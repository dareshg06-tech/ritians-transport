# Where is my Bus — Project Archive

A live bus tracking app for 52 Chennai college bus routes. All buses go to RIT Campus.
Inspired by Chalo + Where is my Train + Bitano Transport Driver GPS Portal.

## What's inside

- **src/** — Next.js 16 + TypeScript source code
  - `app/page.tsx` — Main page with Find My Bus / Driver Mode tabs
  - `components/driver-dashboard.tsx` — Driver GPS Portal (Bitano-style)
  - `components/passenger-dashboard.tsx` — Student dashboard with boarding point
  - `components/bus-map.tsx` — Leaflet map component
  - `hooks/use-bus-socket.ts` — WebSocket hooks
  - `lib/bus-routes.ts` — 52 routes (all → RIT Campus)
  - `lib/route-stops.ts` — Intermediate stops per route
  - `lib/buses.ts` — 12-bus fleet
  - `lib/geo.ts` — Haversine, ETA, next-stop logic
  - `lib/seed.ts` — 4 demo drivers
  - `app/api/` — REST endpoints (driver login, trip start/end, history, stop events)
- **prisma/schema.prisma** — Driver, Trip, StopEvent models
- **db/custom.db** — SQLite database with seed data
- **mini-services/bus-tracker/** — Socket.io WebSocket service (port 3003)
- **scripts/** — Screenshot compression utility
- **download/** — 88 screenshots (compressed)
- **worklog.md** — Full development history

## Tech Stack
- Next.js 16 + TypeScript + Tailwind CSS 4 + shadcn/ui
- Prisma ORM (SQLite)
- Socket.io (real-time WebSocket)
- Leaflet + OpenStreetMap (maps)
- Lucide React (icons)
- Framer Motion (animations)

## How to run

```bash
# 1. Install dependencies
bun install

# 2. Start the Next.js app (runs on port 3000)
bun run dev

# 3. In a separate terminal, start the WebSocket mini-service
cd mini-services/bus-tracker
bun install
bun run dev   # runs on port 3003

# 4. Open http://localhost:81 in your browser
#    (Caddy proxies port 81 → 3000 for the app and → 3003 for WebSocket)
```

## Features

### Student Dashboard (Find My Bus)
- Search and select from 52 routes (all go to RIT Campus)
- See live bus location, speed, next stop ETA
- Select your boarding point → see "Bus reaches you in X min"
- Live map with route line and bus marker
- System status (Live Location ON/OFF, Bus Tracking, etc.)

### Driver Dashboard (Driver Mode)
- Login with DRIVER-001 to DRIVER-004
- Select your assigned bus
- Choose GPS or Network location source
- Start/Stop sharing live location
- Start/End trip with database persistence
- Emergency alert button
- Record passenger count per stop
- View trip history in profile

### Demo Drivers
| ID | Name |
|----|------|
| DRIVER-001 | Ramesh Kumar |
| DRIVER-002 | Suresh Babu |
| DRIVER-003 | Anand Raj |
| DRIVER-004 | Mohan Das |

## Notes
- `node_modules/` and `.next/` are excluded — run `bun install` to restore
- The SQLite database is included with seed data
- The upload/ folder (60MB of video/image references) is excluded
- All screenshots in download/ are compressed (67% smaller)
