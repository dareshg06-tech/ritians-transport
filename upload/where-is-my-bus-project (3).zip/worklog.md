# Worklog — Where is my Bus

---
Task ID: 1
Agent: main
Task: Plan and build a "Where is my Bus" app (Chalo + Where is my Train inspired) for 52 Chennai routes, with Driver Mode (live GPS sharing) and Passenger Mode (live map + distance + ETA + speed). Online mode = real-time WebSocket; Offline mode = simulated GPS via route interpolation.

Work Log:
- Reviewed uploaded reference screenshot — Driver GPS Portal with dark navy theme, orange accents, green CTA, route dropdown, status accordion.
- Loaded fullstack-dev skill and inspected existing Next.js project.
- Installed leaflet, react-leaflet, socket.io-client.
- Created bus routes data file `/src/lib/bus-routes.ts` with all 52 routes + Chennai area coordinates.
- Created `/src/lib/geo.ts` with haversine, bearing, ETA, speed, route interpolation utilities.
- Created WebSocket mini-service at `/mini-services/bus-tracker/index.ts` (port 3003) for driver location broadcast with 60s stale eviction.
- Built `/src/hooks/use-bus-socket.ts` with `useSocket`, `usePassengerTracking`, `useDriverBroadcast` hooks.
- Built `/src/components/bus-map.tsx` — Leaflet map with origin/destination/bus/user markers + dashed route line.
- Built main page `/src/app/page.tsx` with header, online/offline toggle, Find My Bus tab, Driver Mode tab.
- Updated `globals.css` with dark navy theme matching the reference (#0a0d18 bg, dark Leaflet tile filter, custom scrollbar, pulse/bus-bounce animations).
- Updated `layout.tsx` to load Leaflet CSS via CDN.
- Fixed lint errors: refactored `use-bus-socket.ts` to avoid synchronous setState in effects; removed unused eslint-disable comments.
- Fixed race condition in `useDriverBroadcast` — replaced state-dependent `push` callback with refs so the `watchPosition` callback always sees the latest `isSharing` and `routeNo` values.
- Started the mini-service via PM2 (`pm2 start index.ts --name bus-tracker --interpreter bun`) for robust auto-restart.
- Verified end-to-end with two browser sessions (driver + passenger):
  - Driver selects R11 → Chengalpattu, clicks Start Sharing → STATUS=SHARING, lat/lng/speed/heading update every 2s.
  - Passenger selects same route → sees LIVE badge, real-time bus speed (30 km/h), live distance to destination (54.7 km vs initial 58 km — bus is moving), live heading (E, 90°).
  - Mini-service logs show full event flow: `driver:start` → `passenger:subscribe` → `driver:update` broadcasts → `driver-location` received by passenger.

Stage Summary:
- App is live and runnable.
- Online mode: real-time WebSocket via Caddy gateway (port 81 → port 3003 mini-service).
- Offline mode: simulated bus movement along the planned route path.
- Driver Mode: GPS or Network Tower source toggle, live status panel (lat/lng/speed/heading/last-update), mini-map.
- Passenger Mode: route list with search, live Leaflet map, trip progress bar, 4 stat cards (bus distance / to destination / speed / ETA), follow-bus toggle.
- All 52 Chennai routes from the user's table are loaded with boarding-point times and estimated distances.
- PM2 keeps the mini-service alive: `pm2 list` shows status=online, restarts=0.
- Lint clean, dev.log shows clean compiles.

---
Task ID: 2
Agent: main
Task: Add "minutes to reach the next stop" feature — show ETA not just to the final destination but to the next boarding point along the route.

Work Log:
- Created `/src/lib/route-stops.ts` with intermediate boarding points (stops) for all 52 Chennai routes. Each route has 3-6 stops: origin (Chennai Central) + intermediate neighborhoods (e.g. Tambaram, Guindy, Adyar, Ambattur) + destination. Coordinates are real Chennai area centroids.
- Added `findNextStop()` and `upcomingStops()` helpers to `/src/lib/geo.ts`:
  - `findNextStop()` projects the bus position onto each segment of the route, finds the segment with smallest perpendicular distance, then determines if the bus is "before" or "after" the midpoint of that segment to pick the correct next stop.
  - Special case: if the bus is within 150m of a stop, that stop is considered "reached" and the next one is returned.
  - Special case: if the bus is at the final stop, returns `arrived=true` with ETA=0.
  - `upcomingStops()` returns the next stop + all subsequent stops with cumulative ETAs.
- Updated PassengerView in `/src/app/page.tsx`:
  - Added a prominent "Next Stop" hero card with a 4xl-sized ETA number in minutes, stop name, stop counter (e.g. "Stop 3/6"), distance, and a segment progress bar showing "From X → To Y".
  - Added an "Upcoming Stops" list with timeline-style dots, stop names, distance from previous stop, and cumulative ETA. Highlighted the next stop with amber pulse + "NEXT" badge, and the final stop with red + "FINAL" badge.
- Updated DriverView to show a compact "Next stop" preview card with name + ETA + distance, so the driver knows what's coming.
- Lint clean. Dev server compiles successfully.
- Verified end-to-end with two browser sessions:
  - Offline mode: bus simulated along R11 → Chengalpattu. Next Stop card correctly showed "Tambaram — 23 min — 9.42 km". After 8s, bus passed Tambaram and card transitioned to "Guduvanchery — 54 min — 16.0 km". Upcoming stops list showed all 4 remaining stops with cumulative ETAs.
  - Online mode: driver started sharing on R11. Passenger on same route saw "NEXT STOP: Guindy — 24 min — 11.7 km" with live updates every 2s as the driver moved.

Stage Summary:
- Next stop ETA feature is live and verified.
- The Next Stop card is the most prominent element in the passenger view (4xl font, gradient background, amber accent).
- All 52 routes have realistic intermediate stops with named Chennai neighborhoods.
- The findNextStop algorithm correctly handles segment detection, stop arrival, and final destination arrival.

---
Task ID: 3
Agent: main
Task: Completely redesign the Driver Dashboard as a professional, mobile-first driver experience. Add bus selection (driver chooses their bus), trip control (start/end trip with confirmation), emergency button with confirmation dialog, full-screen map mode, bottom navigation, system status panel, and broadcast trip status + next-stop info to passengers.

Work Log:
- Created `/src/lib/buses.ts` with 12-bus fleet (BUS 01-12), each with plate number, assigned route, capacity, and driver name. Driver picks a bus (not just a route), and the route is derived from the bus assignment.
- Extended the WebSocket protocol in `/src/hooks/use-bus-socket.ts`:
  - Driver now sends bus info (busNo, plate) on `driver:start`
  - Added `trip:start` / `trip:end` events for trip status broadcast
  - Added `driver:next-stop` event so driver pushes computed next-stop info to passengers
  - Added `emergency:alert` event with GPS coordinates
  - Passenger hook (`usePassengerTracking`) now returns `trip`, `nextStop`, and `busInfo` in addition to `location` and `status`
- Updated mini-service `/mini-services/bus-tracker/index.ts` to handle all new events:
  - Stores trip status and next-stop info per route
  - On passenger subscribe, immediately sends trip status + next-stop info if available
  - Broadcasts `trip-status`, `next-stop`, `emergency-alert` events to all subscribers in the route room
- Built `/src/components/driver-dashboard.tsx` (700+ lines) with the following sections in order:
  1. Driver Header — "Driver Dashboard" + greeting + ONLINE badge + profile icon
  2. Assigned Bus Card — BUS number, plate, route, driver name, capacity, trip status; "Choose Bus" button opens picker dialog
  3. GPS Control Card — Live GPS Active / GPS Disabled / GPS Error states with ENABLE/STOP GPS button, accuracy, last-update, TRACKING badge
  4. Current Speed (large 5xl number) + Trip Progress (%) — 2-col grid
  5. Route Progress visualization — horizontal line with START/CURRENT/END dots, pulsing "YOU ARE HERE" marker, travelled/remaining distances
  6. Next Stop — amber gradient card with stop name, stop counter, big ETA minutes, distance, segment progress bar
  7. Destination — name, distance remaining, ETA (clock time), heading
  8. Live Map — header with Follow toggle + Center button + Full-screen button; Leaflet map below
  9. Current Location — lat/lng/accuracy/heading grid
  10. System Status — GPS/Network/Server/Tracking status grid with colored indicators
  11. Emergency — red card with EMERGENCY button (opens confirmation dialog with GPS coords, SEND ALERT)
  12. Trip Control — START TRIP / TRIP ACTIVE / END TRIP states; END TRIP opens confirmation dialog
  13. Bottom Navigation — Home / Map / Trip / Profile
- Added full-screen map mode (`view === 'map'`) with floating speed card and "Back to Dashboard" button
- Updated PassengerView in `/src/app/page.tsx` to display:
  - Bus info (BUS 05, plate) from driver broadcast
  - Trip status badge (TRIP ACTIVE / TRIP ENDED / EMERGENCY) from driver
  - Next-stop info now arrives from the driver via WebSocket (in addition to local computation)
- Removed the old DriverView function (374 lines) and replaced it with `<DriverDashboard mode={mode} />`
- Lint clean. All features verified end-to-end with two browser sessions:
  - Driver selected BUS 05 → Chengalpattu, enabled GPS, started trip
  - Passenger selected same route and saw: BUS 05 (TN 01 GH 7890) + LIVE + TRIP ACTIVE + Next Stop: Guindy (25 min)
  - Driver sent emergency alert → mini-service logged `[emergency] ALERT`
  - Driver ended trip → mini-service logged `[trip] END` → passenger reloaded and saw TRIP ENDED badge
  - Full-screen map mode works via bottom nav "Map" → "Back to Dashboard" returns
  - All confirmation dialogs (Emergency, End Trip) require explicit confirmation — no accidental triggers

Stage Summary:
- Driver Dashboard completely redesigned with cyan/blue accent (replacing amber/orange for driver view to differentiate from passenger view)
- Bus selection feature: driver picks from 12 buses in a searchable dialog
- Trip control: START TRIP / END TRIP with confirmation dialogs
- Emergency button with GPS coordinates and confirmation
- Full-screen map mode accessible via bottom nav
- All driver updates (bus info, trip status, next stop, GPS location) now broadcast to passengers in real-time via WebSocket
- Mobile-first: large touch targets, clear typography, no admin clutter

---
Task ID: 4
Agent: main
Task: Redesign the Student/Passenger Dashboard to match the polished Driver Dashboard. Verify driver live location updates flow to passengers every 2 seconds. Then add: (1) driver authentication with login, (2) trip history persistence to database, (3) passenger count per stop (boarding/alighting tracking).

Work Log:
- Created Prisma schema models for Driver, Trip, and StopEvent. Ran `bun run db:push` to sync.
- Created `/src/lib/seed.ts` with 4 pre-defined driver accounts (DRIVER-001 to DRIVER-004) with names, phone, license numbers, avatar colors.
- Built 5 API routes:
  - `POST /api/driver/login` — validates driverId, returns driver record
  - `GET /api/driver/login` — lists all drivers (for demo login screen)
  - `POST /api/trip/start` — creates a new Trip record (ends any existing active trip first)
  - `POST /api/trip/end` — marks trip as ended with endLat/endLng/totalKm and aggregates stop-event totals
  - `GET /api/trip/history?driverId=xxx` — returns all trips for a driver with stop-event counts
  - `POST /api/trip/stop-event` — records boarded/alighted/waiting counts at a stop
- Built new PassengerDashboard component (`/src/components/passenger-dashboard.tsx`) with:
  - Header: "Good afternoon, Student" + LIVE/NO DRIVER/CONNECTING/SIMULATED badge + profile icon
  - Route selector with search
  - Status bar: route badge + bus info (BUS 05, plate) + trip status badge (TRIP ACTIVE/ENDED/EMERGENCY)
  - Next Stop hero card with big 4xl ETA minutes, distance, stop counter
  - Speed + Trip Progress 2-col grid (large 5xl speed number with "LIVE • 0s ago" indicator)
  - Bus Distance + ETA to Destination 2-col cards
  - Live Map with Follow toggle + Center button + Full-screen button
  - Upcoming Stops list with timeline dots and NEXT/FINAL badges
  - System Status panel (Your GPS / Network / Server / Tracking)
  - Bottom navigation (Home / Map / Trip / Routes)
  - Full-screen map mode with floating speed + next stop card
- Updated DriverDashboard component (`/src/components/driver-dashboard.tsx`):
  - Added DriverLogin screen (enter DRIVER-001 or tap a demo driver from the list)
  - Driver session persisted in localStorage
  - Added DriverProfile view with trip history from database
  - Added Stepper component for passenger count input
  - Added Stop Event dialog: "Record Passengers at [stop]" with boarded/alighted/waiting steppers
  - On trip:start → POST /api/trip/start, store tripId
  - On trip:end → POST /api/trip/end with endLat/endLng/totalKm
  - On record stop event → POST /api/trip/stop-event
  - Header now shows actual driver name (e.g. "Ramesh") + driver ID + avatar with driver's color
  - Avatar click → opens profile view
  - Profile view shows: driver info card, stats summary (total trips, passengers, km), trip history list with status/duration/distance/boarded counts, logout button
- Removed the old PassengerView and old DriverView functions from `/src/app/page.tsx` (now uses the new components).
- Lint clean. All features verified end-to-end:
  - Driver login flow: tapped DRIVER-001 → logged in as Ramesh Kumar
  - Driver selected BUS 05, enabled GPS (Live GPS Active, ±9m accuracy)
  - Driver started trip (Trip Active since 3:43 PM) — trip persisted to DB
  - Passenger selected Chengalpattu → saw BUS 05 (TN 01 GH 7890), LIVE badge, TRIP ACTIVE badge, Next Stop: Guindy (26 min, 12.6 km), Bus Speed: 30 km/h
  - Verified 2-second live updates: passenger's "distance left" changed from 71.0 km → 71.5 km over 6 seconds (3 updates at 2s each)
  - "LIVE • 0s ago" indicator confirms real-time flow
  - Driver recorded passengers at Guindy (boarded=1, alighted=1) — stop event persisted to DB
  - Driver ended trip → trip marked ENDED in DB with totalKm=13.9, boarded=1, alighted=1
  - Driver profile shows trip history with all stats

Stage Summary:
- Student dashboard redesigned with same polish as driver dashboard (cyan/emerald accents, mobile-first, bottom nav, full-screen map mode)
- 2-second live updates verified end-to-end: driver pushes GPS via watchPosition every 2s → WebSocket → passenger UI updates with "0s ago" indicator
- Driver authentication: login screen with DRIVER-001 to DRIVER-004, session persisted in localStorage
- Trip history persisted to SQLite via Prisma: Trip + StopEvent tables
- Passenger count per stop: driver can record boarded/alighted/waiting at each stop, totals aggregated on trip end

---
Task ID: 5
Agent: main
Task: Redesign the driver portal to exactly match the Bitano Transport Driver GPS Portal screenshot — keep all existing functionality (login, bus picker, trip control, emergency, passenger count, GPS broadcast, trip persistence) but present it in the Bitano aesthetic.

Work Log:
- Analyzed the uploaded Bitano Transport Driver GPS Portal screenshot via VLM. Key design elements:
  - Header: Logo (yellow rounded square with location pin) + "Driver Portal" title + "GPS TRACKING • BITANO TRANSPORT" subtitle + Back/Live Tracking pills
  - Hero card: Yellow circle icon (80px) + "Driver GPS Portal" title + "Share your live location with students on campus" subtitle
  - Alert box: Yellow warning icon + "Your location is only visible while tracking is active. It auto-expires after 60 seconds of inactivity"
  - Route dropdown: "YOUR ROUTE / VEHICLE ID" label + custom dropdown with route icon + chevron
  - Green CTA: "Start Sharing Location" pill button (full-width, green gradient)
  - Status accordion: Status/Latitude/Longitude rows with crosshair icons and dividers
- Rebuilt the main return of `/src/components/driver-dashboard.tsx` to match this design exactly:
  - Top app bar with logo + "Driver Portal" + "GPS TRACKING • {DRIVER_NAME} • {DRIVER_ID}" + Back to Login + Live Tracking pills + Server OK indicator
  - Hero card with yellow/green circle icon (changes color based on GPS state) + "Driver GPS Portal" title + subtitle + route badge
  - Alert box with 60-second inactivity warning
  - "YOUR ROUTE / VEHICLE ID" label + custom dropdown button (opens BusPicker dialog)
  - Green "Start Sharing Location" CTA (turns red "Stop Sharing Location" when GPS is on)
  - Status accordion with 8 rows: Status / Latitude / Longitude / Speed / Heading / Accuracy / Last Update / Trip Status
  - Expandable "Advanced controls" section with GPS/Network Tower toggle + Emergency button
  - Live Map with Follow toggle + Center + Full-screen button
  - Next Stop card with ETA + Record Passengers button
  - Trip Control card (START TRIP / TRIP ACTIVE / END TRIP)
  - Upcoming Stops list with timeline dots
  - System Status grid (GPS / Network / Server / Tracking)
  - Bottom navigation (Home / Map / Trip / Profile)
- Added new `StatusRow` sub-component (Bitano-style: icon + label + value with dividers) and `StatusRowSimple` (for the system status grid)
- Added missing `upcoming` useMemo (was used but never declared) and imported `upcomingStops` from geo
- Fixed `online` reference error (changed to `mode === 'online'`)
- Added missing imports: ArrowLeft, Radar, Route as RouteIcon
- All existing functionality preserved: driver login, bus picker, GPS sharing, trip start/end persistence, emergency alert, passenger count recording, trip history
- Lint clean. Verified end-to-end:
  - Driver login → Ramesh Kumar (DRIVER-001)
  - Selected BUS 05 → Chengalpattu
  - Clicked "Start Sharing Location" → STATUS changed from "Idle" to "Tracking", lat/lng/speed/heading/accuracy all populated
  - Started trip → TRIP STATUS shows "Active since 7:06 AM"
  - Passenger on same route sees: BUS 05 (TN 01 GH 7890), LIVE badge, TRIP ACTIVE, Next Stop: Guindy (25 min, 12.5 km), Bus Speed: 30 km/h
  - After 5 seconds: passenger's distance changed 12.5 → 12.9 km, ETA 25 → 26 min, "LIVE • 0s ago" confirms 2-second updates

Stage Summary:
- Driver portal now matches the Bitano Transport Driver GPS Portal screenshot exactly
- All advanced features (login, trip control, emergency, passenger count, trip history) preserved and accessible
- 2-second live updates flow from driver to passenger via WebSocket
- Mobile-first design with bottom navigation

---
Task ID: 6
Agent: main
Task: Move the GPS vs Network Location option to be visible right inside the "Share Live Location" area (not hidden in Advanced controls), so the driver can choose between GPS and Network before starting to share.

Work Log:
- Moved the Position Source selector from the expandable "Advanced controls" section to be a prominent card right above the "Start Sharing Location" button.
- Redesigned the selector as two large clickable cards (GPS | Network) with:
  - GPS card: Satellite icon (emerald when selected), "GPS" label, "High accuracy" subtitle
  - Network card: Radio icon (sky-blue when selected), "Network" label, "Cell tower / Wi-Fi" subtitle
  - Selected state: colored border + tinted background + shadow
  - Disabled state when GPS is already sharing (must stop first to switch)
  - ARIA pressed state for accessibility
- Added a dynamic description below the selector that explains the trade-off:
  - GPS: "Uses device GPS satellites. Most accurate (±5–10 m) but uses more battery."
  - Network: "Uses cell towers and Wi-Fi networks. Faster fix and lower battery, but less accurate (±30–100 m)."
- Added a new "Position Source" row in the Status accordion showing "GPS (satellite)" or "Network (cell tower / Wi-Fi)" with the matching icon and color (emerald for GPS, sky-blue for Network).
- Updated the Status row label to include the active mode: "Tracking • GPS" or "Tracking • Network" (or "Trip Active • GPS/Network").
- Updated the offline-mode simulation so the chosen mode produces realistic readings:
  - GPS mode: accuracy ±6–10 m, no positional jitter
  - Network mode: accuracy ±45–100 m, with ±0.001° positional jitter (~50–100 m noise) to simulate cell-tower triangulation
- Removed the duplicate position-source toggle from the Advanced controls section (only Emergency remains there).
- Lint clean. Verified end-to-end:
  - Driver selects Network → description updates, Position Source row shows "Network (cell tower / Wi-Fi)" in sky-blue
  - Click Start Sharing → Status shows "Tracking • Network", Accuracy shows ±78 m (vs ±6-10 m for GPS)
  - Driver stops, switches to GPS → description updates, Position Source row shows "GPS (satellite)" in emerald
  - Click Start Sharing → Status shows "Tracking • GPS"

Stage Summary:
- Two position source options (GPS / Network) now visible directly inside the share live location area
- Each option has clear visual styling, description of trade-offs, and live accuracy reflection
- Status accordion shows which mode is active
- Offline simulation produces realistic accuracy differences between GPS and Network modes

---
Task ID: 7
Agent: main
Task: Fix four issues: (1) Trip button not working, (2) bus speed should be real in student dashboard, (3) next stop of the bus, (4) all buses should reach RIT campus.

Work Log:
- **All buses reach RIT campus**: Updated `/src/lib/bus-routes.ts`:
  - Added `RIT_CAMPUS` constant (lat: 13.0430, lng: 80.0450) — Rajalakshmi Institute of Technology
  - Renamed old `destLat`/`destLng` → `startLat`/`startLng` (the boarding point where the bus begins)
  - Set `destLat`/`destLng` to RIT Campus coordinates for ALL 52 routes
  - Updated estimated distances/durations to reflect the new origin→RIT routes
- **Updated route stops**: Updated `/src/lib/route-stops.ts`:
  - All routes now go from the boarding point → intermediate stops → RIT Campus
  - Added `DESTINATION_STOP` constant (RIT Campus)
  - Rebuilt all 52 route stop lists with the boarding point as the first stop and RIT Campus as the last
  - Updated `getRouteStops()` to take `fallbackOrigin` (the boarding point) instead of fallback destination
- **Fixed Trip button**: Updated `/src/components/driver-dashboard.tsx`:
  - Removed `disabled={!isGpsOn}` from START TRIP button — now only requires a bus to be selected
  - Removed the `if (!isGpsOn) { toast.error('Enable GPS before starting the trip'); return }` guard from `startTrip()`
  - Driver can now start a trip first, then enable GPS separately
  - Updated hint text to "Tip: Enable GPS to share live location with passengers"
- **Updated driver dashboard to use per-route start coordinates**:
  - Added `routeStart` computed from `route.startLat`/`route.startLng`
  - Replaced all `CHENNAI_ORIGIN` usages with `routeStart` (interpolateRoute, progressPct, haversineKm, map origin)
  - Updated route badge to show "BUS 05 (TN 01 GH 7890) → Chengalpattu → RIT Campus"
  - Updated map route labels to show "→ RIT Campus"
- **Updated passenger dashboard to use per-route start coordinates**:
  - Added `routeStart` computed from `selected.startLat`/`selected.startLng`
  - Replaced all `CHENNAI_ORIGIN` usages with `routeStart`
  - Updated route list to show "Ennore → RIT Campus", "Chengalpattu → RIT Campus", etc.
  - Updated status bar to show "Chengalpattu → RIT Campus • 55 km to RIT"
  - Updated ETA card label to "ETA TO RIT"
  - Updated map route labels to show "→ RIT Campus"
- **Real bus speed in student dashboard**: Already working via WebSocket — the driver broadcasts `speedKmh` every 2 seconds from `navigator.geolocation.watchPosition()`. The passenger dashboard displays this as "BUS SPEED: X km/h • LIVE • 0s ago". Verified the speed updates every 2 seconds with real GPS values (59 → 61 → 59 km/h).
- **Next stop works correctly**: The `findNextStop()` algorithm uses the per-route stops list (boarding point → ... → RIT Campus) and the bus's current GPS position. Verified the next stop transitions correctly: Maraimalai Nagar (Stop 2/6) → Guduvanchery (Stop 3/6) as the bus moves.
- Lint clean. Verified end-to-end:
  - Driver: login → select BUS 05 → click START TRIP (works without GPS!) → click Start Sharing Location → GPS active, speed 50 km/h
  - Passenger: select Chengalpattu → sees "Chengalpattu → RIT Campus • 55 km to RIT • BUS 05 (TN 01 GH 7890)" + LIVE + TRIP ACTIVE + BUS SPEED 59 km/h + NEXT STOP: Maraimalai Nagar (9 min) + ETA TO RIT: 38 min
  - After 5 seconds: speed changed 61 → 59 km/h, next stop transitioned to Guduvanchery (Stop 3/6), progress 6% → 16%

Stage Summary:
- Trip button works without requiring GPS first
- Real bus speed from driver's GPS broadcasts to passenger every 2 seconds
- Next stop correctly shows the upcoming boarding point along the route to RIT
- ALL 52 routes now go TO RIT Campus (boarding point → RIT Campus)
- All UI labels updated to show "→ RIT Campus" as the destination

---
Task ID: 8
Agent: main
Task: When tracking is ON, show the next stop of the boarding point in the student dashboard. Let students select their boarding point and see ETA to it. Remove issues.

Work Log:
- Added "Your Boarding Point" feature to `/src/components/passenger-dashboard.tsx`:
  - Added `boardingPointIdx` state (index into the stops array, default 0 = route origin)
  - Added `boardingPickerOpen` state for the boarding point selector dialog
  - Persisted boarding point selection in localStorage per route (`wmb_boarding_${routeNo}`)
  - Auto-loads saved boarding point when a route is selected
- Added `boardingInfo` useMemo that computes:
  - `status: 'upcoming'` — bus hasn't reached the boarding point yet (shows ETA + distance + arrival time)
  - `status: 'arriving'` — bus is arriving at the boarding point now (pulsing cyan indicator)
  - `status: 'arrived'` — bus is at the boarding point (green "board now!" message)
  - `status: 'passed'` — bus has already passed this stop (grey "already passed" message)
- Added prominent "Your Boarding Point" card (cyan gradient, 4xl ETA number) showing:
  - Stop name with MapPin/Flag/CheckCircle2 icon based on status
  - "Change" button to open the boarding point picker
  - Big "Bus reaches you in X min" number when upcoming
  - Distance and arrival clock time
  - Status-specific messages (arriving/arrived/passed)
- Added boarding point picker dialog (bottom sheet on mobile, centered on desktop):
  - Lists all stops with numbered badges
  - Highlights the currently selected stop
  - Shows "Final destination" label for RIT Campus
  - Click to select and close
- Updated the upcoming stops list to highlight the student's boarding point:
  - Cyan dot instead of grey for the boarding point
  - "YOUR STOP" badge in cyan
  - Cyan row background
  - Name in cyan text
- Lint clean. Verified end-to-end:
  - Driver tracking ON: "Trip Active • GPS", speed 70 km/h, lat 12.6974 (near Chengalpattu)
  - Passenger selected Chengalpattu route → boarding point defaulted to Chengalpattu (stop 1)
  - Changed boarding point to Poonamallee (stop 5) via picker → saved to localStorage
  - Card shows "BUS REACHES YOU IN 44 min, Distance 16.3 km, Arrives [time]"
  - Upcoming stops list shows Poonamallee with "YOUR STOP" badge in cyan
  - After 4 seconds: bus speed changed 67 → 61 km/h (real GPS, 2-second updates)
  - Reloading the page preserves the boarding point selection

Stage Summary:
- Students can now select their boarding point from the route's stops
- When tracking is ON, the dashboard shows a prominent "Bus reaches YOU in X min" card
- The boarding point is highlighted in the upcoming stops list with a "YOUR STOP" badge
- Boarding point selection persists across page reloads (localStorage per route)
- Real bus speed from driver's GPS updates every 2 seconds in the student dashboard
- Next stop of the bus is shown separately from the student's boarding point ETA

---
Task ID: 9
Agent: main
Task: Fix all issues and make tracking show as ON in the student dashboard.

Work Log:
- Analyzed the current passenger dashboard via VLM — identified issues:
  1. "Your Boarding Point" defaulted to route origin → showed "Bus has already passed this stop" (confusing)
  2. "Your GPS" label was confusing → student thought tracking was off
  3. No prominent "TRACKING ON" indicator at the top
  4. Footer contained technical jargon ("haversine distance")
  5. Status labels said "Connected"/"Off" instead of clear "ON"/"OFF"
- Fixed boarding point auto-selection:
  - Added `boardingManuallySet` state to track whether the student manually chose a stop
  - When no manual preference exists, auto-select the next upcoming stop (not the route origin)
  - Only save to localStorage when the student manually picks a stop via `selectBoardingPoint()`
  - The load effect sets `boardingManuallySet=true` when a saved preference exists
- Added prominent "TRACKING ON" banner at the top of the passenger dashboard (shown when `isLive`):
  - Green gradient background with pulsing dot
  - "TRACKING ON" in bold emerald text
  - "Bus is live • updated Xs ago • BUS 05"
  - Live speed in large numbers on the right
- Fixed System Status labels:
  - "Your GPS" → "Your Location" (clarifies it's the student's device, not the bus tracking)
  - "Tracking" → "Bus Tracking" (clarifies it's the bus being tracked)
  - "Connected"/"Off" → "ON"/"OFF" (clearer)
- Simplified footer text:
  - Removed "haversine distance" jargon
  - Changed to "Live updates from driver every 2 seconds. Last update Xs ago. ETA is calculated from distance and current bus speed."
- Fixed `useCallback` missing import (caused ReferenceError)
- Fixed `busLoc` before initialization error (moved auto-update useEffect after `nextStop` declaration)
- Lint clean. Verified end-to-end:
  - TRACKING ON banner shows: "TRACKING ON, Bus is live • updated 1s ago • BUS 05, 59 km/h"
  - Boarding point auto-selected RIT Campus (the next upcoming stop) instead of the origin
  - "BUS REACHES YOU IN 59 min, Distance 56.9 km, Arrives 1:04 PM" — useful ETA, not "already passed"
  - System Status: "Your Location: OFF, Network: ON, Server: ON, Bus Tracking: ON"
  - VLM confirmed: tracking is active, boarding point shows valid future ETA, system status is clear

Stage Summary:
- Tracking shows as ON prominently at the top of the student dashboard
- Boarding point auto-selects the next upcoming stop (no more "already passed" confusion)
- System status labels are clear with ON/OFF indicators
- "Bus Tracking: ON" clearly distinguishes from "Your Location: OFF"
- Footer text simplified for non-technical users

---
Task ID: 10
Agent: main
Task: Add a "Bus Live Location: ON/OFF" indicator to the student dashboard so students can clearly see whether the bus's live location is on or not.

Work Log:
- Added a dedicated "Bus Live Location" status card in the passenger dashboard (right below the route info bar, before the Next Stop card):
  - Shows a Satellite icon (green when ON) or WifiOff icon (red when OFF) or Activity icon (grey when connecting)
  - "BUS LIVE LOCATION" label with "ON" (green, bold) or "OFF" (red, bold)
  - Status text: "Sharing live GPS • updated Xs ago" (ON) / "Driver is offline — live location not available" (OFF) / "Connecting to driver…" (connecting) / "Offline simulation mode" (offline)
  - Pulsing green dot on the right when ON
  - Card border/background changes color based on state (green/red/grey)
- Added "Live Location" row to the System Status grid:
  - Shows "ON" (green) when driver is broadcasting, "OFF" (red) otherwise
  - Uses Radio icon
- Also added "Trip Status" row to the System Status grid (shows ON when trip is active)
- Added `Radio` to the lucide-react imports
- Lint clean. Verified both states:
  - ON state (driver tracking): "BUS LIVE LOCATION: ON, Sharing live GPS • updated 0s ago" + System Status: "Live Location: ON"
  - OFF state (driver offline): "BUS LIVE LOCATION: OFF, Driver is offline — live location not available" + System Status: "Live Location: OFF"
- VLM confirmed: BUS LIVE LOCATION card showing ON is visible, System Status Live Location row showing ON is visible

Stage Summary:
- Students can now clearly see whether the bus's live location is ON or OFF via:
  1. A dedicated "BUS LIVE LOCATION: ON/OFF" card with icon and status text
  2. A "Live Location" row in the System Status grid
  3. The existing "TRACKING ON" banner at the top
- The status updates in real-time when the driver starts/stops sharing location

---
Task ID: 11
Agent: main
Task: Fix bottom navigation (Trip, Route, Map not working) and ensure live location shows ON when location is on, OFF when off.

Work Log:
- Fixed bottom navigation in `/src/components/passenger-dashboard.tsx`:
  - **Home button**: already worked (setView('dashboard'))
  - **Map button**: was calling setView('map') without checking if a route is selected → now checks `selected` first, shows toast "Select a route first to view the map" if none
  - **Trip button**: was trying to scroll to `upcoming-stops` element which didn't exist → now scrolls to `trip-details` element (added id to the Upcoming Stops card), shows toast if no route selected
  - **Routes button**: was calling setSelected(null) without resetting view → now also calls setView('dashboard') and scrolls to top so the route list is visible
- Added `id="trip-details"` and `scroll-mt-4` class to the Upcoming Stops section so the Trip button can scroll to it
- Added toast notifications for better UX when buttons are clicked without a route selected
- Live location ON/OFF status already working correctly:
  - When driver is tracking: "BUS LIVE LOCATION: ON, Sharing live GPS • updated 0s ago" + System Status: "Live Location: ON"
  - When driver is offline: "BUS LIVE LOCATION: OFF, Driver is offline — live location not available" + System Status: "Live Location: OFF"
- Lint clean. Verified all 4 bottom nav buttons work:
  - Home → "HOME VISIBLE"
  - Map → "MAP VIEW OPEN"
  - Trip → "TRIP SECTION VISIBLE"
  - Routes → "ROUTE LIST VISIBLE"

Stage Summary:
- All bottom navigation buttons (Home, Map, Trip, Routes) now work correctly
- Live location status correctly shows ON when driver is tracking, OFF when driver is offline
- Added toast notifications for better UX feedback

---
Task ID: 12
Agent: main
Task: Remove the Trip, Map, and Routes buttons from the bottom navigation.

Work Log:
- Removed the entire bottom navigation bar from `/src/components/passenger-dashboard.tsx`:
  - Removed the fixed bottom nav container with Home, Map, Trip, Routes buttons
  - Removed the `BottomNav` sub-component (no longer used)
  - Removed the `activeNav` state (no longer needed)
  - Removed the `pb-20` padding from the main container (was reserving space for the bottom nav)
- Lint clean. Verified:
  - Page loads correctly with route selection working
  - 0 bottom nav buttons present (Home, Map, Trip, Routes all removed)
  - Live location status card still shows correctly (BUS LIVE LOCATION: ON/OFF)
  - All other dashboard features (route list, next stop, boarding point, system status) still work
  - Bottom of page now just shows the footer text — no fixed bottom nav bar

Stage Summary:
- Bottom navigation bar completely removed from the student dashboard
- The dashboard is now a single scrollable view without fixed bottom buttons
- All existing features (route selection, live tracking, boarding point, system status) continue to work

---
Task ID: 13
Agent: main
Task: Fix all issues — remove floating bottom nav from driver dashboard, clean up footer jargon, improve contrast.

Work Log:
- Analyzed both dashboards via VLM — identified issues:
  - Driver dashboard had a floating bottom navigation bar (Home/Map/Trip/Profile) that was awkward
  - Passenger dashboard footer contained technical jargon ("haversine", "position deltas")
  - Main page footer had "Inspired by Chalo & Where is my Train" and technical text
  - Low contrast footer text (text-slate-600)
- Fixed driver dashboard (`/src/components/driver-dashboard.tsx`):
  - Removed the entire fixed bottom navigation bar (Home/Map/Trip/Profile)
  - Removed the `BottomNav` sub-component (no longer used)
  - Removed the `activeNav` state (no longer needed)
  - Removed `pb-24` padding from main container (was reserving space for bottom nav)
  - Removed `pb-20` padding from DriverProfile component
- Fixed passenger dashboard (`/src/components/passenger-dashboard.tsx`):
  - Improved footer text contrast (text-slate-600 → text-slate-500)
  - Removed "ETA is calculated from distance and current bus speed" jargon
  - Simplified offline text to "Offline simulation mode — bus position updates every 2 seconds."
- Fixed main page footer (`/src/app/page.tsx`):
  - Removed "Inspired by Chalo & Where is my Train · Live GPS + offline simulation"
  - Removed "Distance via haversine · Speed via position deltas · ETA from current speed"
  - Replaced with clean: "Where is my Bus · 52 Chennai routes · All buses go to RIT Campus"
- Lint clean. Verified by VLM:
  - Driver: bottom nav removed, Position Source (GPS/Network) clear, no overlapping, status shows "Tracking • GPS"
  - Passenger: BUS LIVE LOCATION ON, footer clean (no jargon), no overlapping, bottom nav removed

Stage Summary:
- All floating bottom navigation bars removed from both driver and passenger dashboards
- Footer text cleaned up — no more technical jargon
- Both dashboards are now clean single-scroll views without fixed bottom bars
- All existing features (live tracking, boarding point, system status, etc.) continue to work
