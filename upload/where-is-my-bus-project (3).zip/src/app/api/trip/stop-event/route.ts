import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

// POST /api/trip/stop-event
// Body: { tripId, stopName, stopIndex, boarded, alighted, waitingAt }
// Records a passenger boarding/alighting event at a stop
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const tripId = String(body.tripId || "").trim()
  const stopName = String(body.stopName || "").trim()
  const stopIndex = typeof body.stopIndex === "number" ? body.stopIndex : -1
  const boarded = Math.max(0, Math.floor(Number(body.boarded) || 0))
  const alighted = Math.max(0, Math.floor(Number(body.alighted) || 0))
  const waitingAt = Math.max(0, Math.floor(Number(body.waitingAt) || 0))

  if (!tripId || !stopName) {
    return NextResponse.json({ error: "tripId and stopName are required" }, { status: 400 })
  }

  const trip = await db.trip.findUnique({ where: { id: tripId } })
  if (!trip) {
    return NextResponse.json({ error: "Trip not found" }, { status: 404 })
  }

  const event = await db.stopEvent.create({
    data: { tripId, stopName, stopIndex, boarded, alighted, waitingAt },
  })

  return NextResponse.json({ ok: true, event })
}

// GET /api/trip/stop-event?tripId=xxx
// Returns: all stop events for a trip
export async function GET(req: NextRequest) {
  const url = new URL(req.url)
  const tripId = url.searchParams.get("tripId")
  if (!tripId) {
    return NextResponse.json({ error: "tripId query param required" }, { status: 400 })
  }
  const events = await db.stopEvent.findMany({
    where: { tripId },
    orderBy: { timestamp: "asc" },
  })
  return NextResponse.json({ events })
}
