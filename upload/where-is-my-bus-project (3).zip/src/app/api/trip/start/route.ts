import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

// POST /api/trip/start
// Body: { driverId, busNo, plate, routeNo, routeName }
// Returns: created trip record
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const driverId = String(body.driverId || "").trim()
  const busNo = String(body.busNo || "").trim()
  const plate = String(body.plate || "").trim()
  const routeNo = String(body.routeNo || "").trim()
  const routeName = String(body.routeName || "").trim()

  if (!driverId || !busNo || !routeNo) {
    return NextResponse.json({ error: "driverId, busNo, routeNo are required" }, { status: 400 })
  }

  // End any currently-active trip for this driver before starting a new one
  const existing = await db.trip.findFirst({
    where: { driverId, status: "active" },
  })
  if (existing) {
    await db.trip.update({
      where: { id: existing.id },
      data: { status: "ended", endedAt: new Date() },
    })
  }

  const trip = await db.trip.create({
    data: {
      driverId,
      busNo,
      plate,
      routeNo,
      routeName,
      status: "active",
      startedAt: new Date(),
    },
  })

  return NextResponse.json({ ok: true, trip })
}
