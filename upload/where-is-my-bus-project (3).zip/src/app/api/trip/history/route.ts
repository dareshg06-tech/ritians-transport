import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

// GET /api/trip/history?driverId=DRIVER-001
// Returns: all trips for the driver, newest first
export async function GET(req: NextRequest) {
  const url = new URL(req.url)
  const driverId = url.searchParams.get("driverId")
  if (!driverId) {
    return NextResponse.json({ error: "driverId query param required" }, { status: 400 })
  }

  const trips = await db.trip.findMany({
    where: { driverId },
    orderBy: { startedAt: "desc" },
    include: {
      stopEvents: {
        orderBy: { timestamp: "asc" },
      },
    },
    take: 50,
  })

  // Compute trip duration
  const result = trips.map((t) => ({
    id: t.id,
    busNo: t.busNo,
    plate: t.plate,
    routeNo: t.routeNo,
    routeName: t.routeName,
    status: t.status,
    startedAt: t.startedAt.toISOString(),
    endedAt: t.endedAt?.toISOString() || null,
    durationMin: t.endedAt ? (t.endedAt.getTime() - t.startedAt.getTime()) / 60000 : null,
    totalKm: t.totalKm,
    totalBoarded: t.totalBoarded,
    totalAlighted: t.totalAlighted,
    stopsCount: t.stopEvents.length,
  }))

  return NextResponse.json({ trips: result })
}
