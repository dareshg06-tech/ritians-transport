import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"

// POST /api/trip/end
// Body: { tripId } OR { driverId, busNo } to find active trip
// Returns: ended trip record
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const tripId = String(body.tripId || "").trim()
  const driverId = String(body.driverId || "").trim()
  const busNo = String(body.busNo || "").trim()
  const endLat = typeof body.endLat === "number" ? body.endLat : null
  const endLng = typeof body.endLng === "number" ? body.endLng : null
  const totalKm = typeof body.totalKm === "number" ? body.totalKm : null

  let trip
  if (tripId) {
    trip = await db.trip.findUnique({ where: { id: tripId } })
  } else if (driverId && busNo) {
    trip = await db.trip.findFirst({
      where: { driverId, busNo, status: "active" },
    })
  } else if (driverId) {
    trip = await db.trip.findFirst({
      where: { driverId, status: "active" },
    })
  }

  if (!trip) {
    return NextResponse.json({ error: "Active trip not found" }, { status: 404 })
  }

  // Compute totals from stop events
  const agg = await db.stopEvent.aggregate({
    where: { tripId: trip.id },
    _sum: { boarded: true, alighted: true },
  })

  const updated = await db.trip.update({
    where: { id: trip.id },
    data: {
      status: "ended",
      endedAt: new Date(),
      endLat: endLat ?? undefined,
      endLng: endLng ?? undefined,
      totalKm: totalKm ?? undefined,
      totalBoarded: agg._sum.boarded || 0,
      totalAlighted: agg._sum.alighted || 0,
    },
  })

  return NextResponse.json({ ok: true, trip: updated })
}
