import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { ensureSeedDrivers } from "@/lib/seed"

// POST /api/driver/login
// Body: { driverId: string }
// Returns: driver record if found, else 401
export async function POST(req: NextRequest) {
  await ensureSeedDrivers()
  const body = await req.json().catch(() => ({}))
  const driverId = String(body.driverId || "").trim().toUpperCase()

  if (!driverId) {
    return NextResponse.json({ error: "driverId is required" }, { status: 400 })
  }

  const driver = await db.driver.findUnique({ where: { id: driverId } })
  if (!driver || !driver.active) {
    return NextResponse.json({ error: "Invalid driver ID or driver inactive" }, { status: 401 })
  }

  return NextResponse.json({
    ok: true,
    driver: {
      id: driver.id,
      name: driver.name,
      phone: driver.phone,
      licenseNo: driver.licenseNo,
      avatarColor: driver.avatarColor,
    },
  })
}

// GET /api/driver/login?list=true — list all driver IDs (for demo)
export async function GET() {
  await ensureSeedDrivers()
  const drivers = await db.driver.findMany({
    select: { id: true, name: true, phone: true, active: true },
  })
  return NextResponse.json({ drivers })
}
