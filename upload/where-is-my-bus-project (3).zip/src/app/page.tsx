"use client"

import dynamic from "next/dynamic"
import { useEffect, useMemo, useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Bus,
  Navigation,
  Search,
  MapPin,
  Satellite,
  Radio,
  Clock,
  Gauge,
  Route as RouteIcon,
  Crosshair,
  Play,
  Square,
  Wifi,
  WifiOff,
  ChevronRight,
  Bus as BusIcon,
  Radar,
  Hand,
  Eye,
  ArrowLeft,
  CircleDot,
  Activity,
  TrendingUp,
  Flag,
  MapPinned,
  Timer,
  CheckCircle2,
  Dot,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import {
  BUS_ROUTES,
  CHENNAI_ORIGIN,
  getRouteByNo,
  searchRoutes,
  type BusRoute,
} from "@/lib/bus-routes"
import {
  haversineKm,
  bearingDeg,
  compassLabel,
  formatDistance,
  formatDuration,
  formatSpeed,
  speedBetween,
  etaMinutes,
  interpolateRoute,
  progressPct,
  findNextStop,
  upcomingStops,
  type LatLng,
} from "@/lib/geo"
import { getRouteStops, type Stop } from "@/lib/route-stops"
import DriverDashboard from "@/components/driver-dashboard"
import PassengerDashboard from "@/components/passenger-dashboard"
import {
  usePassengerTracking,
  useDriverBroadcast,
  type DriverLocation,
} from "@/hooks/use-bus-socket"

const BusMap = dynamic(() => import("@/components/bus-map"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-72 rounded-2xl bg-[#0a0d18] border border-[#1f2538] flex items-center justify-center">
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <Radar className="w-4 h-4 animate-pulse" /> Loading map…
      </div>
    </div>
  ),
})

// =================== Shared bits ===================

function ModeBadge({ mode }: { mode: 'online' | 'offline' }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-semibold tracking-wide",
        mode === 'online'
          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
          : "border-amber-500/40 bg-amber-500/10 text-amber-300"
      )}
    >
      {mode === 'online' ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
      {mode === 'online' ? 'ONLINE' : 'OFFLINE'}
    </Badge>
  )
}

function LiveDot({ color = '#22c55e' }: { color?: string }) {
  return (
    <span className="relative inline-flex w-2 h-2">
      <span className="absolute inset-0 rounded-full opacity-60 animate-ping" style={{ background: color }} />
      <span className="relative inline-flex w-2 h-2 rounded-full" style={{ background: color }} />
    </span>
  )
}

function RouteSelector({
  selectedRoute,
  onSelect,
}: {
  selectedRoute: BusRoute | null
  onSelect: (r: BusRoute) => void
}) {
  const [q, setQ] = useState("")
  const list = useMemo(() => searchRoutes(q), [q])

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search route no or destination (e.g. R11 or Chengalpattu)"
          className="pl-10 bg-[#0a0d18] border-[#1f2538] text-slate-100 placeholder:text-slate-600 rounded-xl h-11"
        />
      </div>
      <div className="text-[11px] uppercase tracking-widest text-slate-500 px-1">
        {list.length} routes available
      </div>
      <ScrollArea className="h-[calc(100vh-280px)] min-h-[280px] rounded-xl">
        <div className="space-y-1.5 pr-1">
          {list.map((r) => {
            const isActive = selectedRoute?.routeNo === r.routeNo
            return (
              <button
                key={r.routeNo}
                onClick={() => onSelect(r)}
                className={cn(
                  "w-full text-left rounded-xl px-3.5 py-3 border transition-all flex items-center gap-3",
                  isActive
                    ? "border-emerald-500/50 bg-emerald-500/10"
                    : "border-[#1f2538] bg-[#10131f] hover:border-[#2a3252] hover:bg-[#161b2b]"
                )}
              >
                <div
                  className={cn(
                    "flex-shrink-0 w-12 h-12 rounded-lg flex flex-col items-center justify-center font-bold text-sm",
                    isActive
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-[#1a2032] text-amber-300"
                  )}
                >
                  <span className="text-[10px] uppercase tracking-wider text-slate-500 leading-none">RTE</span>
                  <span className="text-xs leading-tight">{r.routeNo}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-slate-100 truncate">{r.routeName}</div>
                  <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {r.startingTime || '—'}
                    </span>
                    <span className="flex items-center gap-1">
                      <RouteIcon className="w-3 h-3" />
                      {formatDistance(r.estDistanceKm)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Gauge className="w-3 h-3" />
                      ~{formatDuration(r.estDurationMin)}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
              </button>
            )
          })}
          {list.length === 0 && (
            <div className="text-center text-sm text-slate-500 py-8">No routes match "{q}"</div>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}



// =================== Main Page ===================

export default function Home() {
  const [tab, setTab] = useState<'passenger' | 'driver'>('passenger')
  const [mode, setMode] = useState<'online' | 'offline'>('online')

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0d18] text-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#0a0d18]/95 backdrop-blur border-b border-[#1f2538]">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-amber-500/20">
              <Bus className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold tracking-tight text-slate-100 leading-none">Where is my Bus</h1>
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mt-0.5 leading-none">
                Live Tracking • Chennai Routes
              </p>
            </div>
          </div>
          <ModeBadge mode={mode} />
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-4 pb-24">
        {/* Online/Offline mode toggle */}
        <div className="rounded-2xl border border-[#1f2538] bg-[#10131f] p-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className={cn(
                "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                mode === 'online' ? "bg-emerald-500/15 text-emerald-400" : "bg-amber-500/15 text-amber-400"
              )}>
                {mode === 'online' ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold text-slate-100">
                  {mode === 'online' ? 'Online Mode — Live Tracking' : 'Offline Mode — Simulated'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {mode === 'online'
                    ? 'Uses real GPS + WebSocket. Driver pushes live location every 2s.'
                    : 'No driver required. Bus position simulated along the route path.'}
                </div>
              </div>
            </div>
            <Switch
              checked={mode === 'online'}
              onCheckedChange={(v) => setMode(v ? 'online' : 'offline')}
              aria-label="Toggle online/offline mode"
            />
          </div>
        </div>

        {/* Passenger / Driver tabs */}
        <Tabs value={tab} onValueChange={(v) => setTab(v as 'passenger' | 'driver')}>
          <TabsList className="grid w-full grid-cols-2 bg-[#10131f] border border-[#1f2538] rounded-xl h-12 p-1">
            <TabsTrigger
              value="passenger"
              className="rounded-lg data-[state=active]:bg-emerald-500/15 data-[state=active]:text-emerald-300 text-slate-400 gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" />
              Find My Bus
            </TabsTrigger>
            <TabsTrigger
              value="driver"
              className="rounded-lg data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-300 text-slate-400 gap-1.5"
            >
              <Hand className="w-3.5 h-3.5" />
              Driver Mode
            </TabsTrigger>
          </TabsList>
          <TabsContent value="passenger" className="mt-4">
            <PassengerDashboard mode={mode} />
          </TabsContent>
          <TabsContent value="driver" className="mt-4">
            <DriverDashboard mode={mode} />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-[#1f2538] bg-[#0a0d18] py-6 px-4">
        <div className="max-w-5xl mx-auto text-center space-y-1">
          <p className="text-[11px] text-slate-500">
            Where is my Bus · 52 Chennai routes · All buses go to RIT Campus
          </p>
        </div>
      </footer>
    </div>
  )
}
