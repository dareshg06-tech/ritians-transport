// Intermediate boarding points (stops) for each of the 52 Chennai bus routes.
// ALL routes now go TO RIT Campus. The first stop is the route's boarding point (origin),
// and the last stop is always RIT Campus.
// Intermediate stops are real Chennai neighborhoods along the way.

import { RIT_CAMPUS } from "./bus-routes"

export interface Stop {
  name: string
  lat: number
  lng: number
}

// RIT Campus — the final destination for ALL routes
export const DESTINATION_STOP: Stop = {
  name: RIT_CAMPUS.name,
  lat: RIT_CAMPUS.lat,
  lng: RIT_CAMPUS.lng,
}

// Helper to build a route's stop list: origin (boarding point) + intermediates + RIT Campus
function buildStops(origin: Stop, intermediates: Stop[]): Stop[] {
  return [origin, ...intermediates, DESTINATION_STOP]
}

// Map of routeNo -> ordered stops list (boarding point → ... → RIT Campus)
export const ROUTE_STOPS: Record<string, Stop[]> = {
  // Each route starts at its boarding point and ends at RIT Campus.
  // Intermediate stops are neighborhoods between the boarding point and RIT.
  R01: buildStops( // Ennore → RIT
    { name: "Ennore", lat: 13.2202, lng: 80.3094 },
    [
      { name: "Tondiarpet", lat: 13.1296, lng: 80.2924 },
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R01A: buildStops( // Tondiarpet → RIT
    { name: "Tondiarpet", lat: 13.1296, lng: 80.2924 },
    [
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R01B: buildStops( // Kasimedum → RIT
    { name: "Kasimedum", lat: 13.0827, lng: 80.2707 },
    [
      { name: "Egmore", lat: 13.0732, lng: 80.2609 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R02: buildStops( // Triplicane → RIT
    { name: "Triplicane", lat: 13.0569, lng: 80.275 },
    [
      { name: "Anna Salai", lat: 13.0609, lng: 80.2707 },
      { name: "T. Nagar", lat: 13.0418, lng: 80.2342 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R03: buildStops( // Choolai → RIT
    { name: "Choolai", lat: 13.0851, lng: 80.267 },
    [
      { name: "Egmore", lat: 13.0732, lng: 80.2609 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R03A: buildStops( // Collector Nagar → RIT
    { name: "Collector Nagar", lat: 13.0723, lng: 80.2108 },
    [
      { name: "Anna Nagar West", lat: 13.085, lng: 80.21 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R03B: buildStops( // Water Tank → RIT
    { name: "Water Tank", lat: 13.085, lng: 80.2108 },
    [
      { name: "Anna Nagar West", lat: 13.085, lng: 80.21 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R04: buildStops( // East Mogappair → RIT
    { name: "East Mogappair", lat: 13.09, lng: 80.18 },
    [
      { name: "Ambattur OT", lat: 13.0978, lng: 80.1856 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R05: buildStops( // CIT Nagar → RIT
    { name: "CIT Nagar", lat: 13.029, lng: 80.233 },
    [
      { name: "T. Nagar", lat: 13.0418, lng: 80.2342 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R05A: buildStops( // Loyola College → RIT
    { name: "Loyola College", lat: 13.0878, lng: 80.2217 },
    [
      { name: "Nungambakkam", lat: 13.0708, lng: 80.2447 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R06: buildStops( // Chinmayanagar → RIT
    { name: "Chinmayanagar", lat: 13.0725, lng: 80.15 },
    [
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R07: buildStops( // Santhome → RIT
    { name: "Santhome", lat: 13.0504, lng: 80.2772 },
    [
      { name: "Adyar", lat: 13.0014, lng: 80.2569 },
      { name: "Kotturpuram", lat: 13.0186, lng: 80.2431 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R08: buildStops( // Kovilambakkam → RIT
    { name: "Kovilambakkam", lat: 12.9166, lng: 80.208 },
    [
      { name: "Medavakkam", lat: 12.9193, lng: 80.1956 },
      { name: "Sholinganallur", lat: 12.901, lng: 80.227 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R08A: buildStops( // Adambakkam → RIT
    { name: "Adambakkam", lat: 12.9859, lng: 80.2059 },
    [
      { name: "Guindy", lat: 13.0067, lng: 80.2206 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R09: buildStops( // MKB Nagar → RIT
    { name: "MKB Nagar", lat: 13.1258, lng: 80.253 },
    [
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R10: buildStops( // Thachoor → RIT
    { name: "Thachoor", lat: 13.355, lng: 80.045 },
    [
      { name: "Red Hills", lat: 13.1939, lng: 80.1794 },
      { name: "Avadi", lat: 13.1167, lng: 80.1 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R11: buildStops( // Chengalpattu → RIT
    { name: "Chengalpattu", lat: 12.6914, lng: 79.975 },
    [
      { name: "Maraimalai Nagar", lat: 12.7894, lng: 79.9989 },
      { name: "Guduvanchery", lat: 12.846, lng: 80.052 },
      { name: "Vandalur", lat: 12.901, lng: 80.081 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R11A: buildStops( // Guduvanchery → RIT
    { name: "Guduvanchery", lat: 12.846, lng: 80.052 },
    [
      { name: "Vandalur", lat: 12.901, lng: 80.081 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R12: buildStops( // Minjur → RIT
    { name: "Minjur", lat: 13.278, lng: 80.322 },
    [
      { name: "Tondiarpet", lat: 13.1296, lng: 80.2924 },
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R13: buildStops( // Vyasarpadi → RIT
    { name: "Vyasarpadi", lat: 13.118, lng: 80.247 },
    [
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R13A: buildStops( // ICF → RIT
    { name: "ICF", lat: 13.107, lng: 80.243 },
    [
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R14: buildStops( // Thiruvallur → RIT
    { name: "Thiruvallur", lat: 13.128, lng: 79.901 },
    [
      { name: "Tiruninravur", lat: 13.1228, lng: 79.9731 },
      { name: "Veppampattu", lat: 13.085, lng: 79.938 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R14B: buildStops( // Kakkalur → RIT
    { name: "Kakkalur", lat: 13.115, lng: 79.88 },
    [
      { name: "Tiruninravur", lat: 13.1228, lng: 79.9731 },
      { name: "Veppampattu", lat: 13.085, lng: 79.938 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R15: buildStops( // Cheyyar → RIT
    { name: "Cheyyar", lat: 12.658, lng: 79.546 },
    [
      { name: "Kancheepuram", lat: 12.838, lng: 79.704 },
      { name: "Sriperumbudur", lat: 12.9681, lng: 79.9425 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R15A: buildStops( // Orikkai → RIT
    { name: "Orikkai", lat: 12.838, lng: 79.695 },
    [
      { name: "Kancheepuram", lat: 12.838, lng: 79.704 },
      { name: "Sriperumbudur", lat: 12.9681, lng: 79.9425 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R15B: buildStops( // Kancheepuram → RIT
    { name: "Kancheepuram", lat: 12.838, lng: 79.704 },
    [
      { name: "Sriperumbudur", lat: 12.9681, lng: 79.9425 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R16: buildStops( // Neelangkarai → RIT
    { name: "Neelangkarai", lat: 12.944, lng: 80.233 },
    [
      { name: "Sholinganallur", lat: 12.901, lng: 80.227 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R16B: buildStops( // Sholinganallur → RIT
    { name: "Sholinganallur", lat: 12.901, lng: 80.227 },
    [
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R17: buildStops( // Valluvarkottam → RIT
    { name: "Valluvarkottam", lat: 13.052, lng: 80.244 },
    [
      { name: "Nungambakkam", lat: 13.0708, lng: 80.2447 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R17A: buildStops( // Valasaravakkam → RIT
    { name: "Valasaravakkam", lat: 13.053, lng: 80.171 },
    [
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R18: buildStops( // Velachery → RIT
    { name: "Velachery", lat: 12.979, lng: 80.221 },
    [
      { name: "Guindy", lat: 13.0067, lng: 80.2206 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R18A: buildStops( // Sembakkam → RIT
    { name: "Sembakkam", lat: 12.923, lng: 80.141 },
    [
      { name: "Medavakkam", lat: 12.9193, lng: 80.1956 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R18B: buildStops( // Kelambakkam → RIT
    { name: "Kelambakkam", lat: 12.795, lng: 80.218 },
    [
      { name: "Sholinganallur", lat: 12.901, lng: 80.227 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R19: buildStops( // Poombukar → RIT
    { name: "Poombukar", lat: 11.143, lng: 79.843 },
    [
      { name: "Chidambaram", lat: 11.3996, lng: 79.6936 },
      { name: "Pondicherry", lat: 11.9416, lng: 79.8083 },
      { name: "Tindivanam", lat: 12.2417, lng: 79.6456 },
      { name: "Kancheepuram", lat: 12.838, lng: 79.704 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R19A: buildStops( // Vinayagapuram → RIT
    { name: "Vinayagapuram", lat: 13.125, lng: 80.267 },
    [
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R20: buildStops( // Veppampattu → RIT
    { name: "Veppampattu", lat: 13.085, lng: 79.938 },
    [
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R20A: buildStops( // Pattabiram → RIT
    { name: "Pattabiram", lat: 13.111, lng: 79.947 },
    [
      { name: "Veppampattu", lat: 13.085, lng: 79.938 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R21: buildStops( // Ayappakkam → RIT
    { name: "Ayappakkam", lat: 13.115, lng: 80.07 },
    [
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R22: buildStops( // Thiruthani → RIT
    { name: "Thiruthani", lat: 13.175, lng: 79.616 },
    [
      { name: "Tiruvallur", lat: 13.128, lng: 79.901 },
      { name: "Veppampattu", lat: 13.085, lng: 79.938 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R22A: buildStops( // Sholinghur → RIT
    { name: "Sholinghur", lat: 13.118, lng: 79.425 },
    [
      { name: "Thiruthani", lat: 13.175, lng: 79.616 },
      { name: "Tiruvallur", lat: 13.128, lng: 79.901 },
      { name: "Veppampattu", lat: 13.085, lng: 79.938 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R23: buildStops( // K4 Police Station → RIT
    { name: "K4 Police Station", lat: 13.052, lng: 80.252 },
    [
      { name: "Anna Salai", lat: 13.0609, lng: 80.2707 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R24: buildStops( // Arcot → RIT
    { name: "Arcot", lat: 12.908, lng: 79.33 },
    [
      { name: "Walajapet", lat: 12.927, lng: 79.3678 },
      { name: "Kancheepuram", lat: 12.838, lng: 79.704 },
      { name: "Sriperumbudur", lat: 12.9681, lng: 79.9425 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R25: buildStops( // Kallikuppam → RIT
    { name: "Kallikuppam", lat: 13.148, lng: 80.095 },
    [
      { name: "Pattabiram", lat: 13.111, lng: 79.947 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R25A: buildStops( // Kavangarai → RIT
    { name: "Kavangarai", lat: 13.115, lng: 80.09 },
    [
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R26: buildStops( // Andarkuppam → RIT
    { name: "Andarkuppam", lat: 13.57, lng: 80.195 },
    [
      { name: "Ponneri", lat: 13.32, lng: 80.2 },
      { name: "Minjur", lat: 13.278, lng: 80.322 },
      { name: "Tondiarpet", lat: 13.1296, lng: 80.2924 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R26A: buildStops( // Poonamallee → RIT
    { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    []
  ),
  R27: buildStops( // Avadi Checkpost → RIT
    { name: "Avadi Checkpost", lat: 13.116, lng: 80.08 },
    [
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R27A: buildStops( // Kollumedu → RIT
    { name: "Kollumedu", lat: 13.088, lng: 79.97 },
    [
      { name: "Veppampattu", lat: 13.085, lng: 79.938 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R28: buildStops( // Agaram → RIT
    { name: "Agaram", lat: 13.142, lng: 80.205 },
    [
      { name: "Perambur", lat: 13.1178, lng: 80.2406 },
      { name: "Koyambedu", lat: 13.0694, lng: 80.1978 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R29: buildStops( // Medavakkam Koot Road → RIT
    { name: "Medavakkam Koot Road", lat: 12.918, lng: 80.195 },
    [
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R29A: buildStops( // Pammal → RIT
    { name: "Pammal", lat: 12.957, lng: 80.09 },
    [
      { name: "Chromepet", lat: 12.9517, lng: 80.1419 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
  R29B: buildStops( // Sivanthangal → RIT
    { name: "Sivanthangal", lat: 12.943, lng: 80.083 },
    [
      { name: "Chromepet", lat: 12.9517, lng: 80.1419 },
      { name: "Porur", lat: 13.0357, lng: 80.1567 },
      { name: "Poonamallee", lat: 13.046, lng: 80.105 },
    ]
  ),
}

/**
 * Get the ordered list of stops for a route.
 * The first stop is the route's boarding point (origin).
 * The last stop is always RIT Campus.
 * Falls back to [origin, RIT Campus] if the route has no explicit stops.
 */
export function getRouteStops(routeNo: string, fallbackOrigin: { lat: number; lng: number; name: string }): Stop[] {
  const stops = ROUTE_STOPS[routeNo.toUpperCase()]
  if (stops && stops.length > 0) return stops
  // Fallback: just origin + RIT Campus
  return [
    { name: fallbackOrigin.name, lat: fallbackOrigin.lat, lng: fallbackOrigin.lng },
    DESTINATION_STOP,
  ]
}
