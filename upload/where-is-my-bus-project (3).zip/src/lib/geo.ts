// Geo helpers: haversine distance, bearing, speed (km/h), ETA minutes.

export interface LatLng {
  lat: number
  lng: number
}

const EARTH_RADIUS_KM = 6371
const EARTH_RADIUS_M = 6371000

function toRad(deg: number): number {
  return (deg * Math.PI) / 180
}
function toDeg(rad: number): number {
  return (rad * 180) / Math.PI
}

/** Great-circle distance in km between two coordinates. */
export function haversineKm(a: LatLng, b: LatLng): number {
  const dLat = toRad(b.lat - a.lat)
  const dLng = toRad(b.lng - a.lng)
  const lat1 = toRad(a.lat)
  const lat2 = toRad(b.lat)
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)))
}

/** Distance in metres. */
export function haversineM(a: LatLng, b: LatLng): number {
  return haversineKm(a, b) * 1000
}

/** Initial bearing in degrees (0 = N, 90 = E). */
export function bearingDeg(a: LatLng, b: LatLng): number {
  const lat1 = toRad(a.lat)
  const lat2 = toRad(b.lat)
  const dLng = toRad(b.lng - a.lng)
  const y = Math.sin(dLng) * Math.cos(lat2)
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng)
  return (toDeg(Math.atan2(y, x)) + 360) % 360
}

/** Convert bearing to 8-point compass label. */
export function compassLabel(deg: number): string {
  const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
  return dirs[Math.round(deg / 45) % 8]
}

/** Convert km/h to a friendly speed string. */
export function formatSpeed(kmh: number | null | undefined): string {
  if (kmh == null || !isFinite(kmh) || kmh < 0) return "—"
  return `${kmh.toFixed(1)} km/h`
}

/** Convert km distance to a friendly string. */
export function formatDistance(km: number | null | undefined): string {
  if (km == null || !isFinite(km)) return "—"
  if (km < 1) return `${Math.round(km * 1000)} m`
  if (km < 10) return `${km.toFixed(2)} km`
  return `${km.toFixed(1)} km`
}

/** Convert minutes to "Xh Ym" or "Ym". */
export function formatDuration(min: number | null | undefined): string {
  if (min == null || !isFinite(min) || min < 0) return "—"
  if (min < 60) return `${Math.round(min)} min`
  const h = Math.floor(min / 60)
  const m = Math.round(min % 60)
  return `${h}h ${m}m`
}

/** Compute speed in km/h given two points and a time delta in ms. */
export function speedBetween(
  a: LatLng & { t?: number },
  b: LatLng & { t?: number }
): number | null {
  if (a.t == null || b.t == null) return null
  const dt = (b.t - a.t) / 1000 // seconds
  if (dt <= 0) return null
  const km = haversineKm(a, b)
  return (km / dt) * 3600
}

/**
 * Estimate ETA (minutes) from current position to destination,
 * given current speed in km/h and remaining distance in km.
 * Falls back to a default city speed of 18 km/h if no speed data.
 */
export function etaMinutes(
  remainingKm: number,
  speedKmh: number | null | undefined,
  fallbackKmh = 18
): number {
  const v = speedKmh && speedKmh > 0 ? speedKmh : fallbackKmh
  return (remainingKm / v) * 60
}

/**
 * Generate a sequence of intermediate positions between origin and destination.
 * Used by the OFFLINE (network tower / simulated GPS) mode to fake bus movement.
 * `steps` controls how many intermediate points to generate.
 */
export function interpolateRoute(
  origin: LatLng,
  dest: LatLng,
  steps: number
): LatLng[] {
  if (steps <= 0) return [origin]
  const pts: LatLng[] = []
  for (let i = 0; i <= steps; i++) {
    const t = i / steps
    // Simple linear interpolation — fine for short-to-medium distances.
    // For very long routes the great-circle path is essentially a straight line on a city map.
    pts.push({
      lat: origin.lat + (dest.lat - origin.lat) * t,
      lng: origin.lng + (dest.lng - origin.lng) * t,
    })
  }
  return pts
}

/** Compute progress percentage (0–100) from origin→current→dest. */
export function progressPct(origin: LatLng, current: LatLng, dest: LatLng): number {
  const total = haversineKm(origin, dest)
  if (total <= 0) return 100
  const remaining = haversineKm(current, dest)
  const done = Math.max(0, total - remaining)
  return Math.min(100, (done / total) * 100)
}

/**
 * Project a point onto a line segment a→b, returning the closest point on the segment.
 * Uses equirectangular approximation (good enough for city-scale distances).
 */
function closestPointOnSegment(p: LatLng, a: LatLng, b: LatLng): LatLng {
  const ax = a.lng * Math.cos(toRad((a.lat + b.lat) / 2))
  const ay = a.lat
  const bx = b.lng * Math.cos(toRad((a.lat + b.lat) / 2))
  const by = b.lat
  const px = p.lng * Math.cos(toRad((a.lat + b.lat) / 2))
  const py = p.lat
  const dx = bx - ax
  const dy = by - ay
  const len2 = dx * dx + dy * dy
  if (len2 <= 0) return a
  let t = ((px - ax) * dx + (py - ay) * dy) / len2
  t = Math.max(0, Math.min(1, t))
  return {
    lat: ay + dy * t,
    lng: (ax + dx * t) / Math.cos(toRad((a.lat + b.lat) / 2)),
  }
}

export interface NextStopResult {
  /** Index of the next stop in the stops array. */
  index: number
  /** The next stop object. */
  stop: LatLng & { name?: string }
  /** Distance from current position to the next stop, in km. */
  distanceKm: number
  /** ETA in minutes, given the speed. */
  etaMin: number
  /** Index of the segment the bus is currently on (between stops[segmentIdx] and stops[segmentIdx+1]). */
  segmentIdx: number
  /** True if bus is at/past the last stop. */
  arrived: boolean
}

/**
 * Given the bus's current position and an ordered list of stops,
 * find the NEXT stop the bus is heading towards and compute distance + ETA.
 *
 * Algorithm:
 * 1. Find the segment [stops[i], stops[i+1]] whose closest-point to the bus is nearest.
 * 2. If the bus's projection onto that segment is past the midpoint, next stop is stops[i+2].
 *    Otherwise next stop is stops[i+1].
 * 3. Special case: if the bus is very close to a stop (within ARRIVED_RADIUS_KM), that stop
 *    has been reached — the next stop is the one after.
 */
const ARRIVED_RADIUS_KM = 0.15 // 150m

export function findNextStop(
  current: LatLng,
  stops: (LatLng & { name?: string })[],
  speedKmh: number | null | undefined,
  fallbackKmh = 22
): NextStopResult | null {
  if (!stops || stops.length < 2) return null

  // First check: has the bus arrived at the final stop?
  const lastStop = stops[stops.length - 1]
  const distToLast = haversineKm(current, lastStop)
  if (distToLast < ARRIVED_RADIUS_KM) {
    return {
      index: stops.length - 1,
      stop: lastStop,
      distanceKm: distToLast,
      etaMin: 0,
      segmentIdx: stops.length - 2,
      arrived: true,
    }
  }

  // Find the segment the bus is on (smallest perpendicular distance).
  let bestSeg = 0
  let bestDist = Infinity
  let bestT = 0 // parameter t along segment [0,1]
  for (let i = 0; i < stops.length - 1; i++) {
    const a = stops[i]
    const b = stops[i + 1]
    const cp = closestPointOnSegment(current, a, b)
    const d = haversineKm(current, cp)
    if (d < bestDist) {
      bestDist = d
      bestSeg = i
      // recompute t for this segment
      const ax = a.lng * Math.cos(toRad((a.lat + b.lat) / 2))
      const ay = a.lat
      const bx = b.lng * Math.cos(toRad((a.lat + b.lat) / 2))
      const by = b.lat
      const px = current.lng * Math.cos(toRad((a.lat + b.lat) / 2))
      const py = current.lat
      const dx = bx - ax
      const dy = by - ay
      const len2 = dx * dx + dy * dy
      bestT = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0
      bestT = Math.max(0, Math.min(1, bestT))
    }
  }

  // Check if the bus is within ARRIVED_RADIUS of stops[bestSeg] or stops[bestSeg+1]
  const distToA = haversineKm(current, stops[bestSeg])
  const distToB = haversineKm(current, stops[bestSeg + 1])

  let nextIdx: number
  if (distToB < ARRIVED_RADIUS_KM) {
    // Already reached stops[bestSeg+1], so next is the one after
    nextIdx = Math.min(stops.length - 1, bestSeg + 2)
  } else if (distToA < ARRIVED_RADIUS_KM) {
    // Already reached stops[bestSeg], next is stops[bestSeg+1]
    nextIdx = bestSeg + 1
  } else {
    // Bus is between stops[bestSeg] and stops[bestSeg+1].
    // If projection is past 50% of the segment, next stop is bestSeg+2.
    // Otherwise next is bestSeg+1.
    nextIdx = bestT > 0.5 ? Math.min(stops.length - 1, bestSeg + 2) : bestSeg + 1
  }

  // Safety: don't return an index beyond the last stop
  if (nextIdx >= stops.length) nextIdx = stops.length - 1

  const nextStop = stops[nextIdx]
  const distanceKm = haversineKm(current, nextStop)
  const etaMin = etaMinutes(distanceKm, speedKmh, fallbackKmh)
  return {
    index: nextIdx,
    stop: nextStop,
    distanceKm,
    etaMin,
    segmentIdx: bestSeg,
    arrived: nextIdx === stops.length - 1 && distToLast < ARRIVED_RADIUS_KM,
  }
}

/**
 * Compute ETAs for all upcoming stops (including the next one).
 * Returns an array of { stop, distanceKm, etaMin } for stops ahead of the bus.
 */
export function upcomingStops(
  current: LatLng,
  stops: (LatLng & { name?: string })[],
  speedKmh: number | null | undefined,
  fallbackKmh = 22
): Array<{ stop: LatLng & { name?: string }; distanceKm: number; etaMin: number; index: number }> {
  const next = findNextStop(current, stops, speedKmh, fallbackKmh)
  if (!next) return []
  const result: Array<{ stop: LatLng & { name?: string }; distanceKm: number; etaMin: number; index: number }> = []
  // ETA for the immediate next stop uses current speed
  let cumEta = next.etaMin
  result.push({ stop: next.stop, distanceKm: next.distanceKm, etaMin: next.etaMin, index: next.index })

  // For subsequent stops, use the fallback speed and accumulate ETA from the next stop
  for (let i = next.index + 1; i < stops.length; i++) {
    const prev = stops[i - 1]
    const stop = stops[i]
    const segKm = haversineKm(prev, stop)
    const segEta = etaMinutes(segKm, speedKmh, fallbackKmh)
    cumEta += segEta
    result.push({ stop, distanceKm: segKm, etaMin: cumEta, index: i })
  }
  return result
}
