// All 52 Chennai college bus routes.
// ALL buses go TO RIT Campus (Rajalakshmi Institute of Technology).
// Each route starts at a different boarding point (neighborhood) across Chennai.
// Coordinates are approximate area centroids — accurate enough for haversine distance & ETA.

export interface BusRoute {
  sno: number
  routeNo: string
  routeName: string
  timing: string
  startingTime: string | null
  // START coordinates (the boarding point where the bus begins)
  startLat: number
  startLng: number
  // DESTINATION coordinates — RIT Campus (same for all routes)
  destLat: number
  destLng: number
  // Estimated route distance (km) — used for ETA fallback when no live data
  estDistanceKm: number
  // Approx route duration (minutes) used for ETA fallback
  estDurationMin: number
}

// RIT Campus — Rajalakshmi Institute of Technology, Outer Ring Road, Kuthambakkam, Chennai
export const RIT_CAMPUS = { lat: 13.0430, lng: 80.0450, name: "RIT Campus" }

// Default destination for ALL routes
const DEST = { lat: RIT_CAMPUS.lat, lng: RIT_CAMPUS.lng }

// Legacy alias (kept for backward compatibility — same as RIT_CAMPUS now)
export const CHENNAI_ORIGIN = RIT_CAMPUS

export const BUS_ROUTES: BusRoute[] = [
  { sno: 1, routeNo: "R01", routeName: "Ennore", timing: "", startingTime: null, startLat: 13.2202, startLng: 80.3094, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 45, estDurationMin: 95 },
  { sno: 2, routeNo: "R01A", routeName: "Tondiarpet", timing: "", startingTime: null, startLat: 13.1296, startLng: 80.2924, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 35, estDurationMin: 75 },
  { sno: 3, routeNo: "R01B", routeName: "Kasimedum", timing: "", startingTime: null, startLat: 13.0827, startLng: 80.2707, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 30, estDurationMin: 65 },
  { sno: 4, routeNo: "R02", routeName: "Triplicane", timing: "Boarding Points", startingTime: "6.20 am", startLat: 13.0569, startLng: 80.275, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 28, estDurationMin: 60 },
  { sno: 5, routeNo: "R03", routeName: "Choolai", timing: "Boarding Points", startingTime: "6.20 am", startLat: 13.0851, startLng: 80.267, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 30, estDurationMin: 65 },
  { sno: 6, routeNo: "R03A", routeName: "Collector Nagar", timing: "Boarding Points", startingTime: "6.50 am", startLat: 13.0723, startLng: 80.2108, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 18, estDurationMin: 40 },
  { sno: 7, routeNo: "R03B", routeName: "Water Tank", timing: "Boarding Points", startingTime: "6.40 am", startLat: 13.085, startLng: 80.2108, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 18, estDurationMin: 40 },
  { sno: 8, routeNo: "R04", routeName: "East Mogappair", timing: "Boarding Points", startingTime: "6.30 am", startLat: 13.09, startLng: 80.18, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 16, estDurationMin: 35 },
  { sno: 9, routeNo: "R05", routeName: "CIT Nagar", timing: "Boarding Points", startingTime: "6.10 am", startLat: 13.029, startLng: 80.233, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 25, estDurationMin: 55 },
  { sno: 10, routeNo: "R05A", routeName: "Loyola College", timing: "Boarding Points", startingTime: "6.40 am", startLat: 13.0878, startLng: 80.2217, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 22, estDurationMin: 50 },
  { sno: 11, routeNo: "R06", routeName: "Chinmayanagar", timing: "Boarding Points", startingTime: "6.10 am", startLat: 13.0725, startLng: 80.15, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 12, estDurationMin: 28 },
  { sno: 12, routeNo: "R07", routeName: "Santhome", timing: "Boarding Points", startingTime: "6.10 am", startLat: 13.0504, startLng: 80.2772, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 30, estDurationMin: 65 },
  { sno: 13, routeNo: "R08", routeName: "Kovilambakkam", timing: "Boarding Points", startingTime: "6.10 am", startLat: 12.9166, startLng: 80.208, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 25, estDurationMin: 55 },
  { sno: 14, routeNo: "R08A", routeName: "Adambakkam", timing: "Boarding Points", startingTime: "6.30 am", startLat: 12.9859, startLng: 80.2059, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 22, estDurationMin: 50 },
  { sno: 15, routeNo: "R09", routeName: "MKB Nagar", timing: "Boarding Points", startingTime: "6.00 am", startLat: 13.1258, startLng: 80.253, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 35, estDurationMin: 75 },
  { sno: 16, routeNo: "R10", routeName: "Thachoor", timing: "Boarding Points", startingTime: "5.50 am", startLat: 13.355, startLng: 80.045, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 38, estDurationMin: 80 },
  { sno: 17, routeNo: "R11", routeName: "Chengalpattu", timing: "Boarding Points", startingTime: "6.00 am", startLat: 12.6914, startLng: 79.975, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 55, estDurationMin: 110 },
  { sno: 18, routeNo: "R11A", routeName: "Guduvanchery", timing: "Boarding Points", startingTime: "6.30 am", startLat: 12.846, startLng: 80.052, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 45, estDurationMin: 90 },
  { sno: 19, routeNo: "R12", routeName: "Minjur", timing: "Boarding Points", startingTime: "5.45 am", startLat: 13.278, startLng: 80.322, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 55, estDurationMin: 115 },
  { sno: 20, routeNo: "R13", routeName: "Vyasarpadi", timing: "Boarding Points", startingTime: "6.10 am", startLat: 13.118, startLng: 80.247, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 32, estDurationMin: 70 },
  { sno: 21, routeNo: "R13A", routeName: "ICF", timing: "Boarding Points", startingTime: "6.45 am", startLat: 13.107, startLng: 80.243, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 30, estDurationMin: 65 },
  { sno: 22, routeNo: "R14", routeName: "Thiruvallur", timing: "Boarding Points", startingTime: "6.25 am", startLat: 13.128, startLng: 79.901, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 35, estDurationMin: 75 },
  { sno: 23, routeNo: "R14B", routeName: "Kakkalur", timing: "Boarding Points", startingTime: "6.55 am", startLat: 13.115, startLng: 79.88, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 38, estDurationMin: 80 },
  { sno: 24, routeNo: "R15", routeName: "Cheyyar", timing: "Boarding Points", startingTime: "5.30 am", startLat: 12.658, startLng: 79.546, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 95, estDurationMin: 160 },
  { sno: 25, routeNo: "R15A", routeName: "Orikkai", timing: "Boarding Points", startingTime: "6.15 am", startLat: 12.838, startLng: 79.695, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 70, estDurationMin: 125 },
  { sno: 26, routeNo: "R15B", routeName: "Kancheepuram", timing: "Boarding Points", startingTime: "6.25 am", startLat: 12.838, startLng: 79.704, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 65, estDurationMin: 115 },
  { sno: 27, routeNo: "R16", routeName: "Neelangkarai", timing: "Boarding Points", startingTime: "6.10 am", startLat: 12.944, startLng: 80.233, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 30, estDurationMin: 65 },
  { sno: 28, routeNo: "R16B", routeName: "Sholinganallur", timing: "Boarding Points", startingTime: "6.10 am", startLat: 12.901, startLng: 80.227, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 35, estDurationMin: 75 },
  { sno: 29, routeNo: "R17", routeName: "Valluvarkottam", timing: "Boarding Points", startingTime: "6.15 am", startLat: 13.052, startLng: 80.244, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 25, estDurationMin: 55 },
  { sno: 30, routeNo: "R17A", routeName: "Valasaravakkam", timing: "Boarding Points", startingTime: "6.45 am", startLat: 13.053, startLng: 80.171, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 14, estDurationMin: 32 },
  { sno: 31, routeNo: "R18", routeName: "Velachery", timing: "Boarding Points", startingTime: "6.10 am", startLat: 12.979, startLng: 80.221, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 25, estDurationMin: 55 },
  { sno: 32, routeNo: "R18A", routeName: "Sembakkam", timing: "Boarding Points", startingTime: "6.25 am", startLat: 12.923, startLng: 80.141, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 28, estDurationMin: 60 },
  { sno: 33, routeNo: "R18B", routeName: "Kelambakkam", timing: "Boarding Points", startingTime: "6.00 am", startLat: 12.795, startLng: 80.218, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 40, estDurationMin: 85 },
  { sno: 34, routeNo: "R19", routeName: "Poombukar", timing: "Boarding Points", startingTime: "6.10 am", startLat: 11.143, startLng: 79.843, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 230, estDurationMin: 320 },
  { sno: 35, routeNo: "R19A", routeName: "Vinayagapuram", timing: "Boarding Points", startingTime: "6.45 am", startLat: 13.125, startLng: 80.267, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 32, estDurationMin: 68 },
  { sno: 36, routeNo: "R20", routeName: "Veppampattu", timing: "Boarding Points", startingTime: "6.35 am", startLat: 13.085, startLng: 79.938, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 20, estDurationMin: 45 },
  { sno: 37, routeNo: "R20A", routeName: "Pattabiram", timing: "Boarding Points", startingTime: "6.45 am", startLat: 13.111, startLng: 79.947, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 18, estDurationMin: 40 },
  { sno: 38, routeNo: "R21", routeName: "Ayappakkam", timing: "Boarding Points", startingTime: "6.20 am", startLat: 13.115, startLng: 80.07, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 12, estDurationMin: 28 },
  { sno: 39, routeNo: "R22", routeName: "Thiruthani", timing: "Boarding Points", startingTime: "5.55 am", startLat: 13.175, startLng: 79.616, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 75, estDurationMin: 130 },
  { sno: 40, routeNo: "R22A", routeName: "Sholinghur", timing: "Boarding Points", startingTime: "5.35 am", startLat: 13.118, startLng: 79.425, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 100, estDurationMin: 170 },
  { sno: 41, routeNo: "R23", routeName: "K4 Police Station", timing: "Boarding Points", startingTime: "6.35 am", startLat: 13.052, startLng: 80.252, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 28, estDurationMin: 60 },
  { sno: 42, routeNo: "R24", routeName: "Arcot", timing: "Boarding Points", startingTime: "5.20 am", startLat: 12.908, startLng: 79.33, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 115, estDurationMin: 190 },
  { sno: 43, routeNo: "R25", routeName: "Kallikuppam", timing: "Boarding Points", startingTime: "6.40 am", startLat: 13.148, startLng: 80.095, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 15, estDurationMin: 35 },
  { sno: 44, routeNo: "R25A", routeName: "Kavangarai", timing: "Boarding Points", startingTime: "6.15 am", startLat: 13.115, startLng: 80.09, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 14, estDurationMin: 32 },
  { sno: 45, routeNo: "R26", routeName: "Andarkuppam", timing: "Boarding Points", startingTime: "6.35 am", startLat: 13.57, startLng: 80.195, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 65, estDurationMin: 120 },
  { sno: 46, routeNo: "R26A", routeName: "Poonamallee", timing: "Boarding Points", startingTime: "7.30 am", startLat: 13.046, startLng: 80.105, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 7, estDurationMin: 18 },
  { sno: 47, routeNo: "R27", routeName: "Avadi Checkpost", timing: "Boarding Points", startingTime: "7.05 am", startLat: 13.116, startLng: 80.08, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 14, estDurationMin: 32 },
  { sno: 48, routeNo: "R27A", routeName: "Kollumedu", timing: "Boarding Points", startingTime: "6.20 am", startLat: 13.088, startLng: 79.97, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 20, estDurationMin: 45 },
  { sno: 49, routeNo: "R28", routeName: "Agaram", timing: "Boarding Points", startingTime: "6.20 am", startLat: 13.142, startLng: 80.205, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 32, estDurationMin: 68 },
  { sno: 50, routeNo: "R29", routeName: "Medavakkam Koot Road", timing: "Boarding Points", startingTime: "6.20 am", startLat: 12.918, startLng: 80.195, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 28, estDurationMin: 60 },
  { sno: 51, routeNo: "R29A", routeName: "Pammal", timing: "Boarding Points", startingTime: "6.35 am", startLat: 12.957, startLng: 80.09, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 20, estDurationMin: 45 },
  { sno: 52, routeNo: "R29B", routeName: "Sivanthangal", timing: "Boarding Points", startingTime: null, startLat: 12.943, startLng: 80.083, destLat: DEST.lat, destLng: DEST.lng, estDistanceKm: 18, estDurationMin: 40 },
]

export function getRouteByNo(routeNo: string): BusRoute | undefined {
  return BUS_ROUTES.find((r) => r.routeNo.toLowerCase() === routeNo.toLowerCase())
}

export function searchRoutes(query: string): BusRoute[] {
  const q = query.trim().toLowerCase()
  if (!q) return BUS_ROUTES
  return BUS_ROUTES.filter(
    (r) =>
      r.routeNo.toLowerCase().includes(q) ||
      r.routeName.toLowerCase().includes(q)
  )
}
