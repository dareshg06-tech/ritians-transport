// Bus fleet data — each bus has a number, plate, and is assigned to a route.
// The driver selects a bus (not just a route), and the route is derived from the bus assignment.

import type { BusRoute } from "./bus-routes"
import { BUS_ROUTES } from "./bus-routes"

export interface Bus {
  busNo: string // e.g. "BUS 05"
  plate: string // e.g. "TN 01 AB 1234"
  routeNo: string // e.g. "R11"
  capacity: number
  driverName: string
  // Optional: driver avatar URL
  driverAvatar?: string
}

// Sample fleet — driver picks from this list
export const BUS_FLEET: Bus[] = [
  { busNo: "BUS 01", plate: "TN 01 AB 1234", routeNo: "R01", capacity: 52, driverName: "Assigned Driver" },
  { busNo: "BUS 02", plate: "TN 01 BC 5678", routeNo: "R02", capacity: 52, driverName: "Assigned Driver" },
  { busNo: "BUS 03", plate: "TN 22 CD 9012", routeNo: "R03", capacity: 48, driverName: "Assigned Driver" },
  { busNo: "BUS 04", plate: "TN 22 EF 3456", routeNo: "R04", capacity: 48, driverName: "Assigned Driver" },
  { busNo: "BUS 05", plate: "TN 01 GH 7890", routeNo: "R11", capacity: 52, driverName: "Assigned Driver" },
  { busNo: "BUS 06", plate: "TN 01 IJ 1122", routeNo: "R12", capacity: 52, driverName: "Assigned Driver" },
  { busNo: "BUS 07", plate: "TN 22 KL 3344", routeNo: "R14", capacity: 48, driverName: "Assigned Driver" },
  { busNo: "BUS 08", plate: "TN 22 MN 5566", routeNo: "R16B", capacity: 52, driverName: "Assigned Driver" },
  { busNo: "BUS 09", plate: "TN 01 OP 7788", routeNo: "R18", capacity: 48, driverName: "Assigned Driver" },
  { busNo: "BUS 10", plate: "TN 01 QR 9900", routeNo: "R22", capacity: 52, driverName: "Assigned Driver" },
  { busNo: "BUS 11", plate: "TN 22 ST 1234", routeNo: "R26A", capacity: 48, driverName: "Assigned Driver" },
  { busNo: "BUS 12", plate: "TN 22 UV 5678", routeNo: "R29", capacity: 52, driverName: "Assigned Driver" },
]

export function getBusRoute(bus: Bus): BusRoute | undefined {
  return BUS_ROUTES.find((r) => r.routeNo === bus.routeNo)
}

export function getBusByNo(busNo: string): Bus | undefined {
  return BUS_FLEET.find((b) => b.busNo.toLowerCase() === busNo.toLowerCase())
}
