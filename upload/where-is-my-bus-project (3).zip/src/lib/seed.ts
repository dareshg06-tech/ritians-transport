import { db } from "@/lib/db"

// Pre-defined driver accounts. In production these would come from an admin panel.
export const SEED_DRIVERS = [
  { id: "DRIVER-001", name: "Ramesh Kumar", phone: "+91 98765 43210", licenseNo: "TN0120190000123", avatarColor: "#06b6d4" },
  { id: "DRIVER-002", name: "Suresh Babu", phone: "+91 98765 43211", licenseNo: "TN0120190000124", avatarColor: "#10b981" },
  { id: "DRIVER-003", name: "Anand Raj", phone: "+91 98765 43212", licenseNo: "TN0120190000125", avatarColor: "#f59e0b" },
  { id: "DRIVER-004", name: "Mohan Das", phone: "+91 98765 43213", licenseNo: "TN0120190000126", avatarColor: "#ef4444" },
]

export async function ensureSeedDrivers() {
  try {
    const count = await db.driver.count()
    if (count === 0) {
      await db.driver.createMany({ data: SEED_DRIVERS })
      console.log(`[seed] Inserted ${SEED_DRIVERS.length} drivers`)
    }
  } catch (e) {
    console.error("[seed] failed:", e)
  }
}
