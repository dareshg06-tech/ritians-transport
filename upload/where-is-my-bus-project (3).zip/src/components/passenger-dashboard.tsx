"use client"

import dynamic from "next/dynamic"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Activity,
  AlertTriangle,
  Bus as BusIcon,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Compass,
  Crosshair,
  Flag,
  Gauge,
  LayoutDashboard,
  Locate,
  MapPin,
  Map as MapIcon,
  Navigation,
  Radio,
  Satellite,
  Signal,
  Square,
  Wifi,
  WifiOff,
  X,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import {
  BUS_ROUTES,
  CHENNAI_ORIGIN,
  searchRoutes,
  type BusRoute,
} from "@/lib/bus-routes"
import {
  bearingDeg,
  compassLabel,
  etaMinutes,
  findNextStop,
  formatDistance,
  formatDuration,
  formatSpeed,
  haversineKm,
  interpolateRoute,
  progressPct,
  upcomingStops,
  type LatLng,
} from "@/lib/geo"
import { getRouteStops, type Stop } from "@/lib/route-stops"
import { usePassengerTracking } from "@/hooks/use-bus-socket"

const BusMap = dynamic(() => import("@/components/bus-map"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-72 rounded-2xl bg-[#0a0d18] border border-[#1a2032] flex items-center justify-center">
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <Satellite className="w-4 h-4 animate-pulse" /> Loading map…
      </div>
    </div>
  ),
})

interface PassengerDashboardProps {
  mode: 'online' | 'offline'
}

function greeting(): string {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

function formatETA(min: number): string {
  const eta = new Date(Date.now() + min * 60_000)
  return eta.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

export default function PassengerDashboard({ mode }: PassengerDashboardProps) {
  const [selected, setSelected] = useState<BusRoute | null>(null)
  const [userLoc, setUserLoc] = useState<LatLng | null>(null)
  const [simBus, setSimBus] = useState<LatLng & { t?: number; speedKmh?: number; heading?: number } | null>(null)
  const [follow, setFollow] = useState(true)
  const [view, setView] = useState<'dashboard' | 'map'>('dashboard')
  // Student's chosen boarding point (index into the stops array)
  const [boardingPointIdx, setBoardingPointIdx] = useState<number>(0)
  const [boardingPickerOpen, setBoardingPickerOpen] = useState(false)
  // Track whether the student has manually chosen a boarding point (vs auto-selected)
  const [boardingManuallySet, setBoardingManuallySet] = useState(false)
  const simIdxRef = useRef(0)
  const simTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Online: subscribe to live driver updates
  const {
    location: liveLoc,
    status,
    trip,
    nextStop: serverNextStop,
    busInfo,
  } = usePassengerTracking(selected && mode === 'online' ? selected.routeNo : null)

  // Load saved boarding point for this route from localStorage
  useEffect(() => {
    if (!selected) return
    try {
      const saved = localStorage.getItem(`wmb_boarding_${selected.routeNo}`)
      if (saved != null) {
        const idx = parseInt(saved, 10)
        if (!isNaN(idx) && idx >= 0) {
          setBoardingPointIdx(idx)
          setBoardingManuallySet(true) // student has a saved preference
        }
      } else {
        // Default to stop 1 (the first intermediate stop, not the origin)
        setBoardingPointIdx(Math.min(1, 0))
        setBoardingManuallySet(false) // no manual preference yet
      }
    } catch {
      setBoardingPointIdx(0)
      setBoardingManuallySet(false)
    }
  }, [selected])

  // Save boarding point to localStorage ONLY when the student manually changes it
  const selectBoardingPoint = useCallback((idx: number) => {
    setBoardingPointIdx(idx)
    setBoardingManuallySet(true)
    if (selected) {
      try {
        localStorage.setItem(`wmb_boarding_${selected.routeNo}`, String(idx))
      } catch { /* ignore */ }
    }
  }, [selected])

  // Track user location (works in both modes)
  useEffect(() => {
    if (!navigator.geolocation) return
    const id = navigator.geolocation.watchPosition(
      (pos) => setUserLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => {},
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
    )
    return () => navigator.geolocation.clearWatch(id)
  }, [])

  // Origin = the boarding point (startLat/startLng); Destination = RIT Campus (destLat/destLng)
  const routeStart: LatLng = selected ? { lat: selected.startLat, lng: selected.startLng } : { lat: 13.0827, lng: 80.2707 }
  const dest: LatLng = selected ? { lat: selected.destLat, lng: selected.destLng } : routeStart

  // OFFLINE mode: simulate bus moving along the route
  useEffect(() => {
    if (mode !== 'offline' || !selected) {
      const t = setTimeout(() => setSimBus(null), 0)
      if (simTimerRef.current) clearInterval(simTimerRef.current)
      return () => clearTimeout(t)
    }
    const path = interpolateRoute(routeStart, { lat: selected.destLat, lng: selected.destLng }, 80)
    simIdxRef.current = Math.floor(path.length * 0.25)
    const t0 = setTimeout(() => {
      setSimBus({ ...path[simIdxRef.current], t: Date.now(), speedKmh: 0, heading: 0 })
    }, 0)
    simTimerRef.current = setInterval(() => {
      setSimBus((prev) => {
        if (!prev) return prev
        const nextIdx = Math.min(path.length - 1, simIdxRef.current + 1)
        simIdxRef.current = nextIdx
        const next = path[nextIdx]
        const speed = nextIdx === path.length - 1 ? 0 : 18 + Math.random() * 12
        const heading = bearingDeg(prev, next)
        return { ...next, t: Date.now(), speedKmh: speed, heading }
      })
    }, 2000)
    return () => {
      clearTimeout(t0)
      if (simTimerRef.current) clearInterval(simTimerRef.current)
    }
  }, [mode, selected])

  const busLoc: (LatLng & { speedKmh?: number; heading?: number; t?: number }) | null =
    mode === 'online' ? liveLoc : simBus

  const stops: Stop[] = useMemo(() => {
    if (!selected) return []
    return getRouteStops(selected.routeNo, { name: selected.routeName, lat: selected.startLat, lng: selected.startLng })
  }, [selected])

  // Compute stats + next stop locally (in offline mode or as fallback)
  const localNextStop = useMemo(() => {
    if (!busLoc || stops.length === 0) return null
    const speed = (busLoc as { speedKmh?: number })?.speedKmh ?? null
    return findNextStop(busLoc, stops, speed, 22)
  }, [busLoc, stops])

  // In online mode prefer server-pushed next stop, else use local computation
  const nextStop = mode === 'online' && serverNextStop ? {
    index: serverNextStop.stopIndex,
    stop: { name: serverNextStop.stopName, lat: 0, lng: 0 } as Stop,
    distanceKm: serverNextStop.distanceKm,
    etaMin: serverNextStop.etaMin,
    arrived: serverNextStop.arrived,
    segmentIdx: Math.max(0, serverNextStop.stopIndex - 1),
  } : localNextStop

  // Auto-update boarding point to the next upcoming stop if the bus has passed it
  // (only if the student hasn't manually selected a stop)
  useEffect(() => {
    if (!selected || !busLoc || !nextStop || stops.length === 0) return
    if (boardingManuallySet) return // student has manually chosen, don't auto-change
    // No manual preference — auto-select the next upcoming stop
    if (boardingPointIdx < nextStop.index) {
      setBoardingPointIdx(nextStop.index)
    }
  }, [selected, busLoc, nextStop, stops, boardingPointIdx, boardingManuallySet])

  const stats = useMemo(() => {
    if (!selected) return null
    if (!busLoc) {
      return {
        distanceToBus: null as number | null,
        distanceToDest: selected.estDistanceKm,
        etaMin: selected.estDurationMin,
        speed: null as number | null,
        heading: 0,
        progress: 0,
      }
    }
    const distanceToBus = userLoc ? haversineKm(userLoc, busLoc) : null
    const distanceToDest = haversineKm(busLoc, dest)
    const speed = (busLoc as { speedKmh?: number })?.speedKmh ?? null
    const heading = (busLoc as { heading?: number })?.heading ?? bearingDeg(busLoc, dest)
    const eta = etaMinutes(distanceToDest, speed, 22)
    const progress = progressPct(routeStart, busLoc, dest)
    return {
      distanceToBus,
      distanceToDest,
      etaMin: eta,
      speed,
      heading,
      progress,
    }
  }, [selected, busLoc, userLoc, dest])

  const upcoming = useMemo(() => {
    if (!busLoc || stops.length === 0) return []
    const speed = (busLoc as { speedKmh?: number })?.speedKmh ?? null
    return upcomingStops(busLoc, stops, speed, 22)
  }, [busLoc, stops])

  // === Student's boarding point info ===
  const boardingStop = stops[boardingPointIdx] || null
  // ETA to the student's boarding point
  const boardingInfo = useMemo(() => {
    if (!busLoc || !boardingStop || stops.length === 0) return null
    const speed = (busLoc as { speedKmh?: number })?.speedKmh ?? null
    // Find the boarding point in the upcoming stops list
    const upcomingEntry = upcoming.find((u) => u.index === boardingPointIdx)
    if (upcomingEntry) {
      return {
        stop: boardingStop,
        distanceKm: upcomingEntry.distanceKm,
        etaMin: upcomingEntry.etaMin,
        status: 'upcoming' as const, // bus hasn't reached this stop yet
      }
    }
    // Check if the bus has already passed this stop
    if (nextStop && boardingPointIdx < nextStop.index) {
      return {
        stop: boardingStop,
        distanceKm: 0,
        etaMin: 0,
        status: 'passed' as const, // bus already passed this stop
      }
    }
    // Check if the bus is currently at this stop
    if (nextStop && boardingPointIdx === nextStop.index) {
      return {
        stop: boardingStop,
        distanceKm: nextStop.distanceKm,
        etaMin: nextStop.etaMin,
        status: nextStop.arrived ? 'arrived' as const : 'arriving' as const,
      }
    }
    return null
  }, [busLoc, boardingStop, stops, upcoming, boardingPointIdx, nextStop])

  const online = mode === 'online'
  const isLive = online && status === 'online'

  // Live "seconds ago" ticker for last update
  const [, setTick] = useState(0)
  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 1000)
    return () => clearInterval(i)
  }, [])
  const lastUpdateMs = (liveLoc as { timestamp?: number } | null)?.timestamp ?? null
  const secondsAgo = lastUpdateMs ? Math.floor((Date.now() - lastUpdateMs) / 1000) : null

  // System status
  const sysStatus = useMemo(() => ({
    gps: !!userLoc,
    network: typeof navigator !== 'undefined' ? navigator.onLine : true,
    server: online ? (status !== 'connecting') : true,
    liveLocation: isLive, // bus live location ON/OFF
    tracking: isLive,
  }), [userLoc, online, status, isLive])

  // === Full-screen map view ===
  if (view === 'map') {
    return (
      <div className="fixed inset-0 z-50 bg-[#0a0d18] flex flex-col">
        <div className="flex items-center justify-between p-3 bg-[#0a0d18]/95 backdrop-blur border-b border-[#1a2032]">
          <Button variant="ghost" onClick={() => setView('dashboard')} className="text-cyan-300 hover:bg-cyan-500/10">
            <ChevronDown className="w-4 h-4 mr-1" /> Back
          </Button>
          <div className="flex items-center gap-2">
            {isLive ? (
              <Badge variant="outline" className="border-emerald-500/40 bg-emerald-500/10 text-emerald-300 gap-1.5">
                <span className="relative inline-flex w-2 h-2"><span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" /><span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-400" /></span>
                LIVE • {secondsAgo ?? 0}s ago
              </Badge>
            ) : online ? (
              <Badge variant="outline" className="border-red-500/40 bg-red-500/10 text-red-300 gap-1.5">
                <WifiOff className="w-3 h-3" /> NO DRIVER
              </Badge>
            ) : (
              <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300 gap-1.5">
                <Satellite className="w-3 h-3" /> SIMULATED
              </Badge>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFollow((f) => !f)}
              className={cn("border-[#1a2032]", follow ? "bg-cyan-500/10 text-cyan-300 border-cyan-500/40" : "text-slate-400")}
            >
              <Locate className="w-3.5 h-3.5 mr-1" /> {follow ? 'Following' : 'Manual'}
            </Button>
          </div>
        </div>
        <div className="flex-1 relative">
          {selected && (
            <BusMap
              origin={routeStart}
              destination={dest}
              bus={busLoc}
              user={userLoc}
              routeLabel={`${selected.routeNo} ${selected.routeName} → RIT Campus`}
              followBus={follow}
              className="w-full h-full"
            />
          )}
        </div>
        {/* Floating speed + next stop card */}
        {busLoc && (
          <div className="absolute bottom-4 left-4 right-4 sm:left-4 sm:right-auto sm:w-80 rounded-2xl bg-[#0a0d18]/95 backdrop-blur border border-[#1a2032] p-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold mb-0.5">Speed</div>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-white tabular-nums leading-none">
                    {stats?.speed != null ? Math.round(stats.speed) : '—'}
                  </span>
                  <span className="text-[10px] text-slate-400">km/h</span>
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-widest text-amber-400 font-bold mb-0.5">Next stop</div>
                <div className="text-sm font-bold text-white truncate">
                  {nextStop?.stop.name || '—'}
                </div>
                <div className="text-[10px] text-emerald-300 tabular-nums">
                  {nextStop ? `${Math.max(0, Math.ceil(nextStop.etaMin))} min` : '—'}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {/* =================== Passenger Header =================== */}
      <div className="flex items-center justify-between gap-3 pt-1 pb-2">
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-widest text-emerald-400 font-bold">Find My Bus</div>
          <h2 className="text-lg font-bold text-white leading-tight mt-0.5 truncate">
            {greeting()}, Student
          </h2>
          <div className="text-[10px] text-slate-500">Live bus tracking for Chennai routes</div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {isLive ? (
            <Badge variant="outline" className="border-emerald-500/40 bg-emerald-500/10 text-emerald-300 gap-1.5">
              <span className="relative inline-flex w-2 h-2">
                <span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" />
                <span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-400" />
              </span>
              LIVE
            </Badge>
          ) : online && status === 'offline' ? (
            <Badge variant="outline" className="border-red-500/40 bg-red-500/10 text-red-300 gap-1.5">
              <WifiOff className="w-3 h-3" /> NO DRIVER
            </Badge>
          ) : online ? (
            <Badge variant="outline" className="border-slate-600 bg-slate-700/30 text-slate-400 gap-1.5">
              <Activity className="w-3 h-3 animate-pulse" /> CONNECTING
            </Badge>
          ) : (
            <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300 gap-1.5">
              <Satellite className="w-3 h-3" /> SIMULATED
            </Badge>
          )}
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-sm font-bold">
            S
          </div>
        </div>
      </div>

      {/* =================== Tracking Status Banner =================== */}
      {selected && isLive && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-emerald-500/40 bg-gradient-to-r from-emerald-500/15 via-emerald-500/10 to-transparent p-3 flex items-center gap-3"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
            <span className="relative inline-flex w-3 h-3">
              <span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" />
              <span className="relative inline-flex w-3 h-3 rounded-full bg-emerald-400" />
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold text-emerald-300">TRACKING ON</div>
            <div className="text-[11px] text-slate-400">
              Bus is live • updated {secondsAgo ?? 0}s ago {busInfo.busNo && `• ${busInfo.busNo}`}
            </div>
          </div>
          {stats?.speed != null && (
            <div className="text-right flex-shrink-0">
              <div className="text-lg font-black text-white tabular-nums leading-none">{Math.round(stats.speed)}</div>
              <div className="text-[9px] text-slate-500">km/h</div>
            </div>
          )}
        </motion.div>
      )}

      {/* =================== Route Selector =================== */}
      {!selected && (
        <RouteSelector selectedRoute={selected} onSelect={setSelected} />
      )}

      {/* =================== Selected route status bar =================== */}
      <AnimatePresence>
        {selected && (
          <motion.div
            key="detail"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="space-y-3"
          >
            {/* Status bar */}
            <div className="flex items-center justify-between rounded-xl border border-[#1a2032] bg-[#10131f] px-4 py-3">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  onClick={() => setSelected(null)}
                  className="text-slate-400 hover:text-cyan-300 flex-shrink-0"
                  aria-label="Change route"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" />
                </button>
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0",
                  "bg-[#1a2032] text-amber-300"
                )}>
                  {selected.routeNo}
                </div>
                <div className="min-w-0">
                  <div className="font-semibold text-sm text-slate-100 truncate">{selected.routeName} → RIT Campus</div>
                  <div className="text-[11px] text-slate-500 truncate">
                    {selected.startingTime ? `Started ${selected.startingTime}` : 'No fixed schedule'} • {selected.estDistanceKm} km to RIT
                    {online && busInfo.busNo && (
                      <span className="text-cyan-400"> • {busInfo.busNo} {busInfo.plate ? `(${busInfo.plate})` : ''}</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                {online ? (
                  status === 'online' ? (
                    <Badge variant="outline" className="border-emerald-500/40 bg-emerald-500/10 text-emerald-300 gap-1.5">
                      <span className="relative inline-flex w-2 h-2"><span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" /><span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-400" /></span>
                      LIVE
                    </Badge>
                  ) : status === 'offline' ? (
                    <Badge variant="outline" className="border-red-500/40 bg-red-500/10 text-red-300 gap-1.5">
                      <Square className="w-3 h-3" /> NO DRIVER
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="border-slate-600 bg-slate-700/30 text-slate-400 gap-1.5">
                      <Activity className="w-3 h-3 animate-pulse" /> CONNECTING
                    </Badge>
                  )
                ) : (
                  <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300 gap-1.5">
                    <Satellite className="w-3 h-3" /> SIMULATED
                  </Badge>
                )}
                {online && trip && (
                  <Badge variant="outline" className={cn(
                    "text-[9px] px-1.5 py-0 h-4",
                    trip.status === 'active'
                      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                      : trip.status === 'emergency'
                        ? "border-red-500/40 bg-red-500/10 text-red-300"
                        : "border-slate-600 bg-slate-700/30 text-slate-400"
                  )}>
                    {trip.status === 'active' ? 'TRIP ACTIVE' : trip.status === 'emergency' ? 'EMERGENCY' : trip.status === 'ended' ? 'TRIP ENDED' : 'IDLE'}
                  </Badge>
                )}
              </div>
            </div>

            {/* =================== Bus Live Location Status =================== */}
            <div className={cn(
              "rounded-xl border p-3 flex items-center gap-3 transition-colors",
              isLive
                ? "border-emerald-500/40 bg-emerald-500/[0.07]"
                : online && status === 'offline'
                  ? "border-red-500/40 bg-red-500/[0.07]"
                  : "border-slate-600 bg-slate-700/10"
            )}>
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",
                isLive
                  ? "bg-emerald-500/15 text-emerald-300"
                  : online && status === 'offline'
                    ? "bg-red-500/15 text-red-300"
                    : "bg-slate-600/20 text-slate-400"
              )}>
                {isLive ? (
                  <Satellite className="w-5 h-5" />
                ) : online && status === 'offline' ? (
                  <WifiOff className="w-5 h-5" />
                ) : (
                  <Activity className="w-5 h-5 animate-pulse" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Bus Live Location</span>
                  <span className={cn(
                    "text-xs font-black tracking-wide",
                    isLive ? "text-emerald-300" : "text-red-300"
                  )}>
                    {isLive ? 'ON' : 'OFF'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 truncate">
                  {isLive
                    ? `Sharing live GPS • updated ${secondsAgo ?? 0}s ago`
                    : online && status === 'offline'
                      ? 'Driver is offline — live location not available'
                      : online
                        ? 'Connecting to driver…'
                        : 'Offline simulation mode'}
                </div>
              </div>
              {isLive && (
                <span className="relative inline-flex w-3 h-3 flex-shrink-0">
                  <span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" />
                  <span className="relative inline-flex w-3 h-3 rounded-full bg-emerald-400" />
                </span>
              )}
            </div>

            {/* =================== Next Stop Hero Card =================== */}
            {nextStop && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 }}
                className={cn(
                  "relative overflow-hidden rounded-2xl border p-5",
                  nextStop.arrived
                    ? "border-emerald-500/50 bg-gradient-to-br from-emerald-500/15 to-emerald-600/5"
                    : "border-amber-500/40 bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent"
                )}
              >
                <div className="absolute -right-12 -top-12 w-40 h-40 rounded-full bg-amber-500/5 blur-2xl pointer-events-none" />
                <div className="relative flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={cn(
                      "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0",
                      nextStop.arrived ? "bg-emerald-500/20 text-emerald-300" : "bg-amber-500/20 text-amber-300"
                    )}>
                      {nextStop.arrived ? <CheckCircle2 className="w-5 h-5" /> : <Flag className="w-5 h-5" />}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                        {nextStop.arrived ? 'Arrived at' : 'Next stop'}
                      </div>
                      <div className="text-base font-bold text-slate-100 truncate mt-0.5">
                        {nextStop.stop.name || 'Unknown'}
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline" className="border-slate-600 bg-slate-800/50 text-slate-300 text-[10px] flex-shrink-0">
                    Stop {nextStop.index + 1}/{stops.length}
                  </Badge>
                </div>

                {!nextStop.arrived && (
                  <div className="relative flex items-end gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold mb-0.5">
                        Reaches in
                      </div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl font-black text-emerald-300 tabular-nums leading-none">
                          {Math.max(0, Math.ceil(nextStop.etaMin))}
                        </span>
                        <span className="text-sm font-semibold text-slate-400">min</span>
                      </div>
                    </div>
                    <div className="ml-auto flex flex-col items-end gap-1">
                      <div className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">Distance</div>
                      <div className="text-sm font-bold text-slate-200 tabular-nums">
                        {formatDistance(nextStop.distanceKm)}
                      </div>
                    </div>
                  </div>
                )}

                {nextStop.arrived && (
                  <div className="text-sm font-semibold text-emerald-300">
                    Bus has reached the stop.
                  </div>
                )}
              </motion.div>
            )}

            {/* =================== Your Boarding Point Card =================== */}
            {selected && boardingStop && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.15 }}
                className={cn(
                  "relative overflow-hidden rounded-2xl border p-4",
                  boardingInfo?.status === 'arrived'
                    ? "border-emerald-500/50 bg-gradient-to-br from-emerald-500/15 to-emerald-600/5"
                    : boardingInfo?.status === 'passed'
                      ? "border-slate-600 bg-slate-700/10"
                      : "border-cyan-500/40 bg-gradient-to-br from-cyan-500/10 via-cyan-500/5 to-transparent"
                )}
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={cn(
                      "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0",
                      boardingInfo?.status === 'arrived'
                        ? "bg-emerald-500/20 text-emerald-300"
                        : boardingInfo?.status === 'passed'
                          ? "bg-slate-600/20 text-slate-400"
                          : "bg-cyan-500/20 text-cyan-300"
                    )}>
                      {boardingInfo?.status === 'arrived' ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : boardingInfo?.status === 'passed' ? (
                        <Flag className="w-5 h-5" />
                      ) : (
                        <MapPin className="w-5 h-5" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                        Your Boarding Point
                      </div>
                      <div className="text-base font-bold text-slate-100 truncate mt-0.5">
                        {boardingStop.name}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setBoardingPickerOpen(true)}
                    className="text-[10px] text-cyan-300 hover:text-cyan-200 font-semibold border border-cyan-500/30 rounded-full px-2.5 py-1 hover:bg-cyan-500/10 transition-colors flex-shrink-0"
                  >
                    Change
                  </button>
                </div>

                {/* Boarding point status */}
                {busLoc && boardingInfo ? (
                  boardingInfo.status === 'upcoming' ? (
                    <div className="flex items-end justify-between gap-3">
                      <div>
                        <div className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold mb-0.5">
                          Bus reaches you in
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-4xl font-black text-cyan-300 tabular-nums leading-none">
                            {Math.max(0, Math.ceil(boardingInfo.etaMin))}
                          </span>
                          <span className="text-sm font-semibold text-slate-400">min</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-500">Distance</div>
                        <div className="text-sm font-bold text-slate-200 tabular-nums">
                          {formatDistance(boardingInfo.distanceKm)}
                        </div>
                        <div className="text-[10px] text-cyan-400 mt-0.5">Arrives {formatETA(boardingInfo.etaMin)}</div>
                      </div>
                    </div>
                  ) : boardingInfo.status === 'arriving' ? (
                    <div className="flex items-center gap-2 py-1">
                      <span className="relative inline-flex w-2 h-2">
                        <span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-cyan-400" />
                        <span className="relative inline-flex w-2 h-2 rounded-full bg-cyan-400" />
                      </span>
                      <span className="text-sm font-bold text-cyan-300">Bus is arriving at your stop now!</span>
                    </div>
                  ) : boardingInfo.status === 'arrived' ? (
                    <div className="flex items-center gap-2 py-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span className="text-sm font-bold text-emerald-300">Bus is at your stop — board now!</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 py-1">
                      <Flag className="w-4 h-4 text-slate-500" />
                      <span className="text-sm text-slate-500">Bus has already passed this stop</span>
                    </div>
                  )
                ) : !busLoc ? (
                  <div className="text-xs text-slate-500 py-1">
                    {isLive ? 'Waiting for bus location…' : 'Bus not tracking — enable driver GPS to see ETA'}
                  </div>
                ) : null}
              </motion.div>
            )}

            {/* =================== Speed + Trip Progress (2-col) =================== */}
            {stats && (
              <div className="grid grid-cols-2 gap-3">
                <div className={cn(
                  "rounded-2xl border p-4 flex flex-col justify-between",
                  isLive || (!online && busLoc)
                    ? "border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 to-[#10131f]"
                    : "border-[#1a2032] bg-[#10131f]"
                )}>
                  <div className="flex items-center gap-1.5 mb-2">
                    <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Bus Speed</span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-5xl font-black text-white tabular-nums leading-none">
                      {busLoc && stats.speed != null ? Math.round(stats.speed) : '—'}
                    </span>
                    {busLoc && stats.speed != null && <span className="text-xs font-semibold text-slate-400">km/h</span>}
                  </div>
                  <div className="text-[10px] mt-2 flex items-center gap-1">
                    {isLive ? (
                      <>
                        <span className="relative inline-flex w-1.5 h-1.5"><span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" /><span className="relative inline-flex w-1.5 h-1.5 rounded-full bg-emerald-400" /></span>
                        <span className="text-emerald-400 font-semibold">LIVE • {secondsAgo ?? 0}s ago</span>
                      </>
                    ) : !online && busLoc ? (
                      <span className="text-amber-400 font-semibold">SIMULATED</span>
                    ) : (
                      <span className="text-slate-500">Waiting for driver…</span>
                    )}
                  </div>
                </div>

                <div className="rounded-2xl border border-[#1a2032] bg-[#10131f] p-4 flex flex-col justify-between">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Activity className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Trip Progress</span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-black text-white tabular-nums leading-none">
                      {stats.progress.toFixed(0)}
                    </span>
                    <span className="text-xs font-semibold text-slate-400">%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[#1a2032] overflow-hidden mt-2">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400"
                      animate={{ width: `${stats.progress}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1.5 tabular-nums">
                    {formatDistance(stats.progress / 100 * selected.estDistanceKm)} done • {formatDistance(stats.distanceToDest)} left
                  </div>
                </div>
              </div>
            )}

            {/* =================== Bus Distance + ETA cards =================== */}
            {stats && (
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-[#1a2032] bg-[#10131f] p-4">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Crosshair className="w-3.5 h-3.5 text-blue-400" />
                    <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Bus distance</span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-white tabular-nums leading-none">
                      {stats.distanceToBus != null ? formatDistance(stats.distanceToBus) : '—'}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {userLoc ? 'From your live location' : 'Enable location to see'}
                  </div>
                </div>
                <div className="rounded-2xl border border-[#1a2032] bg-[#10131f] p-4">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Clock className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">ETA to RIT</span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-emerald-300 tabular-nums leading-none">
                      {busLoc ? formatDuration(stats.etaMin) : '—'}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {busLoc ? `Arrives ${formatETA(stats.etaMin)}` : 'Waiting for bus'}
                  </div>
                </div>
              </div>
            )}

            {/* =================== Map =================== */}
            <div className="rounded-2xl border border-[#1a2032] overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2.5 bg-[#10131f] border-b border-[#1a2032]">
                <div className="flex items-center gap-1.5">
                  <MapIcon className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Live Map</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-400">Follow</span>
                    <Switch checked={follow} onCheckedChange={setFollow} className="data-[state=checked]:bg-cyan-500" />
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setFollow(true)}
                    className="h-7 px-2 text-[10px] border-[#1a2032] text-cyan-300 hover:bg-cyan-500/10"
                  >
                    <Locate className="w-3 h-3 mr-1" /> Center
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setView('map')}
                    className="h-7 px-2 text-[10px] border-[#1a2032] text-cyan-300 hover:bg-cyan-500/10"
                  >
                    Full <ChevronDown className="w-3 h-3 ml-0.5 -rotate-90" />
                  </Button>
                </div>
              </div>
              <BusMap
                origin={routeStart}
                destination={dest}
                bus={busLoc}
                user={userLoc}
                routeLabel={`${selected.routeNo} ${selected.routeName} → RIT Campus`}
                followBus={follow}
                className="w-full h-56"
              />
            </div>

            {/* =================== Upcoming stops list =================== */}
            {upcoming.length > 0 && (
              <div id="trip-details" className="rounded-2xl border border-[#1a2032] bg-[#10131f] overflow-hidden scroll-mt-4">
                <div className="px-4 py-3 border-b border-[#1a2032] flex items-center gap-2">
                  <Flag className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Upcoming Stops</span>
                  <span className="ml-auto text-[10px] text-slate-500">
                    {upcoming.length} stop{upcoming.length !== 1 ? 's' : ''} ahead
                  </span>
                </div>
                <div className="max-h-72 overflow-y-auto wmb-scroll">
                  {upcoming.map((u, i) => {
                    const isNext = i === 0
                    const isLast = u.index === stops.length - 1
                    const isMyStop = u.index === boardingPointIdx
                    return (
                      <div
                        key={`${u.index}-${u.stop.name}`}
                        className={cn(
                          "px-4 py-3 flex items-center gap-3 border-b border-[#1a2032] last:border-b-0 transition-colors",
                          isMyStop ? "bg-cyan-500/10" : isNext ? "bg-amber-500/5" : "hover:bg-white/[0.02]"
                        )}
                      >
                        <div className="flex flex-col items-center flex-shrink-0">
                          <div className={cn(
                            "w-2.5 h-2.5 rounded-full border-2",
                            isMyStop
                              ? "border-cyan-400 bg-cyan-400"
                              : isNext
                                ? "border-amber-400 bg-amber-400 animate-pulse"
                                : isLast
                                  ? "border-red-400 bg-red-400/30"
                                  : "border-slate-600 bg-transparent"
                          )} />
                          {!isLast && <div className="w-px h-6 bg-slate-700 mt-0.5" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={cn(
                              "text-sm font-semibold truncate",
                              isMyStop ? "text-cyan-300" : isNext ? "text-amber-300" : "text-slate-200"
                            )}>
                              {u.stop.name || 'Unknown'}
                            </span>
                            {isMyStop && (
                              <Badge variant="outline" className="border-cyan-500/50 bg-cyan-500/15 text-cyan-300 text-[9px] px-1.5 py-0 h-4 flex-shrink-0">YOUR STOP</Badge>
                            )}
                            {isNext && !isMyStop && (
                              <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300 text-[9px] px-1.5 py-0 h-4 flex-shrink-0">NEXT</Badge>
                            )}
                            {isLast && !isMyStop && (
                              <Badge variant="outline" className="border-red-500/40 bg-red-500/10 text-red-300 text-[9px] px-1.5 py-0 h-4 flex-shrink-0">FINAL</Badge>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5 tabular-nums">
                            {formatDistance(u.distanceKm)} from previous stop
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className={cn(
                            "text-sm font-bold tabular-nums",
                            isNext ? "text-emerald-300" : "text-slate-300"
                          )}>
                            {Math.max(0, Math.ceil(u.etaMin))}
                            <span className="text-[10px] font-normal text-slate-500 ml-0.5">min</span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* =================== System Status =================== */}
            <div className="rounded-2xl border border-[#1a2032] bg-[#10131f] p-4">
              <div className="flex items-center gap-1.5 mb-3">
                <Signal className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">System Status</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <StatusRow label="Your Location" ok={sysStatus.gps} icon={Satellite} />
                <StatusRow label="Network" ok={sysStatus.network} icon={Wifi} />
                <StatusRow label="Server" ok={sysStatus.server} icon={Navigation} />
                <StatusRow label="Live Location" ok={sysStatus.liveLocation} icon={Radio} />
                <StatusRow label="Bus Tracking" ok={sysStatus.tracking} icon={Activity} />
                <StatusRow label="Trip Status" ok={!!(trip && trip.status === 'active')} icon={Flag} />
              </div>
              {online && !sysStatus.server && (
                <div className="text-[10px] text-amber-400 mt-2 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Reconnecting to server…
                </div>
              )}
            </div>

            {/* Source attribution */}
            <div className="text-[10px] text-slate-500 px-1 leading-relaxed">
              {online
                ? `Live updates from driver every 2 seconds. Last update ${secondsAgo != null ? `${secondsAgo}s ago` : 'never'}.`
                : 'Offline simulation mode — bus position updates every 2 seconds.'}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* =================== Boarding Point Picker Dialog =================== */}
      {boardingPickerOpen && selected && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setBoardingPickerOpen(false)}>
          <div
            className="w-full max-w-md rounded-2xl bg-[#10131f] border border-[#1a2032] shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-[#1a2032]">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-bold text-white">Select Your Boarding Point</span>
              </div>
              <button onClick={() => setBoardingPickerOpen(false)} className="text-slate-500 hover:text-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="px-3 py-2">
              <div className="text-[10px] text-slate-500 mb-2 px-1">
                {selected.routeNo} • {selected.routeName} → RIT Campus • {stops.length} stops
              </div>
            </div>
            <div className="max-h-80 overflow-y-auto wmb-scroll px-2 pb-3">
              {stops.map((s, idx) => {
                const isSelected = idx === boardingPointIdx
                const isLast = idx === stops.length - 1
                return (
                  <button
                    key={`${idx}-${s.name}`}
                    onClick={() => {
                      selectBoardingPoint(idx)
                      setBoardingPickerOpen(false)
                    }}
                    className={cn(
                      "w-full text-left rounded-xl px-3 py-2.5 border flex items-center gap-3 mb-1.5 transition-colors",
                      isSelected
                        ? "border-cyan-500/50 bg-cyan-500/10"
                        : "border-[#1a2032] hover:border-[#2a3252] hover:bg-[#161b2b]"
                    )}
                  >
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold",
                      isSelected ? "bg-cyan-500/20 text-cyan-300" : "bg-[#1a2032] text-slate-400"
                    )}>
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm text-slate-100 truncate">{s.name}</div>
                      {isLast && <div className="text-[10px] text-red-400">Final destination</div>}
                    </div>
                    {isSelected && (
                      <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

// =================== Sub-components ===================

function StatusRow({ label, ok, icon: Icon }: { label: string; ok: boolean; icon: React.ElementType }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-[#0a0d18]/60 px-2.5 py-2">
      <div className="flex items-center gap-1.5">
        <Icon className={cn("w-3.5 h-3.5", ok ? "text-emerald-400" : "text-slate-600")} />
        <span className="text-[11px] font-semibold text-slate-300">{label}</span>
      </div>
      <div className="flex items-center gap-1">
        <span className={cn("w-1.5 h-1.5 rounded-full", ok ? "bg-emerald-400" : "bg-red-400")} />
        <span className={cn("text-[10px] font-bold", ok ? "text-emerald-300" : "text-red-300")}>
          {ok ? 'ON' : 'OFF'}
        </span>
      </div>
    </div>
  )
}

function RouteSelector({ selectedRoute, onSelect }: {
  selectedRoute: BusRoute | null
  onSelect: (r: BusRoute) => void
}) {
  const [q, setQ] = useState("")
  const list = useMemo(() => searchRoutes(q), [q])
  return (
    <div className="space-y-3">
      <div className="relative">
        <Crosshair className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search route no or destination (e.g. R11 or Chengalpattu)"
          className="w-full pl-10 pr-3 py-3 bg-[#0a0d18] border border-[#1a2032] text-slate-100 placeholder:text-slate-600 rounded-xl text-sm focus:outline-none focus:border-cyan-500/40"
        />
      </div>
      <div className="text-[10px] uppercase tracking-widest text-slate-500 px-1">
        {list.length} routes available
      </div>
      <div className="max-h-[60vh] overflow-y-auto wmb-scroll space-y-1.5 pr-1">
        {list.map((r) => {
          const isActive = selectedRoute?.routeNo === r.routeNo
          return (
            <button
              key={r.routeNo}
              onClick={() => onSelect(r)}
              className={cn(
                "w-full text-left rounded-xl px-3.5 py-3 border transition-all flex items-center gap-3",
                isActive
                  ? "border-cyan-500/50 bg-cyan-500/10"
                  : "border-[#1a2032] bg-[#10131f] hover:border-[#2a3252] hover:bg-[#161b2b]"
              )}
            >
              <div className={cn(
                "flex-shrink-0 w-12 h-12 rounded-lg flex flex-col items-center justify-center font-bold text-sm",
                isActive ? "bg-cyan-500/20 text-cyan-300" : "bg-[#1a2032] text-amber-300"
              )}>
                <span className="text-[10px] uppercase tracking-wider text-slate-500 leading-none">RTE</span>
                <span className="text-xs leading-tight">{r.routeNo}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm text-slate-100 truncate">{r.routeName} → RIT Campus</div>
                <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {r.startingTime || '—'}</span>
                  <span className="flex items-center gap-1"><Navigation className="w-3 h-3" /> {formatDistance(r.estDistanceKm)}</span>
                  <span className="flex items-center gap-1"><Gauge className="w-3 h-3" /> ~{formatDuration(r.estDurationMin)}</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
            </button>
          )
        })}
        {list.length === 0 && (
          <div className="text-center text-sm text-slate-500 py-8">No routes match "{q}"</div>
        )}
      </div>
    </div>
  )
}
