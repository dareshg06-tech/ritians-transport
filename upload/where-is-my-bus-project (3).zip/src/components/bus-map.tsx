"use client"

import { useEffect, useRef } from "react"
import L from "leaflet"
import type { LatLng } from "@/lib/geo"

export interface MapMarker {
  id: string
  lat: number
  lng: number
  kind: 'origin' | 'destination' | 'bus' | 'user'
  label?: string
  heading?: number
}

export interface BusMapProps {
  origin: LatLng
  destination: LatLng
  bus?: LatLng | null
  user?: LatLng | null
  routeLabel?: string
  className?: string
  followBus?: boolean
}

// Build a colored pin marker
function buildIcon(kind: MapMarker['kind'], heading?: number): L.DivIcon {
  if (kind === 'bus') {
    return L.divIcon({
      className: '',
      html: `<div class="wmb-bus-icon" style="display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50% 50% 50% 0;background:linear-gradient(135deg,#22c55e,#16a34a);transform:rotate(${(heading || 0) - 45}deg);box-shadow:0 4px 16px rgba(34,197,94,0.5);border:3px solid white;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform:rotate(-${(heading || 0) - 45}deg);">
          <path d="M8 6v6"/><path d="M15 6v6"/><path d="M2 12h19.6"/><path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3"/><circle cx="7" cy="18" r="2"/><path d="M9 18h5"/><circle cx="16" cy="18" r="2"/>
        </svg>
      </div>`,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
    })
  }
  if (kind === 'user') {
    return L.divIcon({
      className: '',
      html: `<div style="position:relative;display:flex;align-items:center;justify-content:center;width:24px;height:24px;">
        <div class="wmb-live-dot" style="position:absolute;inset:0;background:#3b82f6;border-radius:50%;opacity:0.4;"></div>
        <div style="position:relative;width:16px;height:16px;background:#3b82f6;border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.4);"></div>
      </div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    })
  }
  if (kind === 'origin') {
    return L.divIcon({
      className: '',
      html: `<div style="display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;background:#f59e0b;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.4);font-size:14px;color:white;font-weight:bold;">A</div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
    })
  }
  // destination
  return L.divIcon({
    className: '',
    html: `<div style="display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;background:#ef4444;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.4);font-size:14px;color:white;font-weight:bold;">B</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  })
}

export default function BusMap({ origin, destination, bus, user, routeLabel, className, followBus }: BusMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const mapRef = useRef<L.Map | null>(null)
  const markersRef = useRef<Record<string, L.Marker>>({})
  const routeLineRef = useRef<L.Polyline | null>(null)
  const initializedRef = useRef(false)

  // Init map once
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return
    const map = L.map(containerRef.current, {
      center: [origin.lat, origin.lng],
      zoom: 12,
      zoomControl: true,
      attributionControl: true,
    })
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map)
    mapRef.current = map
    initializedRef.current = true

    // Force recalculation of map size after mount
    setTimeout(() => map.invalidateSize(), 100)

    return () => {
      map.remove()
      mapRef.current = null
      markersRef.current = {}
      routeLineRef.current = null
      initializedRef.current = false
    }
  }, [])

  // Update markers when props change
  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    const upsert = (id: string, lat: number, lng: number, kind: MapMarker['kind'], heading?: number) => {
      const existing = markersRef.current[id]
      if (existing) {
        existing.setLatLng([lat, lng])
        existing.setIcon(buildIcon(kind, heading))
      } else {
        const m = L.marker([lat, lng], { icon: buildIcon(kind, heading) }).addTo(map)
        markersRef.current[id] = m
      }
    }

    upsert('origin', origin.lat, origin.lng, 'origin')
    upsert('destination', destination.lat, destination.lng, 'destination')
    if (bus) upsert('bus', bus.lat, bus.lng, 'bus', bus ? undefined : undefined)
    if (user) upsert('user', user.lat, user.lng, 'user')

    // Remove bus/user markers if not provided
    if (!bus && markersRef.current['bus']) {
      map.removeLayer(markersRef.current['bus'])
      delete markersRef.current['bus']
    }
    if (!user && markersRef.current['user']) {
      map.removeLayer(markersRef['user'])
      delete markersRef.current['user']
    }

    // Draw the route line origin -> destination
    if (routeLineRef.current) {
      routeLineRef.current.setLatLngs([
        [origin.lat, origin.lng],
        [destination.lat, destination.lng],
      ])
    } else {
      routeLineRef.current = L.polyline(
        [
          [origin.lat, origin.lng],
          [destination.lat, destination.lng],
        ],
        { color: '#f59e0b', weight: 3, opacity: 0.6, dashArray: '8 8' }
      ).addTo(map)
    }

    // If bus is moving and followBus is on, recenter on bus; else fit bounds
    if (bus && followBus) {
      map.setView([bus.lat, bus.lng], Math.max(map.getZoom(), 14), { animate: true })
    } else {
      const bounds = L.latLngBounds([
        [origin.lat, origin.lng],
        [destination.lat, destination.lng],
      ])
      if (bus) bounds.extend([bus.lat, bus.lng])
      if (user) bounds.extend([user.lat, user.lng])
      map.fitBounds(bounds, { padding: [60, 60], maxZoom: 14 })
    }
  }, [origin.lat, origin.lng, destination.lat, destination.lng, bus?.lat, bus?.lng, user?.lat, user?.lng, followBus])

  return (
    <div
      ref={containerRef}
      className={className || "w-full h-72 rounded-2xl overflow-hidden border border-[#1f2538]"}
      style={{ minHeight: 280, background: '#0a0d18' }}
      aria-label={`Map showing route ${routeLabel || ''}`}
    />
  )
}
