"use client"

import dynamic from "next/dynamic"
import { useEffect, useMemo, useRef, useState, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Bus as BusIcon,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Compass,
  Crosshair,
  Flag,
  Gauge,
  LayoutDashboard,
  Locate,
  MapPin,
  Map as MapIcon,
  Navigation,
  Radio,
  Radar,
  Route as RouteIcon,
  Satellite,
  Send,
  Settings,
  Shield,
  Signal,
  Square,
  X,
  Wifi,
  WifiOff,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { BUS_FLEET, getBusRoute, type Bus } from "@/lib/buses"
import { CHENNAI_ORIGIN } from "@/lib/bus-routes"
import { getRouteStops, type Stop } from "@/lib/route-stops"
import {
  bearingDeg,
  compassLabel,
  etaMinutes,
  findNextStop,
  formatDistance,
  formatDuration,
  formatSpeed,
  haversineKm,
  interpolateRoute,
  progressPct,
  speedBetween,
  upcomingStops,
  type LatLng,
} from "@/lib/geo"
import { useDriverBroadcast } from "@/hooks/use-bus-socket"

// ===== Driver info =====
interface DriverInfo {
  id: string
  name: string
  phone?: string | null
  licenseNo?: string | null
  avatarColor: string
}

// Persisted driver info in localStorage
const DRIVER_LS_KEY = "wmb_driver_session"
function loadDriverSession(): DriverInfo | null {
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(DRIVER_LS_KEY) : null
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}
function saveDriverSession(d: DriverInfo) {
  try { localStorage.setItem(DRIVER_LS_KEY, JSON.stringify(d)) } catch { /* ignore */ }
}
function clearDriverSession() {
  try { localStorage.removeItem(DRIVER_LS_KEY) } catch { /* ignore */ }
}

const BusMap = dynamic(() => import("@/components/bus-map"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-72 rounded-2xl bg-[#0a0d18] border border-[#1a2032] flex items-center justify-center">
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <Satellite className="w-4 h-4 animate-pulse" /> Loading map…
      </div>
    </div>
  ),
})

type GpsState = 'off' | 'on' | 'error'
type TripState = 'idle' | 'active' | 'ended'

interface DriverDashboardProps {
  mode: 'online' | 'offline'
}

function greeting(): string {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

function formatTimeOfDay(ms: number): string {
  const d = new Date(ms)
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

function formatETA(min: number): string {
  const eta = new Date(Date.now() + min * 60_000)
  return eta.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

export default function DriverDashboard({ mode }: DriverDashboardProps) {
  // === Auth state ===
  const [driver, setDriver] = useState<DriverInfo | null>(null)
  const [authReady, setAuthReady] = useState(false)

  // === State ===
  const [selectedBus, setSelectedBus] = useState<Bus | null>(null)
  const [busPickerOpen, setBusPickerOpen] = useState(false)
  const [gpsState, setGpsState] = useState<GpsState>('off')
  const [tripState, setTripState] = useState<TripState>('idle')
  const [tripStartedAt, setTripStartedAt] = useState<number | null>(null)
  const [tripId, setTripId] = useState<string | null>(null) // persisted trip ID

  const [lat, setLat] = useState<number | null>(null)
  const [lng, setLng] = useState<number | null>(null)
  const [accuracy, setAccuracy] = useState<number | null>(null)
  const [speed, setSpeed] = useState<number | null>(null)
  const [heading, setHeading] = useState<number>(0)
  const [lastUpdate, setLastUpdate] = useState<number | null>(null)
  const [gpsError, setGpsError] = useState<string | null>(null)
  const [trackingMode, setTrackingMode] = useState<'gps' | 'tower'>('gps')

  const [follow, setFollow] = useState(true)
  const [view, setView] = useState<'dashboard' | 'map' | 'history' | 'profile'>('dashboard')

  const [emergencyOpen, setEmergencyOpen] = useState(false)
  const [endTripOpen, setEndTripOpen] = useState(false)
  const [emergencySent, setEmergencySent] = useState(false)

  // Passenger count per stop
  const [stopPickerOpen, setStopPickerOpen] = useState(false)
  const [stopEventOpen, setStopEventOpen] = useState(false)
  const [stopEventForm, setStopEventForm] = useState<{ stopName: string; stopIndex: number; boarded: number; alighted: number; waitingAt: number }>({
    stopName: '', stopIndex: 0, boarded: 0, alighted: 0, waitingAt: 0,
  })

  // Trip history (for profile view)
  const [history, setHistory] = useState<Array<{
    id: string; busNo: string; plate: string; routeNo: string; routeName: string;
    status: string; startedAt: string; endedAt: string | null; durationMin: number | null;
    totalKm: number | null; totalBoarded: number; totalAlighted: number; stopsCount: number;
  }>>([])
  const [historyLoading, setHistoryLoading] = useState(false)

  const broadcast = useDriverBroadcast()

  // === Load driver session on mount ===
  useEffect(() => {
    setDriver(loadDriverSession())
    setAuthReady(true)
  }, [])

  const watchIdRef = useRef<number | null>(null)
  const lastPosRef = useRef<{ lat: number; lng: number; t: number } | null>(null)
  // Simulated driver movement (offline mode)
  const simIdxRef = useRef(0)
  const simTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // === Logout ===
  const logout = useCallback(() => {
    if (watchIdRef.current != null && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current)
      watchIdRef.current = null
    }
    if (simTimerRef.current) {
      clearInterval(simTimerRef.current)
      simTimerRef.current = null
    }
    if (tripId && mode === 'online') {
      fetch('/api/trip/end', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tripId }),
      }).catch(() => {})
    }
    if (mode === 'online') broadcast.stop()
    clearDriverSession()
    setDriver(null)
    setSelectedBus(null)
    setTripId(null)
    setGpsState('off')
    setTripState('idle')
    setTripStartedAt(null)
    setView('dashboard')
    toast.success('Logged out')
  }, [tripId, mode, broadcast])

  const route = selectedBus ? getBusRoute(selectedBus) : null
  const routeNo = route?.routeNo || null
  const routeName = route?.routeName || ''
  // Origin = the boarding point (startLat/startLng); Destination = RIT Campus (destLat/destLng)
  const routeStart: LatLng = route ? { lat: route.startLat, lng: route.startLng } : { lat: 13.0827, lng: 80.2707 }
  const dest: LatLng = route ? { lat: route.destLat, lng: route.destLng } : routeStart

  // === Computed stops & next stop ===
  const stops: Stop[] = useMemo(() => {
    if (!route) return []
    return getRouteStops(route.routeNo, { name: route.routeName, lat: route.startLat, lng: route.startLng })
  }, [route])

  const nextStop = useMemo(() => {
    if (!selectedBus || lat == null || lng == null || stops.length === 0) return null
    return findNextStop({ lat, lng }, stops, speed ?? null, 22)
  }, [selectedBus, lat, lng, speed, stops])

  // Upcoming stops list (for the list view)
  const upcoming = useMemo(() => {
    if (!selectedBus || lat == null || lng == null || stops.length === 0) return []
    return upcomingStops({ lat, lng }, stops, speed ?? null, 22)
  }, [selectedBus, lat, lng, speed, stops])

  // === GPS state ===
  const isGpsOn = gpsState === 'on' && (mode === 'online' ? broadcast.isSharing : true)

  // === Start GPS ===
  const startGps = useCallback(() => {
    if (!selectedBus || !route) {
      toast.error('Select your bus first')
      return
    }
    setGpsError(null)

    if (mode === 'online') {
      if (!navigator.geolocation) {
        setGpsState('error')
        setGpsError('Geolocation not supported on this device')
        toast.error('Geolocation not supported')
        return
      }
      const ok = broadcast.start(route.routeNo, route.routeName, {
        busNo: selectedBus.busNo,
        plate: selectedBus.plate,
      })
      if (!ok) {
        setGpsState('error')
        setGpsError('Could not connect to tracking server')
        toast.error('Could not connect to tracking server')
        return
      }
      watchIdRef.current = navigator.geolocation.watchPosition(
        (pos) => {
          const newLat = pos.coords.latitude
          const newLng = pos.coords.longitude
          const t = Date.now()
          const prev = lastPosRef.current
          let calcSpeed = pos.coords.speed != null && pos.coords.speed >= 0
            ? pos.coords.speed * 3.6
            : null
          if (calcSpeed == null && prev) {
            calcSpeed = speedBetween({ ...prev, t: prev.t }, { lat: newLat, lng: newLng, t })
          }
          const h = pos.coords.heading != null && pos.coords.heading >= 0
            ? pos.coords.heading
            : prev
              ? bearingDeg(prev, { lat: newLat, lng: newLng })
              : 0
          setLat(newLat)
          setLng(newLng)
          setAccuracy(pos.coords.accuracy ?? null)
          setSpeed(calcSpeed)
          setHeading(h)
          setLastUpdate(t)
          setGpsState('on')
          lastPosRef.current = { lat: newLat, lng: newLng, t }

          broadcast.push({
            routeName: route.routeName,
            lat: newLat,
            lng: newLng,
            accuracy: pos.coords.accuracy ?? undefined,
            speedKmh: calcSpeed ?? 0,
            heading: h,
            mode: trackingMode,
          })
        },
        (err) => {
          setGpsState('error')
          setGpsError(err.message || 'Could not get location')
          toast.error('GPS error: ' + (err.message || 'unknown'))
        },
        { enableHighAccuracy: trackingMode === 'gps', maximumAge: 2000, timeout: 15000 }
      )
      toast.success(`GPS active — sharing location on route ${route.routeNo}`)
    } else {
      // Offline: simulate driver movement along the route (using stops, not straight line)
      const path = interpolateRoute(routeStart, dest, 100)
      simIdxRef.current = 0
      const start = path[0]
      // Network mode = lower accuracy + jitter; GPS mode = tight accuracy
      const isTower = trackingMode === 'tower'
      const baseAccuracy = isTower ? 45 + Math.random() * 55 : 6 + Math.random() * 4 // GPS: 6-10m, Tower: 45-100m
      const jitter = () => (isTower ? (Math.random() - 0.5) * 0.001 : 0) // ~50-100m positional noise for tower
      setLat(start.lat + jitter())
      setLng(start.lng + jitter())
      setAccuracy(baseAccuracy)
      setSpeed(0)
      setHeading(bearingDeg(start, path[1] || dest))
      setLastUpdate(Date.now())
      setGpsState('on')
      lastPosRef.current = { lat: start.lat, lng: start.lng, t: Date.now() }

      simTimerRef.current = setInterval(() => {
        const nextIdx = Math.min(path.length - 1, simIdxRef.current + 1)
        simIdxRef.current = nextIdx
        const next = path[nextIdx]
        const prev = lastPosRef.current!
        const sp = nextIdx === path.length - 1 ? 0 : 22 + Math.random() * 8
        const h = bearingDeg(prev, next)
        setLat(next.lat + jitter())
        setLng(next.lng + jitter())
        setAccuracy(isTower ? 45 + Math.random() * 55 : 6 + Math.random() * 4)
        setSpeed(sp)
        setHeading(h)
        setLastUpdate(Date.now())
        lastPosRef.current = { lat: next.lat, lng: next.lng, t: Date.now() }
      }, 2000)
      toast.success(`${isTower ? 'Network tower' : 'GPS'} active (simulated) on route ${route.routeNo}`)
    }
  }, [selectedBus, route, mode, broadcast, trackingMode, dest])

  // === Stop GPS ===
  const stopGps = useCallback(() => {
    if (watchIdRef.current != null && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current)
      watchIdRef.current = null
    }
    if (simTimerRef.current) {
      clearInterval(simTimerRef.current)
      simTimerRef.current = null
    }
    if (mode === 'online') broadcast.stop()
    setGpsState('off')
    lastPosRef.current = null
    toast.info('GPS stopped — location sharing off')
  }, [mode, broadcast])

  // === Broadcast next stop to passengers whenever it changes ===
  useEffect(() => {
    if (!nextStop || !broadcast.isSharing || !route) return
    broadcast.pushNextStop({
      stopName: nextStop.stop.name || 'Unknown',
      stopIndex: nextStop.index,
      totalStops: stops.length,
      distanceKm: nextStop.distanceKm,
      etaMin: nextStop.etaMin,
      arrived: nextStop.arrived,
    })
  }, [nextStop, broadcast, route, stops.length])

  // Latest distance travelled — kept in a ref so confirmEndTrip can read it
  // without depending on the (later-declared) distTravelled useMemo.
  const distTravelledRef = useRef(0)

  // === Start / end trip ===
  const startTrip = useCallback(async () => {
    if (!route || !selectedBus) {
      toast.error('Select your bus first')
      return
    }
    // Auto-enable GPS if not already on
    if (!isGpsOn) {
      toast.info('Starting GPS and trip…')
      // Try to start GPS first
      // We'll call startGps indirectly by setting a flag; but simpler: just proceed and let the driver enable GPS
      // For now, start the trip anyway — GPS can be enabled separately
    }
    if (mode === 'online') {
      broadcast.startTrip(route.routeNo, route.routeName, {
        busNo: selectedBus.busNo,
        plate: selectedBus.plate,
      })
      // Persist trip to database
      if (driver) {
        try {
          const res = await fetch('/api/trip/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              driverId: driver.id,
              busNo: selectedBus.busNo,
              plate: selectedBus.plate,
              routeNo: route.routeNo,
              routeName: route.routeName,
            }),
          })
          const data = await res.json()
          if (data.ok && data.trip) {
            setTripId(data.trip.id)
          }
        } catch (e) {
          console.error('[trip:start] failed to persist', e)
        }
      }
    }
    setTripState('active')
    setTripStartedAt(Date.now())
    toast.success(`Trip started at ${formatTimeOfDay(Date.now())}`)
  }, [route, selectedBus, isGpsOn, mode, broadcast, driver])

  const confirmEndTrip = useCallback(async () => {
    if (!route) return
    if (mode === 'online') {
      broadcast.endTrip(route.routeNo)
      // Persist trip end to database
      if (tripId) {
        try {
          await fetch('/api/trip/end', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              tripId,
              endLat: lat ?? undefined,
              endLng: lng ?? undefined,
              totalKm: distTravelledRef.current || undefined,
            }),
          })
        } catch (e) {
          console.error('[trip:end] failed to persist', e)
        }
      }
    }
    setTripState('ended')
    setTripStartedAt(null)
    setTripId(null)
    setEndTripOpen(false)
    toast.success('Trip ended. Safe travels!')
  }, [route, mode, broadcast, tripId, lat, lng])

  // === Record a stop event (passenger boarding/alighting) ===
  const recordStopEvent = useCallback(async () => {
    if (!tripId) {
      toast.error('No active trip')
      return
    }
    try {
      await fetch('/api/trip/stop-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tripId,
          stopName: stopEventForm.stopName,
          stopIndex: stopEventForm.stopIndex,
          boarded: stopEventForm.boarded,
          alighted: stopEventForm.alighted,
          waitingAt: stopEventForm.waitingAt,
        }),
      })
      toast.success(`Recorded ${stopEventForm.boarded} boarded, ${stopEventForm.alighted} alighted at ${stopEventForm.stopName}`)
      setStopEventOpen(false)
    } catch (e) {
      toast.error('Failed to record stop event')
      console.error(e)
    }
  }, [tripId, stopEventForm])

  // === Load trip history when profile view opens ===
  useEffect(() => {
    if (view !== 'profile' || !driver) return
    setHistoryLoading(true)
    fetch(`/api/trip/history?driverId=${encodeURIComponent(driver.id)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.trips) setHistory(data.trips)
      })
      .catch(() => toast.error('Failed to load trip history'))
      .finally(() => setHistoryLoading(false))
  }, [view, driver])

  // === Emergency ===
  const confirmEmergency = useCallback(() => {
    if (!route || lat == null || lng == null) {
      toast.error('GPS not available — cannot send coordinates')
      return
    }
    if (mode === 'online') {
      broadcast.sendEmergency(route.routeNo, lat, lng, selectedBus?.busNo)
    }
    setEmergencySent(true)
    setEmergencyOpen(false)
    setTimeout(() => setEmergencySent(false), 5000)
    toast.error('🚨 Emergency alert sent to control room')
  }, [route, lat, lng, mode, broadcast, selectedBus])

  // === Cleanup on unmount ===
  useEffect(() => {
    return () => {
      if (watchIdRef.current != null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current)
      }
      if (simTimerRef.current) clearInterval(simTimerRef.current)
      if (mode === 'online') broadcast.stop()
    }
  }, [])

  // === Reset state when bus changes ===
  useEffect(() => {
    if (gpsState === 'on') stopGps()
    if (tripState === 'active') {
      if (mode === 'online' && route) broadcast.endTrip(route.routeNo)
      setTripState('idle')
      setTripStartedAt(null)
    }
    setLat(null); setLng(null); setSpeed(null); setAccuracy(null); setLastUpdate(null); setHeading(0)
  }, [selectedBus])

  // === Live "seconds ago" ticker ===
  const [, setTick] = useState(0)
  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 1000)
    return () => clearInterval(i)
  }, [])
  const secondsAgo = lastUpdate ? Math.floor((Date.now() - lastUpdate) / 1000) : null

  // === Trip progress ===
  const progress = useMemo(() => {
    if (!route || lat == null || lng == null) return 0
    return progressPct(routeStart, { lat, lng }, dest)
  }, [route, lat, lng, dest])

  const distTravelled = useMemo(() => {
    if (!route || lat == null || lng == null) return 0
    return haversineKm(routeStart, { lat, lng })
  }, [route, lat, lng])

  // Keep distTravelledRef in sync so async callbacks can read latest value
  useEffect(() => {
    distTravelledRef.current = distTravelled
  }, [distTravelled])

  const distRemaining = useMemo(() => {
    if (!route || lat == null || lng == null) return route?.estDistanceKm ?? 0
    return haversineKm({ lat, lng }, dest)
  }, [route, lat, lng, dest])

  const etaToDest = useMemo(() => {
    if (!route) return null
    return etaMinutes(distRemaining, speed ?? null, 22)
  }, [route, distRemaining, speed])

  // === System status ===
  const sysStatus = useMemo(() => {
    return {
      gps: isGpsOn,
      network: typeof navigator !== 'undefined' ? navigator.onLine : true,
      server: broadcast.connected,
      tracking: isGpsOn && (mode === 'offline' || broadcast.isSharing),
    }
  }, [isGpsOn, broadcast.connected, broadcast.isSharing, mode])

  // === Render ===

  // Auth gate: show login screen if not authenticated
  if (!authReady) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-sm text-slate-500 flex items-center gap-2">
          <Satellite className="w-4 h-4 animate-pulse" /> Loading…
        </div>
      </div>
    )
  }

  if (!driver) {
    return <DriverLogin onLogin={(d) => { setDriver(d); saveDriverSession(d) }} />
  }

  // Profile view (trip history)
  if (view === 'profile') {
    return (
      <DriverProfile
        driver={driver}
        history={history}
        historyLoading={historyLoading}
        onBack={() => setView('dashboard')}
        onLogout={logout}
      />
    )
  }

  if (view === 'map') {
    return (
      <div className="fixed inset-0 z-50 bg-[#0a0d18] flex flex-col">
        <div className="flex items-center justify-between p-3 bg-[#0a0d18]/95 backdrop-blur border-b border-[#1a2032]">
          <Button
            variant="ghost"
            onClick={() => setView('dashboard')}
            className="text-cyan-300 hover:bg-cyan-500/10"
          >
            <ChevronDown className="w-4 h-4 mr-1" /> Back to Dashboard
          </Button>
          <div className="flex items-center gap-2">
            {isGpsOn ? (
              <Badge variant="outline" className="border-emerald-500/40 bg-emerald-500/10 text-emerald-300 gap-1.5">
                <span className="relative inline-flex w-2 h-2"><span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" /><span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-400" /></span>
                LIVE GPS
              </Badge>
            ) : (
              <Badge variant="outline" className="border-red-500/40 bg-red-500/10 text-red-300 gap-1.5">
                <WifiOff className="w-3 h-3" /> GPS OFF
              </Badge>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFollow((f) => !f)}
              className={cn(
                "border-[#1a2032]",
                follow ? "bg-cyan-500/10 text-cyan-300 border-cyan-500/40" : "text-slate-400"
              )}
            >
              <Locate className="w-3.5 h-3.5 mr-1" /> {follow ? 'Following' : 'Manual'}
            </Button>
          </div>
        </div>
        <div className="flex-1 relative">
          {route && (
            <BusMap
              origin={routeStart}
              destination={dest}
              bus={lat != null && lng != null ? { lat, lng } : null}
              routeLabel={`${selectedBus?.busNo || ''} ${route.routeName} → RIT Campus`}
              followBus={follow}
              className="w-full h-full"
            />
          )}
        </div>
        {/* Floating speed card on full-screen map */}
        {isGpsOn && speed != null && (
          <div className="absolute bottom-4 left-4 right-4 sm:left-4 sm:right-auto sm:w-64 rounded-2xl bg-[#0a0d18]/95 backdrop-blur border border-[#1a2032] p-4">
            <div className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold mb-1">Live Speed</div>
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-black text-white tabular-nums">{Math.round(speed)}</span>
              <span className="text-sm font-semibold text-slate-400">km/h</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">
              {secondsAgo != null ? `Updated ${secondsAgo}s ago • ${formatDistance(distRemaining)} to go` : '—'}
            </div>
          </div>
        )}
      </div>
    )
  }

  // Compute extra status info for the portal display
  const statusLabel = !isGpsOn
    ? 'Idle'
    : gpsState === 'error'
      ? 'Error'
      : tripState === 'active'
        ? `Trip Active • ${trackingMode === 'gps' ? 'GPS' : 'Network'}`
        : `Tracking • ${trackingMode === 'gps' ? 'GPS' : 'Network'}`

  return (
    <div className="min-h-screen bg-[#0f111a] text-slate-100">
      {/* =================== Top App Bar (Bitano-style) =================== */}
      <header className="border-b border-[#1f2538] bg-[#0f111a]">
        <div className="max-w-2xl mx-auto px-4 py-3">
          {/* Row 1: Logo + Title + Subtitle */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20 flex-shrink-0">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-base font-bold text-white leading-tight">Driver Portal</h1>
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mt-0.5 leading-none">
                GPS TRACKING • {driver.name.split(' ')[0].toUpperCase()} • {driver.id}
              </p>
            </div>
            <button
              onClick={() => setView('profile')}
              className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg hover:opacity-90 transition-opacity flex-shrink-0"
              style={{ background: `linear-gradient(135deg, ${driver.avatarColor}, ${driver.avatarColor}cc)` }}
              aria-label="Open driver profile"
            >
              {driver.name.charAt(0).toUpperCase()}
            </button>
          </div>

          {/* Row 2: Back / Live Tracking pills */}
          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={() => { logout() }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#161b2b] border border-[#2a3252] text-cyan-300 text-xs font-semibold hover:bg-[#1f2538] transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Login
            </button>
            <div className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-colors",
              isGpsOn
                ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                : "border-slate-600 bg-[#161b2b] text-slate-400"
            )}>
              {isGpsOn ? (
                <>
                  <span className="relative inline-flex w-2 h-2">
                    <span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" />
                    <span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-400" />
                  </span>
                  LIVE TRACKING
                </>
              ) : (
                <>
                  <Radio className="w-3.5 h-3.5" /> Live Tracking
                </>
              )}
            </div>
            {mode === 'online' && (
              <div className={cn(
                "ml-auto flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-semibold",
                broadcast.connected
                  ? "bg-emerald-500/10 text-emerald-300"
                  : "bg-amber-500/10 text-amber-300"
              )}>
                <Signal className="w-3 h-3" />
                {broadcast.connected ? 'Server OK' : 'Reconnecting…'}
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {/* =================== Driver GPS Portal Hero Card (Bitano-style) =================== */}
        <div className="rounded-3xl border border-[#1f2538] bg-[#161b2b] p-6 shadow-xl">
          {/* Hero icon */}
          <div className="flex justify-center mb-4">
            <div className={cn(
              "w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-colors",
              isGpsOn
                ? "bg-gradient-to-br from-emerald-500 to-emerald-600 shadow-emerald-500/30"
                : "bg-gradient-to-br from-amber-500 to-amber-600 shadow-amber-500/30"
            )}>
              {isGpsOn ? <Satellite className="w-10 h-10 text-white" /> : <Radio className="w-10 h-10 text-white" />}
            </div>
          </div>

          <h2 className="text-xl font-bold text-white text-center">Driver GPS Portal</h2>
          <p className="text-xs text-slate-500 mt-1.5 text-center">
            Share your live location with passengers on route
          </p>

          {/* Route badge below subtitle */}
          {selectedBus && route && (
            <div className="flex justify-center mt-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] font-semibold">
                <RouteIcon className="w-3 h-3" />
                {selectedBus.busNo} ({selectedBus.plate}) → {route.routeName} → RIT Campus
              </div>
            </div>
          )}

          {/* =================== Alert Box =================== */}
          <div className="mt-5 rounded-xl border border-amber-500/30 bg-amber-500/[0.06] p-3.5 flex items-start gap-3">
            <Radar className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-amber-200/90">
              Your location is only visible to passengers while tracking is active.
              It auto-expires after 60 seconds of inactivity.
            </p>
          </div>

          {/* =================== Route / Vehicle Selector =================== */}
          <div className="mt-5">
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold mb-2">
              Your Route / Vehicle ID
            </div>
            <button
              onClick={() => setBusPickerOpen(true)}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-[#0f1219] border border-[#2a3252] hover:border-[#3a4366] transition-colors text-left"
            >
              <RouteIcon className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                {selectedBus ? (
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-100 truncate">
                      {selectedBus.busNo} — {route?.routeName || 'Unknown'}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono truncate">{selectedBus.plate}</div>
                  </div>
                ) : (
                  <div className="text-sm text-slate-500">Select Your Route</div>
                )}
              </div>
              <ChevronDown className="w-4 h-4 text-slate-500 flex-shrink-0" />
            </button>
          </div>

          {/* =================== Position Source Selector (GPS vs Network) =================== */}
          <div className="mt-4">
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold mb-2">
              Position Source
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setTrackingMode('gps')}
                disabled={gpsState === 'on'}
                aria-pressed={trackingMode === 'gps'}
                className={cn(
                  "rounded-xl px-3 py-3 border text-xs font-semibold transition-all flex flex-col items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed",
                  trackingMode === 'gps'
                    ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-300 shadow-sm shadow-emerald-500/10"
                    : "border-[#2a3252] text-slate-400 hover:bg-[#1a2032] hover:border-[#3a4366]"
                )}
              >
                <Satellite className={cn("w-5 h-5", trackingMode === 'gps' && "text-emerald-400")} />
                <span>GPS</span>
                <span className="text-[9px] font-normal text-slate-500 leading-none">High accuracy</span>
              </button>
              <button
                type="button"
                onClick={() => setTrackingMode('tower')}
                disabled={gpsState === 'on'}
                aria-pressed={trackingMode === 'tower'}
                className={cn(
                  "rounded-xl px-3 py-3 border text-xs font-semibold transition-all flex flex-col items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed",
                  trackingMode === 'tower'
                    ? "border-sky-500/60 bg-sky-500/10 text-sky-300 shadow-sm shadow-sky-500/10"
                    : "border-[#2a3252] text-slate-400 hover:bg-[#1a2032] hover:border-[#3a4366]"
                )}
              >
                <Radio className={cn("w-5 h-5", trackingMode === 'tower' && "text-sky-400")} />
                <span>Network</span>
                <span className="text-[9px] font-normal text-slate-500 leading-none">Cell tower / Wi-Fi</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-600 mt-1.5 leading-snug">
              {trackingMode === 'gps'
                ? 'Uses device GPS satellites. Most accurate (±5–10 m) but uses more battery.'
                : 'Uses cell towers and Wi-Fi networks. Faster fix and lower battery, but less accurate (±30–100 m).'}
            </p>
          </div>

          {/* =================== Primary Action Button =================== */}
          <div className="mt-3">
            {gpsState === 'on' ? (
              <button
                onClick={stopGps}
                className="w-full h-14 rounded-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 text-white font-bold text-sm shadow-lg shadow-red-500/30 flex items-center justify-center gap-2 transition-all"
              >
                <Square className="w-4 h-4" /> Stop Sharing Location
              </button>
            ) : (
              <button
                onClick={startGps}
                disabled={!selectedBus}
                className="w-full h-14 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <MapPin className="w-4 h-4" /> Start Sharing Location
              </button>
            )}
            {!selectedBus && gpsState !== 'on' && (
              <div className="text-[10px] text-amber-400 text-center mt-2">Choose your bus first</div>
            )}
            {gpsState === 'error' && gpsError && (
              <div className="text-[10px] text-red-400 text-center mt-2">{gpsError}</div>
            )}
          </div>

          {/* =================== Status Accordion (Bitano-style) =================== */}
          <div className="mt-5 rounded-xl bg-[#0f1219] border border-[#2a3252] overflow-hidden">
            <StatusRow
              icon={Activity}
              label="Status"
              value={statusLabel}
              valueColor={isGpsOn ? 'text-emerald-300' : 'text-slate-300'}
              divider
            />
            <StatusRow
              icon={trackingMode === 'gps' ? Satellite : Radio}
              label="Position Source"
              value={trackingMode === 'gps' ? 'GPS (satellite)' : 'Network (cell tower / Wi-Fi)'}
              valueColor={trackingMode === 'gps' ? 'text-emerald-300' : 'text-sky-300'}
              divider
            />
            <StatusRow
              icon={Crosshair}
              label="Latitude"
              value={lat != null ? `${lat.toFixed(6)}° N` : '—'}
              valueClass="font-mono"
              divider
            />
            <StatusRow
              icon={Crosshair}
              label="Longitude"
              value={lng != null ? `${lng.toFixed(6)}° E` : '—'}
              valueClass="font-mono"
              divider
            />
            <StatusRow
              icon={Gauge}
              label="Speed"
              value={isGpsOn && speed != null ? `${speed.toFixed(1)} km/h` : '—'}
              valueClass="font-mono"
              divider
            />
            <StatusRow
              icon={Compass}
              label="Heading"
              value={isGpsOn ? `${compassLabel(heading)} (${heading.toFixed(0)}°)` : '—'}
              divider
            />
            <StatusRow
              icon={Crosshair}
              label="Accuracy"
              value={accuracy != null ? `± ${Math.round(accuracy)} m` : '—'}
              valueClass="font-mono"
              divider
            />
            <StatusRow
              icon={Clock}
              label="Last Update"
              value={secondsAgo != null ? `${secondsAgo}s ago` : '—'}
              valueColor={secondsAgo != null && secondsAgo < 5 ? 'text-emerald-300' : 'text-slate-300'}
              divider
            />
            <StatusRow
              icon={Navigation}
              label="Trip Status"
              value={
                tripState === 'active' ? (tripStartedAt ? `Active since ${formatTimeOfDay(tripStartedAt)}` : 'Active') :
                tripState === 'ended' ? 'Ended' : 'Not started'
              }
              valueColor={tripState === 'active' ? 'text-emerald-300' : 'text-slate-300'}
            />
          </div>

          {/* Expandable advanced controls */}
          <details className="mt-3 group">
            <summary className="cursor-pointer list-none flex items-center justify-center gap-1.5 text-[11px] text-slate-500 hover:text-slate-300 py-2">
              <ChevronDown className="w-3 h-3 group-open:rotate-180 transition-transform" />
              Advanced controls
            </summary>
            <div className="mt-2 space-y-2">
              {/* Emergency button */}
              <button
                onClick={() => setEmergencyOpen(true)}
                disabled={!isGpsOn}
                className="w-full h-11 rounded-xl border border-red-500/40 bg-red-500/10 text-red-300 font-bold text-xs hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2 disabled:opacity-40"
              >
                <Shield className="w-4 h-4" /> EMERGENCY ALERT
              </button>
              {emergencySent && (
                <div className="text-[10px] text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3 h-3" /> Emergency alert sent successfully.
                </div>
              )}
            </div>
          </details>
        </div>

        {/* =================== Live Map =================== */}
        {route && (
          <div className="rounded-2xl border border-[#1f2538] overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 bg-[#161b2b] border-b border-[#1f2538]">
              <div className="flex items-center gap-1.5">
                <MapIcon className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Live Map</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-400">Follow</span>
                  <Switch checked={follow} onCheckedChange={setFollow} className="data-[state=checked]:bg-cyan-500" />
                </div>
                <Button variant="outline" size="sm" onClick={() => setFollow(true)} className="h-7 px-2 text-[10px] border-[#1f2538] text-cyan-300 hover:bg-cyan-500/10">
                  <Locate className="w-3 h-3 mr-1" /> Center
                </Button>
                <Button variant="outline" size="sm" onClick={() => setView('map')} className="h-7 px-2 text-[10px] border-[#1f2538] text-cyan-300 hover:bg-cyan-500/10">
                  Full <ChevronDown className="w-3 h-3 ml-0.5 -rotate-90" />
                </Button>
              </div>
            </div>
            <BusMap
              origin={routeStart}
              destination={dest}
              bus={lat != null && lng != null ? { lat, lng } : null}
              routeLabel={`${selectedBus?.busNo || ''} ${route.routeName} → RIT Campus`}
              followBus={follow}
              className="w-full h-56"
            />
          </div>
        )}

        {/* =================== Next Stop =================== */}
        {route && nextStop && (
          <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-500/[0.08] via-amber-500/[0.03] to-transparent p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5">
                <Flag className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Next Stop</span>
              </div>
              <Badge variant="outline" className="border-slate-600 bg-slate-800/50 text-slate-300 text-[10px]">
                Stop {nextStop.index + 1}/{stops.length}
              </Badge>
            </div>
            <div className="flex items-end justify-between gap-3">
              <div className="min-w-0">
                <div className={cn(
                  "text-xl font-bold truncate",
                  nextStop.arrived ? "text-emerald-300" : "text-white"
                )}>
                  {nextStop.stop.name || 'Unknown'}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 tabular-nums">
                  {formatDistance(nextStop.distanceKm)} away
                </div>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-3xl font-black text-emerald-300 tabular-nums leading-none">
                  {nextStop.arrived ? '0' : Math.max(0, Math.ceil(nextStop.etaMin))}
                </div>
                <div className="text-[10px] text-slate-500 -mt-0.5">min ETA</div>
              </div>
            </div>
            {tripState === 'active' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setStopEventForm({
                    stopName: nextStop.stop.name || 'Unknown',
                    stopIndex: nextStop.index,
                    boarded: 0, alighted: 0, waitingAt: 0,
                  })
                  setStopEventOpen(true)
                }}
                className="mt-3 w-full h-9 border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 text-xs"
              >
                <Crosshair className="w-3.5 h-3.5 mr-1" /> Record Passengers at this Stop
              </Button>
            )}
          </div>
        )}

        {/* =================== Trip Control =================== */}
        <div id="trip-control" className="rounded-2xl border border-[#1f2538] bg-[#161b2b] p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Trip Control</span>
            </div>
            {tripStartedAt && tripState === 'active' && (
              <span className="text-[10px] text-emerald-300">Started at {formatTimeOfDay(tripStartedAt)}</span>
            )}
          </div>
          {tripState === 'idle' ? (
            <Button
              onClick={startTrip}
              disabled={!selectedBus}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-sm font-bold disabled:opacity-40"
            >
              <Navigation className="w-4 h-4 mr-2" /> START TRIP
            </Button>
          ) : tripState === 'active' ? (
            <>
              <div className="flex items-center gap-2 mb-3 px-3 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                <span className="relative inline-flex w-2 h-2"><span className="absolute inset-0 rounded-full opacity-60 animate-ping bg-emerald-400" /><span className="relative inline-flex w-2 h-2 rounded-full bg-emerald-400" /></span>
                <span className="text-xs font-bold text-emerald-300">TRIP ACTIVE</span>
                {tripStartedAt && (
                  <span className="text-[10px] text-slate-500 ml-auto">since {formatTimeOfDay(tripStartedAt)}</span>
                )}
              </div>
              <Button onClick={() => setEndTripOpen(true)} variant="destructive" className="w-full h-12 rounded-xl bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 text-sm font-bold">
                <Square className="w-4 h-4 mr-2" /> END TRIP
              </Button>
            </>
          ) : (
            <div className="text-center py-2">
              <CheckCircle2 className="w-6 h-6 text-slate-500 mx-auto mb-1" />
              <div className="text-xs text-slate-400">Trip ended</div>
              <Button onClick={() => { setTripState('idle'); setTripStartedAt(null) }} variant="outline" className="mt-2 border-[#1f2538] text-cyan-300 hover:bg-cyan-500/10 text-xs h-9">
                Start New Trip
              </Button>
            </div>
          )}
          {!isGpsOn && tripState === 'idle' && selectedBus && (
            <div className="text-[10px] text-amber-400 text-center mt-2">Tip: Enable GPS to share live location with passengers</div>
          )}
          {!selectedBus && tripState === 'idle' && (
            <div className="text-[10px] text-amber-400 text-center mt-2">Select your bus first</div>
          )}
        </div>

        {/* =================== Upcoming Stops List =================== */}
        {route && upcoming.length > 0 && (
          <div className="rounded-2xl border border-[#1f2538] bg-[#161b2b] overflow-hidden">
            <div className="px-4 py-3 border-b border-[#1f2538] flex items-center gap-2">
              <Flag className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Upcoming Stops</span>
              <span className="ml-auto text-[10px] text-slate-500">{upcoming.length} ahead</span>
            </div>
            <div className="max-h-72 overflow-y-auto wmb-scroll">
              {upcoming.map((u, i) => {
                const isNext = i === 0
                const isLast = u.index === stops.length - 1
                return (
                  <div key={`${u.index}-${u.stop.name}`} className={cn(
                    "px-4 py-3 flex items-center gap-3 border-b border-[#1a2032] last:border-b-0 transition-colors",
                    isNext ? "bg-amber-500/5" : "hover:bg-white/[0.02]"
                  )}>
                    <div className="flex flex-col items-center flex-shrink-0">
                      <div className={cn(
                        "w-2.5 h-2.5 rounded-full border-2",
                        isNext ? "border-amber-400 bg-amber-400 animate-pulse"
                        : isLast ? "border-red-400 bg-red-400/30"
                        : "border-slate-600 bg-transparent"
                      )} />
                      {!isLast && <div className="w-px h-6 bg-slate-700 mt-0.5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className={cn("text-sm font-semibold truncate", isNext ? "text-amber-300" : "text-slate-200")}>
                          {u.stop.name || 'Unknown'}
                        </span>
                        {isNext && (
                          <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300 text-[9px] px-1.5 py-0 h-4 flex-shrink-0">NEXT</Badge>
                        )}
                        {isLast && (
                          <Badge variant="outline" className="border-red-500/40 bg-red-500/10 text-red-300 text-[9px] px-1.5 py-0 h-4 flex-shrink-0">FINAL</Badge>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5 tabular-nums">
                        {formatDistance(u.distanceKm)} from previous
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className={cn("text-sm font-bold tabular-nums", isNext ? "text-emerald-300" : "text-slate-300")}>
                        {Math.max(0, Math.ceil(u.etaMin))}
                        <span className="text-[10px] font-normal text-slate-500 ml-0.5">min</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* =================== System Status =================== */}
        <div className="rounded-2xl border border-[#1f2538] bg-[#161b2b] p-4">
          <div className="flex items-center gap-1.5 mb-3">
            <Signal className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">System Status</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <StatusRowSimple label="GPS" ok={sysStatus.gps} icon={Satellite} />
            <StatusRowSimple label="Network" ok={sysStatus.network} icon={Wifi} />
            <StatusRowSimple label="Server" ok={sysStatus.server} icon={Radio} />
            <StatusRowSimple label="Tracking" ok={sysStatus.tracking} icon={Activity} />
          </div>
        </div>

      </main>

      {/* =================== Bus Picker Dialog =================== */}
      <BusPicker
        open={busPickerOpen}
        onOpenChange={setBusPickerOpen}
        selectedBus={selectedBus}
        onSelect={(b) => {
          setSelectedBus(b)
          setBusPickerOpen(false)
          toast.success(`Bus selected: ${b.busNo} (${b.plate}) → ${getBusRoute(b)?.routeName || ''}`)
        }}
      />

      {/* =================== Emergency Dialog =================== */}
      <Dialog open={emergencyOpen} onOpenChange={setEmergencyOpen}>
        <DialogContent className="bg-[#161b2b] border-red-500/30 text-white">
          <DialogHeader>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-xl bg-red-500/15 text-red-400 flex items-center justify-center">
                <Shield className="w-5 h-5" />
              </div>
              <DialogTitle className="text-red-300">Emergency Assistance</DialogTitle>
            </div>
            <DialogDescription className="text-slate-400">
              Are you sure you want to send an emergency alert? This will notify the control room
              with your current GPS coordinates and timestamp.
            </DialogDescription>
          </DialogHeader>
          {lat != null && lng != null && (
            <div className="rounded-lg bg-[#0f111a] border border-[#1f2538] p-2.5 text-xs font-mono text-slate-400">
              {lat.toFixed(4)}°N, {lng.toFixed(4)}°E
            </div>
          )}
          <DialogFooter className="flex gap-2 mt-2">
            <Button variant="outline" onClick={() => setEmergencyOpen(false)} className="border-[#1f2538] text-slate-300 hover:bg-[#1f2538] flex-1">
              <X className="w-4 h-4 mr-1.5" /> CANCEL
            </Button>
            <Button variant="destructive" onClick={confirmEmergency} className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 flex-1">
              <Send className="w-4 h-4 mr-1.5" /> SEND ALERT
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* =================== End Trip Dialog =================== */}
      <Dialog open={endTripOpen} onOpenChange={setEndTripOpen}>
        <DialogContent className="bg-[#161b2b] border-[#1f2538] text-white">
          <DialogHeader>
            <DialogTitle className="text-white">End Trip?</DialogTitle>
            <DialogDescription className="text-slate-400">
              Are you sure you want to end the current trip? Passengers will be notified.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 mt-2">
            <Button variant="outline" onClick={() => setEndTripOpen(false)} className="border-[#1f2538] text-slate-300 hover:bg-[#1f2538] flex-1">
              <X className="w-4 h-4 mr-1.5" /> CANCEL
            </Button>
            <Button variant="destructive" onClick={confirmEndTrip} className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 flex-1">
              <Square className="w-4 h-4 mr-1.5" /> END TRIP
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* =================== Stop Event Dialog =================== */}
      <Dialog open={stopEventOpen} onOpenChange={setStopEventOpen}>
        <DialogContent className="bg-[#161b2b] border-[#1f2538] text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Crosshair className="w-4 h-4 text-amber-400" /> Passenger Count
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Record passengers at <span className="text-amber-300 font-semibold">{stopEventForm.stopName}</span>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Stepper label="Boarded (got on)" value={stopEventForm.boarded} onChange={(v) => setStopEventForm((f) => ({ ...f, boarded: v }))} accent="#22c55e" />
            <Stepper label="Alighted (got off)" value={stopEventForm.alighted} onChange={(v) => setStopEventForm((f) => ({ ...f, alighted: v }))} accent="#f59e0b" />
            <Stepper label="Waiting at stop" value={stopEventForm.waitingAt} onChange={(v) => setStopEventForm((f) => ({ ...f, waitingAt: v }))} accent="#3b82f6" />
          </div>
          <DialogFooter className="flex gap-2 mt-2">
            <Button variant="outline" onClick={() => setStopEventOpen(false)} className="border-[#1f2538] text-slate-300 hover:bg-[#1f2538] flex-1">
              <X className="w-4 h-4 mr-1.5" /> CANCEL
            </Button>
            <Button onClick={recordStopEvent} className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 flex-1 text-black">
              <CheckCircle2 className="w-4 h-4 mr-1.5" /> SAVE
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// =================== Sub-components ===================

// Bitano-style status row with icon + label + value (used in the portal accordion)
function StatusRow({
  icon: Icon,
  label,
  value,
  valueColor,
  valueClass,
  divider,
}: {
  icon: React.ElementType
  label: string
  value: string
  valueColor?: string
  valueClass?: string
  divider?: boolean
}) {
  return (
    <div className={cn("px-4 py-3 flex items-center justify-between", divider && "border-b border-[#1a2032]")}>
      <div className="flex items-center gap-2.5">
        <Icon className="w-3.5 h-3.5 text-slate-500" />
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{label}</span>
      </div>
      <span className={cn("text-xs font-bold tabular-nums", valueColor || "text-slate-200", valueClass)}>
        {value}
      </span>
    </div>
  )
}

// Simple OK/Disconnected status row (used in system status grid)
function StatusRowSimple({ label, ok, icon: Icon }: { label: string; ok: boolean; icon: React.ElementType }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-[#0f111a]/60 px-2.5 py-2">
      <div className="flex items-center gap-1.5">
        <Icon className={cn("w-3.5 h-3.5", ok ? "text-emerald-400" : "text-slate-600")} />
        <span className="text-[11px] font-semibold text-slate-300">{label}</span>
      </div>
      <div className="flex items-center gap-1">
        <span className={cn("w-1.5 h-1.5 rounded-full", ok ? "bg-emerald-400" : "bg-red-400")} />
        <span className={cn("text-[10px] font-bold", ok ? "text-emerald-300" : "text-red-300")}>
          {ok ? 'Connected' : 'Off'}
        </span>
      </div>
    </div>
  )
}

function BusPicker({ open, onOpenChange, selectedBus, onSelect }: {
  open: boolean
  onOpenChange: (v: boolean) => void
  selectedBus: Bus | null
  onSelect: (b: Bus) => void
}) {
  const [q, setQ] = useState("")
  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase()
    if (!query) return BUS_FLEET
    return BUS_FLEET.filter((b) =>
      b.busNo.toLowerCase().includes(query) ||
      b.plate.toLowerCase().includes(query) ||
      b.routeNo.toLowerCase().includes(query)
    )
  }, [q])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#10131f] border-[#1a2032] text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <BusIcon className="w-4 h-4 text-cyan-400" /> Choose Your Assigned Bus
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Select the bus you are driving today. The route is determined by your bus assignment.
          </DialogDescription>
        </DialogHeader>
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search bus no, plate, or route…"
          className="w-full bg-[#0a0d18] border border-[#1a2032] rounded-lg px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/40"
        />
        <div className="max-h-72 overflow-y-auto wmb-scroll space-y-1.5 mt-2">
          {filtered.map((b) => {
            const isActive = selectedBus?.busNo === b.busNo
            return (
              <button
                key={b.busNo}
                onClick={() => onSelect(b)}
                className={cn(
                  "w-full text-left rounded-xl px-3 py-2.5 border flex items-center gap-3 transition-colors",
                  isActive
                    ? "border-cyan-500/50 bg-cyan-500/10"
                    : "border-[#1a2032] hover:border-[#2a3252] hover:bg-[#161b2b]"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                  isActive ? "bg-cyan-500/20 text-cyan-300" : "bg-[#1a2032] text-slate-400"
                )}>
                  <BusIcon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm text-slate-100">{b.busNo}</div>
                  <div className="text-[11px] text-slate-500 font-mono">{b.plate}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-wider text-slate-500">Route</div>
                  <div className="text-xs font-bold text-cyan-300">{b.routeNo}</div>
                </div>
              </button>
            )
          })}
          {filtered.length === 0 && (
            <div className="text-center text-sm text-slate-500 py-6">No buses match "{q}"</div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

// =================== Stepper (number +/- input) ===================
function Stepper({ label, value, onChange, accent }: {
  label: string
  value: number
  onChange: (v: number) => void
  accent: string
}) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-[#0a0d18] border border-[#1a2032] px-3 py-2">
      <div className="flex items-center gap-2">
        <span className="w-2 h-2 rounded-full" style={{ background: accent }} />
        <span className="text-xs font-semibold text-slate-200">{label}</span>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onChange(Math.max(0, value - 1))}
          className="w-8 h-8 rounded-lg bg-[#1a2032] hover:bg-[#2a3252] text-slate-200 font-bold text-lg flex items-center justify-center"
        >−</button>
        <input
          type="number"
          min={0}
          value={value}
          onChange={(e) => onChange(Math.max(0, parseInt(e.target.value) || 0))}
          className="w-14 text-center bg-transparent text-white font-bold text-base tabular-nums focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
        />
        <button
          onClick={() => onChange(value + 1)}
          className="w-8 h-8 rounded-lg bg-[#1a2032] hover:bg-[#2a3252] text-slate-200 font-bold text-lg flex items-center justify-center"
        >+</button>
      </div>
    </div>
  )
}

// =================== Driver Login Screen ===================
function DriverLogin({ onLogin }: { onLogin: (d: DriverInfo) => void }) {
  const [driverId, setDriverId] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [drivers, setDrivers] = useState<Array<{ id: string; name: string; phone: string | null; active: boolean }>>([])

  useEffect(() => {
    fetch("/api/driver/login")
      .then((r) => r.json())
      .then((data) => {
        if (data.drivers) setDrivers(data.drivers)
      })
      .catch(() => {})
  }, [])

  const submit = async (id?: string) => {
    const did = (id || driverId).trim().toUpperCase()
    if (!did) {
      setError("Enter your Driver ID")
      return
    }
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/driver/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ driverId: did }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || "Login failed")
        return
      }
      onLogin(data.driver)
    } catch (e) {
      setError("Network error. Try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm space-y-5"
      >
        {/* Logo */}
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/30">
            <Satellite className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-xl font-black text-white mt-3">Driver Login</h1>
          <p className="text-xs text-slate-500 mt-1">Enter your Driver ID to access the dashboard</p>
        </div>

        {/* Form */}
        <div className="rounded-2xl border border-[#1a2032] bg-[#10131f] p-4 space-y-3">
          <input
            autoFocus
            value={driverId}
            onChange={(e) => setDriverId(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') submit() }}
            placeholder="DRIVER-001"
            className="w-full bg-[#0a0d18] border border-[#1a2032] rounded-lg px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/40 uppercase font-mono"
          />
          {error && (
            <div className="text-xs text-red-400 bg-red-500/5 border border-red-500/20 rounded-lg px-3 py-2">
              {error}
            </div>
          )}
          <Button
            onClick={() => submit()}
            disabled={loading}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-sm font-bold disabled:opacity-50"
          >
            {loading ? "Signing in…" : "Sign In"}
          </Button>
        </div>

        {/* Quick-pick list of demo drivers */}
        {drivers.length > 0 && (
          <div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2 px-1">
              Demo Drivers (tap to login)
            </div>
            <div className="space-y-1.5">
              {drivers.filter(d => d.active).map((d) => (
                <button
                  key={d.id}
                  onClick={() => submit(d.id)}
                  disabled={loading}
                  className="w-full text-left rounded-xl px-3 py-2.5 border border-[#1a2032] bg-[#10131f] hover:border-cyan-500/40 hover:bg-cyan-500/5 transition-colors flex items-center gap-3 disabled:opacity-50"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {d.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-slate-100">{d.name}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{d.id}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="text-[10px] text-slate-600 text-center">
          Driver authentication is required. Your session is stored locally on this device.
        </div>
      </motion.div>
    </div>
  )
}

// =================== Driver Profile (Trip History) ===================
function DriverProfile({ driver, history, historyLoading, onBack, onLogout }: {
  driver: DriverInfo
  history: Array<{
    id: string; busNo: string; plate: string; routeNo: string; routeName: string;
    status: string; startedAt: string; endedAt: string | null; durationMin: number | null;
    totalKm: number | null; totalBoarded: number; totalAlighted: number; stopsCount: number;
  }>
  historyLoading: boolean
  onBack: () => void
  onLogout: () => void
}) {
  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center gap-3 pt-1 pb-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="text-cyan-300 hover:bg-cyan-500/10 px-2"
        >
          <ChevronRight className="w-4 h-4 rotate-180" /> Back
        </Button>
        <h2 className="text-lg font-bold text-white">Driver Profile</h2>
      </div>

      {/* Driver card */}
      <div className="rounded-2xl border border-[#1a2032] bg-gradient-to-br from-[#10131f] to-[#0d1424] p-4 flex items-center gap-3">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-lg flex-shrink-0"
          style={{ background: `linear-gradient(135deg, ${driver.avatarColor}, ${driver.avatarColor}cc)` }}
        >
          {driver.name.charAt(0).toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-base font-bold text-white truncate">{driver.name}</div>
          <div className="text-[11px] text-slate-500 font-mono">{driver.id}</div>
          {driver.phone && <div className="text-[11px] text-slate-500 mt-0.5">{driver.phone}</div>}
          {driver.licenseNo && <div className="text-[10px] text-slate-600 mt-0.5">License: {driver.licenseNo}</div>}
        </div>
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-3 gap-2">
        <StatTile label="Total Trips" value={String(history.length)} />
        <StatTile label="Passengers" value={String(history.reduce((s, t) => s + t.totalBoarded, 0))} />
        <StatTile
          label="Total km"
          value={history.reduce((s, t) => s + (t.totalKm || 0), 0).toFixed(1)}
        />
      </div>

      {/* Trip history */}
      <div>
        <div className="flex items-center justify-between mb-2 px-1">
          <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Trip History</span>
          <span className="text-[10px] text-slate-500">{history.length} trip{history.length !== 1 ? 's' : ''}</span>
        </div>
        {historyLoading ? (
          <div className="rounded-xl border border-[#1a2032] bg-[#10131f] p-6 text-center text-sm text-slate-500">
            Loading…
          </div>
        ) : history.length === 0 ? (
          <div className="rounded-xl border border-[#1a2032] bg-[#10131f] p-6 text-center text-sm text-slate-500">
            No trips yet. Start a trip to see your history here.
          </div>
        ) : (
          <div className="space-y-2">
            {history.map((t) => {
              const d = new Date(t.startedAt)
              const dateStr = d.toLocaleDateString([], { day: 'numeric', month: 'short' })
              const timeStr = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
              const isActive = t.status === 'active'
              return (
                <div key={t.id} className="rounded-xl border border-[#1a2032] bg-[#10131f] p-3">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                        isActive ? "bg-emerald-500/15 text-emerald-300" : "bg-[#1a2032] text-slate-400"
                      )}>
                        <BusIcon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-slate-100">{t.busNo}</div>
                        <div className="text-[10px] text-slate-500 font-mono truncate">{t.plate}</div>
                      </div>
                    </div>
                    <Badge variant="outline" className={cn(
                      "text-[9px] px-1.5 py-0 h-4 flex-shrink-0",
                      isActive ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" :
                      t.status === 'emergency' ? "border-red-500/40 bg-red-500/10 text-red-300" :
                      "border-slate-600 bg-slate-700/30 text-slate-400"
                    )}>
                      {t.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Route {t.routeNo} → {t.routeName}
                  </div>
                  <div className="grid grid-cols-4 gap-2 mt-2 pt-2 border-t border-[#1a2032] text-[10px]">
                    <div>
                      <div className="text-slate-600">Started</div>
                      <div className="text-slate-200 font-semibold">{dateStr} {timeStr}</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Duration</div>
                      <div className="text-slate-200 font-semibold tabular-nums">
                        {t.durationMin != null ? formatDuration(t.durationMin) : '—'}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-600">Distance</div>
                      <div className="text-slate-200 font-semibold tabular-nums">{t.totalKm ? formatDistance(t.totalKm) : '—'}</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Boarded</div>
                      <div className="text-emerald-300 font-semibold tabular-nums">{t.totalBoarded}</div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Logout */}
      <Button
        onClick={onLogout}
        variant="outline"
        className="w-full h-12 rounded-xl border-red-500/30 text-red-300 hover:bg-red-500/10 text-sm font-bold mt-4"
      >
        <X className="w-4 h-4 mr-2" /> LOGOUT
      </Button>
    </div>
  )
}

function StatTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-[#1a2032] bg-[#10131f] p-3 text-center">
      <div className="text-2xl font-black text-cyan-300 tabular-nums leading-none">{value}</div>
      <div className="text-[9px] uppercase tracking-widest text-slate-500 font-semibold mt-1">{label}</div>
    </div>
  )
}
