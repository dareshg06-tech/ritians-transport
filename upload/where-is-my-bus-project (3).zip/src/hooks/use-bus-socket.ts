"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { io, type Socket } from "socket.io-client"

export interface DriverLocation {
  routeNo: string
  routeName: string
  busNo?: string
  plate?: string
  lat: number
  lng: number
  accuracy?: number
  speedKmh: number
  heading: number
  timestamp: number
  mode: 'gps' | 'tower'
  driverId: string
}

export type DriverStatus = 'online' | 'offline' | 'connecting'

export interface TripStatus {
  routeNo: string
  busNo?: string
  plate?: string
  routeName: string
  startedAt: number | null
  endedAt: number | null
  status: 'idle' | 'active' | 'ended' | 'emergency'
  vehicleId?: string
  driverId?: string
}

export interface NextStopInfo {
  routeNo: string
  stopName: string
  stopIndex: number
  totalStops: number
  distanceKm: number
  etaMin: number
  arrived: boolean
  timestamp: number
}

let socketSingleton: Socket | null = null

function getSocket(): Socket {
  if (socketSingleton) return socketSingleton
  socketSingleton = io("/?XTransformPort=3003", {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000,
  })
  return socketSingleton
}

/** Hook that gives you a singleton socket + connection state. */
export function useSocket() {
  const [socket] = useState<Socket>(() => getSocket())
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    const onConn = () => setConnected(true)
    const onDisc = () => setConnected(false)
    socket.on('connect', onConn)
    socket.on('disconnect', onDisc)
    const t = setTimeout(() => {
      if (socket.connected) setConnected(true)
    }, 0)
    return () => {
      clearTimeout(t)
      socket.off('connect', onConn)
      socket.off('disconnect', onDisc)
    }
  }, [socket])

  return { socket, connected }
}

/** Passenger-side hook: subscribe to a route's live driver updates + trip status + next stop. */
export function usePassengerTracking(routeNo: string | null) {
  const { socket, connected } = useSocket()
  const [location, setLocation] = useState<DriverLocation | null>(null)
  const [status, setStatus] = useState<DriverStatus>('connecting')
  const [trip, setTrip] = useState<TripStatus | null>(null)
  const [nextStop, setNextStop] = useState<NextStopInfo | null>(null)
  const [busInfo, setBusInfo] = useState<{ busNo?: string; plate?: string }>({})

  useEffect(() => {
    if (!socket || !connected || !routeNo) {
      const t = setTimeout(() => {
        setStatus('connecting')
      }, 0)
      return () => clearTimeout(t)
    }
    const t0 = setTimeout(() => {
      setLocation(null)
      setStatus('connecting')
      setTrip(null)
      setNextStop(null)
      setBusInfo({})
      socket.emit('passenger:subscribe', { routeNo })
    }, 0)

    const onLoc = (loc: DriverLocation) => {
      setLocation(loc)
      setStatus('online')
      if (loc.busNo || loc.plate) {
        setBusInfo({ busNo: loc.busNo, plate: loc.plate })
      }
    }
    const onOnline = (info: { routeNo: string; busNo?: string; plate?: string }) => {
      setStatus('online')
      if (info.busNo || info.plate) setBusInfo({ busNo: info.busNo, plate: info.plate })
    }
    const onOffline = () => {
      setStatus('offline')
      setLocation(null)
    }
    const onTrip = (t: TripStatus) => setTrip(t)
    const onNext = (ns: NextStopInfo) => setNextStop(ns)

    socket.on('driver-location', onLoc)
    socket.on('driver-online', onOnline)
    socket.on('driver-offline', onOffline)
    socket.on('trip-status', onTrip)
    socket.on('next-stop', onNext)

    return () => {
      clearTimeout(t0)
      socket.emit('passenger:unsubscribe', { routeNo })
      socket.off('driver-location', onLoc)
      socket.off('driver-online', onOnline)
      socket.off('driver-offline', onOffline)
      socket.off('trip-status', onTrip)
      socket.off('next-stop', onNext)
    }
  }, [socket, connected, routeNo])

  return { location, status, connected, trip, nextStop, busInfo }
}

/** Driver-side hook: start/stop broadcasting GPS fixes + trip + next-stop + emergency. */
export function useDriverBroadcast() {
  const { socket, connected } = useSocket()
  const [isSharing, setIsSharing] = useState(false)
  const routeRef = useRef<string | null>(null)
  const busInfoRef = useRef<{ busNo?: string; plate?: string }>({})
  const isSharingRef = useRef(false)

  const start = useCallback(
    (routeNo: string, routeName: string, busInfo?: { busNo?: string; plate?: string }) => {
      if (!socket) return false
      if (!socket.connected) {
        socket.connect()
      }
      routeRef.current = routeNo
      busInfoRef.current = busInfo || {}
      isSharingRef.current = true
      socket.emit('driver:start', {
        routeNo,
        routeName,
        driverId: socket.id,
        busNo: busInfo?.busNo,
        plate: busInfo?.plate,
      })
      setIsSharing(true)
      return true
    },
    [socket]
  )

  const stop = useCallback(() => {
    if (!socket) return
    socket.emit('driver:stop', {})
    isSharingRef.current = false
    setIsSharing(false)
    routeRef.current = null
    busInfoRef.current = {}
  }, [socket])

  const push = useCallback(
    (loc: Omit<DriverLocation, 'routeNo' | 'driverId' | 'timestamp'> & { timestamp?: number }) => {
      if (!socket || !isSharingRef.current || !routeRef.current) return
      socket.emit('driver:update', {
        routeNo: routeRef.current,
        routeName: loc.routeName,
        lat: loc.lat,
        lng: loc.lng,
        accuracy: loc.accuracy,
        speedKmh: loc.speedKmh,
        heading: loc.heading,
        mode: loc.mode,
        timestamp: loc.timestamp || Date.now(),
      })
    },
    [socket]
  )

  const pushNextStop = useCallback(
    (ns: Omit<NextStopInfo, 'routeNo' | 'timestamp'> & { timestamp?: number }) => {
      if (!socket || !isSharingRef.current || !routeRef.current) return
      socket.emit('driver:next-stop', {
        routeNo: routeRef.current,
        stopName: ns.stopName,
        stopIndex: ns.stopIndex,
        totalStops: ns.totalStops,
        distanceKm: ns.distanceKm,
        etaMin: ns.etaMin,
        arrived: ns.arrived,
        timestamp: ns.timestamp || Date.now(),
      })
    },
    [socket]
  )

  const startTrip = useCallback(
    (routeNo: string, routeName: string, busInfo?: { busNo?: string; plate?: string }) => {
      if (!socket) return false
      socket.emit('trip:start', {
        routeNo,
        routeName,
        busNo: busInfo?.busNo,
        plate: busInfo?.plate,
        vehicleId: busInfo?.busNo,
        driverId: socket.id,
      })
      return true
    },
    [socket]
  )

  const endTrip = useCallback(
    (routeNo: string) => {
      if (!socket) return
      socket.emit('trip:end', { routeNo })
    },
    [socket]
  )

  const sendEmergency = useCallback(
    (routeNo: string, lat: number, lng: number, busNo?: string) => {
      if (!socket) return
      socket.emit('emergency:alert', {
        routeNo,
        lat,
        lng,
        timestamp: Date.now(),
        busNo,
      })
    },
    [socket]
  )

  return { start, stop, push, pushNextStop, startTrip, endTrip, sendEmergency, isSharing, connected }
}
