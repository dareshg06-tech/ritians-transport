#!/bin/bash
trap '' HUP INT TERM
cd "$(dirname "$0")"
while true; do
  bun index.ts 2>&1
  echo "[heal] exited $? at $(date -u +%FT%TZ), respawning in 1s" >&2
  sleep 1
done
