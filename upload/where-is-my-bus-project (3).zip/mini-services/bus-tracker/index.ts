import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

interface DriverLocation {
  routeNo: string
  routeName: string
  busNo?: string
  plate?: string
  lat: number
  lng: number
  accuracy?: number
  speedKmh: number
  heading: number
  timestamp: number
  mode: 'gps' | 'tower'
  driverId: string
}

// Trip status (separate from GPS sharing)
interface TripStatus {
  routeNo: string
  busNo?: string
  plate?: string
  routeName: string
  startedAt: number | null
  endedAt: number | null
  status: 'idle' | 'active' | 'ended' | 'emergency'
  vehicleId?: string
  driverId?: string
}

// Next-stop info broadcast (computed by driver, sent to passengers)
interface NextStopInfo {
  routeNo: string
  stopName: string
  stopIndex: number
  totalStops: number
  distanceKm: number
  etaMin: number
  arrived: boolean
  timestamp: number
}

// In-memory live driver registry: routeNo -> latest known location
const liveDrivers = new Map<string, DriverLocation>()

// Trip status registry: routeNo -> trip status
const tripStatuses = new Map<string, TripStatus>()

// Latest next-stop info per route
const nextStopInfo = new Map<string, NextStopInfo>()

// Heartbeat watchdog: if a driver hasn't pinged in 60s, evict them.
const lastSeen = new Map<string, number>()
const STALE_MS = 60_000

setInterval(() => {
  const now = Date.now()
  for (const [routeNo, ts] of lastSeen.entries()) {
    if (now - ts > STALE_MS) {
      console.log(`[tracker] evicting stale driver for ${routeNo}`)
      liveDrivers.delete(routeNo)
      lastSeen.delete(routeNo)
      io.to(`route:${routeNo}`).emit('driver-offline', { routeNo, reason: 'timeout' })
    }
  }
}, 10_000)

io.on('connection', (socket) => {
  console.log(`[tracker] client connected: ${socket.id}`)

  // Driver starts broadcasting for a route
  socket.on('driver:start', (payload: {
    routeNo: string
    routeName: string
    driverId?: string
    busNo?: string
    plate?: string
  }) => {
    socket.data.role = 'driver'
    socket.data.routeNo = payload.routeNo
    socket.data.driverId = payload.driverId || socket.id
    socket.data.busNo = payload.busNo
    socket.data.plate = payload.plate
    console.log(`[driver] ${socket.id} started on route ${payload.routeNo} (${payload.routeName}) bus=${payload.busNo || 'n/a'}`)
    socket.join(`route:${payload.routeNo}`)
    // Notify all passengers on that route that driver is online
    io.to(`route:${payload.routeNo}`).emit('driver-online', {
      routeNo: payload.routeNo,
      busNo: payload.busNo,
      plate: payload.plate,
    })
  })

  // Driver pushes a new GPS / tower fix
  socket.on('driver:update', (payload: Omit<DriverLocation, 'timestamp' | 'driverId'> & { timestamp?: number }) => {
    if (socket.data.role !== 'driver') return
    const routeNo = socket.data.routeNo
    if (!routeNo) return
    const ts = payload.timestamp || Date.now()
    const loc: DriverLocation = {
      routeNo,
      routeName: payload.routeName,
      busNo: socket.data.busNo,
      plate: socket.data.plate,
      lat: payload.lat,
      lng: payload.lng,
      accuracy: payload.accuracy,
      speedKmh: payload.speedKmh,
      heading: payload.heading,
      mode: payload.mode,
      driverId: socket.data.driverId,
      timestamp: ts,
    }
    liveDrivers.set(routeNo, loc)
    lastSeen.set(routeNo, ts)
    // Broadcast to passengers subscribed to this route
    io.to(`route:${routeNo}`).emit('driver-location', loc)
    // Log every 5th update to avoid spam
    if (!socket.data._updateCount) socket.data._updateCount = 0
    socket.data._updateCount++
    if (socket.data._updateCount % 5 === 0) {
      console.log(`[driver] ${routeNo} loc=(${payload.lat.toFixed(4)}, ${payload.lng.toFixed(4)}) speed=${payload.speedKmh.toFixed(1)}km/h`)
    }
  })

  // Driver pushes next-stop info (computed on driver side, broadcast to passengers)
  socket.on('driver:next-stop', (payload: Omit<NextStopInfo, 'timestamp'> & { timestamp?: number }) => {
    if (socket.data.role !== 'driver') return
    const routeNo = socket.data.routeNo
    if (!routeNo) return
    const info: NextStopInfo = {
      routeNo,
      stopName: payload.stopName,
      stopIndex: payload.stopIndex,
      totalStops: payload.totalStops,
      distanceKm: payload.distanceKm,
      etaMin: payload.etaMin,
      arrived: payload.arrived,
      timestamp: payload.timestamp || Date.now(),
    }
    nextStopInfo.set(routeNo, info)
    io.to(`route:${routeNo}`).emit('next-stop', info)
  })

  // Driver starts a trip
  socket.on('trip:start', (payload: { routeNo: string; routeName: string; busNo?: string; plate?: string; vehicleId?: string; driverId?: string }) => {
    const routeNo = payload.routeNo
    const status: TripStatus = {
      routeNo,
      busNo: payload.busNo,
      plate: payload.plate,
      routeName: payload.routeName,
      startedAt: Date.now(),
      endedAt: null,
      status: 'active',
      vehicleId: payload.vehicleId || payload.busNo,
      driverId: payload.driverId,
    }
    tripStatuses.set(routeNo, status)
    io.to(`route:${routeNo}`).emit('trip-status', status)
    console.log(`[trip] START route=${routeNo} bus=${payload.busNo || 'n/a'}`)
  })

  // Driver ends a trip
  socket.on('trip:end', (payload: { routeNo: string }) => {
    const routeNo = payload.routeNo
    const existing = tripStatuses.get(routeNo)
    const status: TripStatus = {
      routeNo,
      busNo: existing?.busNo,
      plate: existing?.plate,
      routeName: existing?.routeName || '',
      startedAt: existing?.startedAt || null,
      endedAt: Date.now(),
      status: 'ended',
      vehicleId: existing?.vehicleId,
      driverId: existing?.driverId,
    }
    tripStatuses.set(routeNo, status)
    io.to(`route:${routeNo}`).emit('trip-status', status)
    console.log(`[trip] END route=${routeNo}`)
  })

  // Driver triggers emergency
  socket.on('emergency:alert', (payload: { routeNo: string; lat: number; lng: number; timestamp: number; busNo?: string }) => {
    const routeNo = payload.routeNo
    const existing = tripStatuses.get(routeNo)
    if (existing) {
      existing.status = 'emergency'
      tripStatuses.set(routeNo, existing)
    }
    io.to(`route:${routeNo}`).emit('emergency-alert', payload)
    console.log(`[emergency] ALERT route=${routeNo} loc=(${payload.lat.toFixed(4)}, ${payload.lng.toFixed(4)})`)
  })

  // Driver stops sharing
  socket.on('driver:stop', () => {
    const routeNo = socket.data.routeNo
    if (routeNo) {
      liveDrivers.delete(routeNo)
      lastSeen.delete(routeNo)
      nextStopInfo.delete(routeNo)
      io.to(`route:${routeNo}`).emit('driver-offline', { routeNo, reason: 'manual-stop' })
      console.log(`[driver] ${socket.id} stopped on route ${routeNo}`)
      socket.leave(`route:${routeNo}`)
    }
    socket.data.role = null
    socket.data.routeNo = null
  })

  // Passenger subscribes to a route's live updates
  socket.on('passenger:subscribe', (payload: { routeNo: string }) => {
    socket.data.role = 'passenger'
    const routeNo = payload.routeNo
    socket.join(`route:${routeNo}`)
    // If a driver is already broadcasting, immediately send the last known location
    const existing = liveDrivers.get(routeNo)
    if (existing) {
      socket.emit('driver-online', { routeNo, busNo: existing.busNo, plate: existing.plate })
      socket.emit('driver-location', existing)
    } else {
      socket.emit('driver-offline', { routeNo, reason: 'no-driver' })
    }
    // Send trip status if exists
    const trip = tripStatuses.get(routeNo)
    if (trip) {
      socket.emit('trip-status', trip)
    }
    // Send next-stop info if exists
    const ns = nextStopInfo.get(routeNo)
    if (ns) {
      socket.emit('next-stop', ns)
    }
    console.log(`[passenger] ${socket.id} subscribed to ${routeNo}`)
  })

  // Passenger unsubscribes
  socket.on('passenger:unsubscribe', (payload: { routeNo: string }) => {
    socket.leave(`route:${payload.routeNo}`)
    console.log(`[passenger] ${socket.id} unsubscribed from ${payload.routeNo}`)
  })

  // Health check
  socket.on('ping-server', () => {
    socket.emit('pong-server', {
      t: Date.now(),
      online: liveDrivers.size,
      trips: tripStatuses.size,
    })
  })

  socket.on('disconnect', () => {
    if (socket.data.role === 'driver' && socket.data.routeNo) {
      const routeNo = socket.data.routeNo
      liveDrivers.delete(routeNo)
      lastSeen.delete(routeNo)
      nextStopInfo.delete(routeNo)
      io.to(`route:${routeNo}`).emit('driver-offline', { routeNo, reason: 'driver-disconnected' })
      console.log(`[driver] ${socket.id} disconnected from route ${routeNo}`)
    } else {
      console.log(`[client] ${socket.id} disconnected`)
    }
  })

  socket.on('error', (err) => {
    console.error(`[socket error] ${socket.id}:`, err)
  })
})

const PORT = 3003
httpServer.listen(PORT, "::", () => {
  console.log(`[bus-tracker] WebSocket service running on port ${PORT}`)
})

process.on('SIGTERM', () => {
  console.log('[bus-tracker] SIGTERM, shutting down...')
  httpServer.close(() => process.exit(0))
})
process.on('SIGINT', () => {
  console.log('[bus-tracker] SIGINT, shutting down...')
  httpServer.close(() => process.exit(0))
})
