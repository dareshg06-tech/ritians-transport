#!/bin/bash
# Robust bus-tracker service runner — auto-restarts on crash
cd "$(dirname "$0")"
echo "[runner] starting bus-tracker watchdog..."
while true; do
  echo "[runner] launching bun index.ts at $(date -u +%FT%TZ)"
  bun index.ts
  exit_code=$?
  echo "[runner] bun exited with code $exit_code at $(date -u +%FT%TZ) — restarting in 2s"
  sleep 2
done
