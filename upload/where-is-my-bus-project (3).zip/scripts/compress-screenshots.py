#!/usr/bin/env python3
"""Compress all PNG screenshots in the download folder."""
import os
import sys
from PIL import Image
from pathlib import Path

DOWNLOAD_DIR = Path("/home/z/my-project/download")

def compress_png(filepath):
    """Compress a single PNG file in place."""
    try:
        original_size = os.path.getsize(filepath)
        img = Image.open(filepath)
        # Convert to RGBA if needed for proper handling
        if img.mode not in ("RGB", "RGBA", "P"):
            img = img.convert("RGBA")
        # For palette mode, keep it (smaller); for others, optimize
        if img.mode == "P":
            img.save(filepath, format="PNG", optimize=True, compress_level=9)
        else:
            # Quantize to reduce colors (max 256) — dramatic size reduction for screenshots
            quantized = img.quantize(colors=256, method=0, dither=1)  # MEDIANCUT + FLOYDSTEINBER
            quantized.save(filepath, format="PNG", optimize=True, compress_level=9)
        new_size = os.path.getsize(filepath)
        return original_size, new_size
    except Exception as e:
        print(f"  ERROR: {e}")
        return 0, 0

def main():
    pngs = sorted(DOWNLOAD_DIR.glob("*.png"))
    if not pngs:
        print("No PNG files found in download folder")
        return
    
    print(f"Found {len(pngs)} PNG files to compress")
    print("=" * 60)
    
    total_original = 0
    total_compressed = 0
    compressed_count = 0
    
    for png in pngs:
        orig, new = compress_png(png)
        if orig > 0:
            total_original += orig
            total_compressed += new
            savings = (1 - new / orig) * 100
            print(f"  {png.name:45s} {orig/1024:6.0f}KB -> {new/1024:6.0f}KB ({savings:+5.1f}%)")
            compressed_count += 1
    
    print("=" * 60)
    total_savings = (1 - total_compressed / total_original) * 100 if total_original > 0 else 0
    print(f"Compressed {compressed_count} files")
    print(f"Total: {total_original/1024/1024:.2f}MB -> {total_compressed/1024/1024:.2f}MB ({total_savings:.1f}% smaller)")

if __name__ == "__main__":
    main()
