import { db } from "../src/lib/db"
async function main() {
  const drivers = await db.driver.findMany()
  console.log("=== DRIVERS ===")
  console.log(JSON.stringify(drivers, null, 2))
  const trips = await db.trip.findMany({ include: { stopEvents: true, driver: true } })
  console.log("\n=== TRIPS ===")
  for (const t of trips) {
    console.log(`Trip ${t.id.slice(-6)}: ${t.busNo} ${t.plate} route ${t.routeNo} (${t.routeName})`)
    console.log(`  status=${t.status} started=${t.startedAt.toISOString()} ended=${t.endedAt?.toISOString() || 'active'}`)
    console.log(`  totalKm=${t.totalKm} boarded=${t.totalBoarded} alighted=${t.totalAlighted}`)
    console.log(`  driver=${t.driver?.name} (${t.driver?.id})`)
    console.log(`  stopEvents: ${t.stopEvents.length}`)
    for (const e of t.stopEvents) {
      console.log(`    - ${e.stopName} (idx ${e.stopIndex}): boarded=${e.boarded} alighted=${e.alighted} waiting=${e.waitingAt} at ${e.timestamp.toISOString()}`)
    }
  }
}
main().catch(console.error).finally(() => process.exit(0))
